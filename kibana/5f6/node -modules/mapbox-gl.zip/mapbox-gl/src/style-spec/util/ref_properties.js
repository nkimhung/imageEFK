
export default ['type', 'source', 'source-layer', 'minzoom', 'maxzoom', 'filter', 'layout'];
