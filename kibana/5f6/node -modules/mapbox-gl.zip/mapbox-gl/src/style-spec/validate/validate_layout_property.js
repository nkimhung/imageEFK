
import validateProperty from './validate_property';

export default function validateLayoutProperty(options) {
    return validateProperty(options, 'layout');
}
