// @flow strict

export type Cancelable = { cancel: () => void };
