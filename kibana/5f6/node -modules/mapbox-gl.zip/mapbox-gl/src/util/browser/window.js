// @flow
/* eslint-env browser */
import type {Window} from '../../types/window';

export default (self: Window);
