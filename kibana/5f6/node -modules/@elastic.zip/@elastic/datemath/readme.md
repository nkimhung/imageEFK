# datemath

Datemath string parser used in Kibana
