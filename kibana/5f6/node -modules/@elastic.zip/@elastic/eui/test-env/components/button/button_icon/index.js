"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiButtonIcon", {
  enumerable: true,
  get: function get() {
    return _button_icon.EuiButtonIcon;
  }
});

var _button_icon = require("./button_icon");