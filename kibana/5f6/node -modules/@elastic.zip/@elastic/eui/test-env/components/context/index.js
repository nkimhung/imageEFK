"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiContext", {
  enumerable: true,
  get: function get() {
    return _context.EuiContext;
  }
});
Object.defineProperty(exports, "EuiI18nConsumer", {
  enumerable: true,
  get: function get() {
    return _context.EuiI18nConsumer;
  }
});

var _context = require("./context");