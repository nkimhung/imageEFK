"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiAvatar", {
  enumerable: true,
  get: function get() {
    return _avatar.EuiAvatar;
  }
});

var _avatar = require("./avatar");