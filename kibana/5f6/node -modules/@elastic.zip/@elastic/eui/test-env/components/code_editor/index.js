"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiCodeEditor", {
  enumerable: true,
  get: function get() {
    return _code_editor.EuiCodeEditor;
  }
});

var _code_editor = require("./code_editor");