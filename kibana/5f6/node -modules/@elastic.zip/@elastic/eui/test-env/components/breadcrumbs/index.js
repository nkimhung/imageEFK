"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiBreadcrumbs", {
  enumerable: true,
  get: function get() {
    return _breadcrumbs.EuiBreadcrumbs;
  }
});

var _breadcrumbs = require("./breadcrumbs");