"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiAccordion", {
  enumerable: true,
  get: function get() {
    return _accordion.EuiAccordion;
  }
});

var _accordion = require("./accordion");