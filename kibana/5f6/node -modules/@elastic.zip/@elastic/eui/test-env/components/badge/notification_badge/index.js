"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiNotificationBadge", {
  enumerable: true,
  get: function get() {
    return _badge_notification.EuiNotificationBadge;
  }
});

var _badge_notification = require("./badge_notification");