"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiButtonGroup", {
  enumerable: true,
  get: function get() {
    return _button_group.EuiButtonGroup;
  }
});

var _button_group = require("./button_group");