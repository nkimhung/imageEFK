"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiColorPalettePicker", {
  enumerable: true,
  get: function get() {
    return _color_palette_picker.EuiColorPalettePicker;
  }
});

var _color_palette_picker = require("./color_palette_picker");