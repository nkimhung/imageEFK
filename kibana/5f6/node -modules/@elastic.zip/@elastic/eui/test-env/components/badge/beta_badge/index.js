"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiBetaBadge", {
  enumerable: true,
  get: function get() {
    return _beta_badge.EuiBetaBadge;
  }
});

var _beta_badge = require("./beta_badge");