"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "COLORS", {
  enumerable: true,
  get: function get() {
    return _button_empty.COLORS;
  }
});
Object.defineProperty(exports, "ICON_SIDES", {
  enumerable: true,
  get: function get() {
    return _button_empty.ICON_SIDES;
  }
});
Object.defineProperty(exports, "EuiButtonEmpty", {
  enumerable: true,
  get: function get() {
    return _button_empty.EuiButtonEmpty;
  }
});

var _button_empty = require("./button_empty");