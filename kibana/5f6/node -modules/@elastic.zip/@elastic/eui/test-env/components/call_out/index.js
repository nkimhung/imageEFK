"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiCallOut", {
  enumerable: true,
  get: function get() {
    return _call_out.EuiCallOut;
  }
});

var _call_out = require("./call_out");