"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiBottomBar", {
  enumerable: true,
  get: function get() {
    return _bottom_bar.EuiBottomBar;
  }
});

var _bottom_bar = require("./bottom_bar");