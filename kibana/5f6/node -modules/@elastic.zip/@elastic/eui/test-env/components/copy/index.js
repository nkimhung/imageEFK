"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiCopy", {
  enumerable: true,
  get: function get() {
    return _copy.EuiCopy;
  }
});

var _copy = require("./copy");