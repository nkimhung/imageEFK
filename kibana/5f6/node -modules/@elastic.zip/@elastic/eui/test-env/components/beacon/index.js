"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiBeacon", {
  enumerable: true,
  get: function get() {
    return _beacon.EuiBeacon;
  }
});

var _beacon = require("./beacon");