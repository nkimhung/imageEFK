"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiAspectRatio", {
  enumerable: true,
  get: function get() {
    return _aspect_ratio.EuiAspectRatio;
  }
});

var _aspect_ratio = require("./aspect_ratio");