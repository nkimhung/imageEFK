"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiCollapsibleNavGroup", {
  enumerable: true,
  get: function get() {
    return _collapsible_nav_group.EuiCollapsibleNavGroup;
  }
});

var _collapsible_nav_group = require("./collapsible_nav_group");