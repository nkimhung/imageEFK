"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiBadgeGroup", {
  enumerable: true,
  get: function get() {
    return _badge_group.EuiBadgeGroup;
  }
});

var _badge_group = require("./badge_group");