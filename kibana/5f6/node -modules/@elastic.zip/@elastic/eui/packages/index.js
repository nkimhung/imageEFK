var ReactDatePicker = require('./react-datepicker').default;

module.exports = {
  ReactDatePicker: ReactDatePicker
};
