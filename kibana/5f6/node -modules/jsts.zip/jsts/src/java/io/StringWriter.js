export default function StringWriter () {}
