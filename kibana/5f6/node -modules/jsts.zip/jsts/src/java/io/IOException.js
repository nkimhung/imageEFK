export default function IOException () {}
