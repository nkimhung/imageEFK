export default function ByteArrayOutputStream () {}
