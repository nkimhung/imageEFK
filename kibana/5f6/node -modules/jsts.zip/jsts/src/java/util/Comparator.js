export default function Comparator () {}
