export default function IllegalArgumentException () {}
