export default function RuntimeException (message) {
  this.message = message
}
