export default function Exception () {}
