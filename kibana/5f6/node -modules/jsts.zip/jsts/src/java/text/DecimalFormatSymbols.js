export default function DecimalFormatSymbols () {}
