import * as quadtree from './index/quadtree'
import * as strtree from './index/strtree'

export { quadtree, strtree }
