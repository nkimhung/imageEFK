function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import dateMath from '@elastic/datemath';
import { i18n } from '@kbn/i18n';
import _ from 'lodash';
import moment from 'moment-timezone';
import { IncompatibleActionError } from '../../../../../src/plugins/ui_actions/public';
import { checkLicense } from '../lib/license_check';
import { ViewMode } from '../../../../../src/plugins/embeddable/public';
import { SEARCH_EMBEDDABLE_TYPE } from '../../../../../src/plugins/discover/public';
import { API_GENERATE_IMMEDIATE, CSV_REPORTING_ACTION } from '../../constants';

function isSavedSearchEmbeddable(embeddable) {
  return embeddable.type === SEARCH_EMBEDDABLE_TYPE;
}

export var GetCsvReportPanelAction = /*#__PURE__*/function () {
  function GetCsvReportPanelAction(core, license$) {
    var _this = this;

    _classCallCheck(this, GetCsvReportPanelAction);

    _defineProperty(this, "isDownloading", void 0);

    _defineProperty(this, "type", '');

    _defineProperty(this, "id", CSV_REPORTING_ACTION);

    _defineProperty(this, "canDownloadCSV", false);

    _defineProperty(this, "core", void 0);

    _defineProperty(this, "isCompatible", /*#__PURE__*/function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(context) {
        var embeddable;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (_this.canDownloadCSV) {
                  _context.next = 2;
                  break;
                }

                return _context.abrupt("return", false);

              case 2:
                embeddable = context.embeddable;
                return _context.abrupt("return", embeddable.getInput().viewMode !== ViewMode.EDIT && embeddable.type === 'search');

              case 4:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }());

    _defineProperty(this, "execute", /*#__PURE__*/function () {
      var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(context) {
        var embeddable, _embeddable$getInput, _embeddable$getInput$, to, from, searchEmbeddable, searchRequestBody, state, kibanaTimezone, id, filename, timezone, fromTime, toTime, body;

        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                embeddable = context.embeddable;

                if (isSavedSearchEmbeddable(embeddable)) {
                  _context2.next = 3;
                  break;
                }

                throw new IncompatibleActionError();

              case 3:
                if (!_this.isDownloading) {
                  _context2.next = 5;
                  break;
                }

                return _context2.abrupt("return");

              case 5:
                _embeddable$getInput = embeddable.getInput(), _embeddable$getInput$ = _embeddable$getInput.timeRange, to = _embeddable$getInput$.to, from = _embeddable$getInput$.from;
                searchEmbeddable = embeddable;
                _context2.next = 9;
                return _this.getSearchRequestBody({
                  searchEmbeddable: searchEmbeddable
                });

              case 9:
                searchRequestBody = _context2.sent;
                state = _.pick(searchRequestBody, ['sort', 'docvalue_fields', 'query']);
                kibanaTimezone = _this.core.uiSettings.get('dateFormat:tz');
                id = "search:".concat(embeddable.getSavedSearch().id);
                filename = embeddable.getTitle();
                timezone = kibanaTimezone === 'Browser' ? moment.tz.guess() : kibanaTimezone;
                fromTime = dateMath.parse(from);
                toTime = dateMath.parse(to);

                if (!(!fromTime || !toTime)) {
                  _context2.next = 19;
                  break;
                }

                return _context2.abrupt("return", _this.onGenerationFail(new Error("Invalid time range: From: ".concat(fromTime, ", To: ").concat(toTime))));

              case 19:
                body = JSON.stringify({
                  timerange: {
                    min: fromTime.format(),
                    max: toTime.format(),
                    timezone: timezone
                  },
                  state: state
                });
                _this.isDownloading = true;

                _this.core.notifications.toasts.addSuccess({
                  title: i18n.translate('xpack.reporting.dashboard.csvDownloadStartedTitle', {
                    defaultMessage: "CSV Download Started"
                  }),
                  text: i18n.translate('xpack.reporting.dashboard.csvDownloadStartedMessage', {
                    defaultMessage: "Your CSV will download momentarily."
                  }),
                  'data-test-subj': 'csvDownloadStarted'
                });

                _context2.next = 24;
                return _this.core.http.post("".concat(API_GENERATE_IMMEDIATE, "/").concat(id), {
                  body: body
                }).then(function (rawResponse) {
                  _this.isDownloading = false;
                  var download = "".concat(filename, ".csv");
                  var blob = new Blob([rawResponse], {
                    type: 'text/csv;charset=utf-8;'
                  }); // Hack for IE11 Support

                  if (window.navigator.msSaveOrOpenBlob) {
                    return window.navigator.msSaveOrOpenBlob(blob, download);
                  }

                  var a = window.document.createElement('a');
                  var downloadObject = window.URL.createObjectURL(blob);
                  a.href = downloadObject;
                  a.download = download;
                  document.body.appendChild(a);
                  a.click();
                  window.URL.revokeObjectURL(downloadObject);
                  document.body.removeChild(a);
                }).catch(_this.onGenerationFail.bind(_this));

              case 24:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }));

      return function (_x2) {
        return _ref2.apply(this, arguments);
      };
    }());

    this.isDownloading = false;
    this.core = core;
    license$.subscribe(function (license) {
      var results = license.check('reporting', 'basic');

      var _checkLicense = checkLicense(results),
          showLinks = _checkLicense.showLinks;

      _this.canDownloadCSV = showLinks;
    });
  }

  _createClass(GetCsvReportPanelAction, [{
    key: "getIconType",
    value: function getIconType() {
      return 'document';
    }
  }, {
    key: "getDisplayName",
    value: function getDisplayName() {
      return i18n.translate('xpack.reporting.dashboard.downloadCsvPanelTitle', {
        defaultMessage: 'Download CSV'
      });
    }
  }, {
    key: "getSearchRequestBody",
    value: function getSearchRequestBody(_ref3) {
      var searchEmbeddable = _ref3.searchEmbeddable;
      var adapters = searchEmbeddable.getInspectorAdapters();

      if (!adapters) {
        return {};
      }

      if (adapters.requests.requests.length === 0) {
        return {};
      }

      return searchEmbeddable.getSavedSearch().searchSource.getSearchRequestBody();
    }
  }, {
    key: "onGenerationFail",
    value: function onGenerationFail(error) {
      this.isDownloading = false;
      this.core.notifications.toasts.addDanger({
        title: i18n.translate('xpack.reporting.dashboard.failedCsvDownloadTitle', {
          defaultMessage: "CSV download failed"
        }),
        text: i18n.translate('xpack.reporting.dashboard.failedCsvDownloadMessage', {
          defaultMessage: "We couldn't generate your CSV at this time."
        }),
        'data-test-subj': 'downloadCsvFail'
      });
    }
  }]);

  return GetCsvReportPanelAction;
}();