/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiCallOut, EuiSpacer } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import { FormattedMessage } from '@kbn/i18n/react';
import React, { Fragment } from 'react';
import { toMountPoint } from '../../../../../src/plugins/kibana_react/public';
export var getFailureToast = function getFailureToast(errorText, job, getManagmenetLink) {
  return {
    title: toMountPoint( /*#__PURE__*/React.createElement(FormattedMessage, {
      id: "xpack.reporting.publicNotifier.error.couldNotCreateReportTitle",
      defaultMessage: "Could not create report for {reportObjectType} '{reportObjectTitle}'.",
      values: {
        reportObjectType: job.type,
        reportObjectTitle: job.title
      }
    })),
    text: toMountPoint( /*#__PURE__*/React.createElement(Fragment, null, /*#__PURE__*/React.createElement(EuiCallOut, {
      size: "m",
      title: i18n.translate('xpack.reporting.publicNotifier.error.calloutTitle', {
        defaultMessage: 'The reporting job failed'
      }),
      color: "danger",
      iconType: "alert"
    }, errorText), /*#__PURE__*/React.createElement(EuiSpacer, null), /*#__PURE__*/React.createElement("p", null, /*#__PURE__*/React.createElement(FormattedMessage, {
      id: "xpack.reporting.publicNotifier.error.checkManagement",
      defaultMessage: "More information is available at {path}.",
      values: {
        path: /*#__PURE__*/React.createElement("a", {
          href: getManagmenetLink()
        }, /*#__PURE__*/React.createElement(FormattedMessage, {
          id: "xpack.reporting.publicNotifier.error.reportingSectionUrlLinkLabel",
          defaultMessage: "Management > Kibana > Reporting"
        }))
      }
    })))),
    iconType: undefined,
    'data-test-subj': 'completeReportFailure'
  };
};