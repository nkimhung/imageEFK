function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiBasicTable, EuiPageContent, EuiSpacer, EuiText, EuiTextColor, EuiTitle } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import { FormattedMessage, injectI18n } from '@kbn/i18n/react';
import { get } from 'lodash';
import moment from 'moment';
import { Component, default as React, Fragment } from 'react';
import { Poller } from '../../common/poller';
import { JobStatuses } from '../../constants';
import { checkLicense } from '../lib/license_check';
import { ReportDeleteButton, ReportDownloadButton, ReportErrorButton, ReportInfoButton } from './buttons';
var jobStatusLabelsMap = new Map([[JobStatuses.PENDING, i18n.translate('xpack.reporting.jobStatuses.pendingText', {
  defaultMessage: 'Pending'
})], [JobStatuses.PROCESSING, i18n.translate('xpack.reporting.jobStatuses.processingText', {
  defaultMessage: 'Processing'
})], [JobStatuses.COMPLETED, i18n.translate('xpack.reporting.jobStatuses.completedText', {
  defaultMessage: 'Completed'
})], [JobStatuses.WARNINGS, i18n.translate('xpack.reporting.jobStatuses.warningText', {
  defaultMessage: 'Completed with warnings'
})], [JobStatuses.FAILED, i18n.translate('xpack.reporting.jobStatuses.failedText', {
  defaultMessage: 'Failed'
})], [JobStatuses.CANCELLED, i18n.translate('xpack.reporting.jobStatuses.cancelledText', {
  defaultMessage: 'Cancelled'
})]]);

var ReportListingUi = /*#__PURE__*/function (_Component) {
  _inherits(ReportListingUi, _Component);

  var _super = _createSuper(ReportListingUi);

  function ReportListingUi(props) {
    var _this;

    _classCallCheck(this, ReportListingUi);

    _this = _super.call(this, props);

    _defineProperty(_assertThisInitialized(_this), "isInitialJobsFetch", void 0);

    _defineProperty(_assertThisInitialized(_this), "licenseSubscription", void 0);

    _defineProperty(_assertThisInitialized(_this), "mounted", void 0);

    _defineProperty(_assertThisInitialized(_this), "poller", void 0);

    _defineProperty(_assertThisInitialized(_this), "licenseHandler", function (license) {
      var _checkLicense = checkLicense(license.check('reporting', 'basic')),
          enableLinks = _checkLicense.enableLinks,
          showLinks = _checkLicense.showLinks,
          badLicenseMessage = _checkLicense.message;

      _this.setState({
        enableLinks: enableLinks,
        showLinks: showLinks,
        badLicenseMessage: badLicenseMessage
      });
    });

    _defineProperty(_assertThisInitialized(_this), "onSelectionChange", function (jobs) {
      _this.setState(function (current) {
        return _objectSpread(_objectSpread({}, current), {}, {
          selectedJobs: jobs
        });
      });
    });

    _defineProperty(_assertThisInitialized(_this), "removeRecord", function (record) {
      var jobs = _this.state.jobs;
      var filtered = jobs.filter(function (j) {
        return j.id !== record.id;
      });

      _this.setState(function (current) {
        return _objectSpread(_objectSpread({}, current), {}, {
          jobs: filtered
        });
      });
    });

    _defineProperty(_assertThisInitialized(_this), "renderDeleteButton", function () {
      var selectedJobs = _this.state.selectedJobs;
      if (selectedJobs.length === 0) return undefined;

      var performDelete = /*#__PURE__*/function () {
        var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
          var _iterator, _step, record;

          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  _iterator = _createForOfIteratorHelper(selectedJobs);
                  _context.prev = 1;

                  _iterator.s();

                case 3:
                  if ((_step = _iterator.n()).done) {
                    _context.next = 18;
                    break;
                  }

                  record = _step.value;
                  _context.prev = 5;
                  _context.next = 8;
                  return _this.props.apiClient.deleteReport(record.id);

                case 8:
                  _this.removeRecord(record);

                  _this.props.toasts.addSuccess(_this.props.intl.formatMessage({
                    id: 'xpack.reporting.listing.table.deleteConfim',
                    defaultMessage: "The {reportTitle} report was deleted"
                  }, {
                    reportTitle: record.object_title
                  }));

                  _context.next = 16;
                  break;

                case 12:
                  _context.prev = 12;
                  _context.t0 = _context["catch"](5);

                  _this.props.toasts.addDanger(_this.props.intl.formatMessage({
                    id: 'xpack.reporting.listing.table.deleteFailedErrorMessage',
                    defaultMessage: "The report was not deleted: {error}"
                  }, {
                    error: _context.t0
                  }));

                  throw _context.t0;

                case 16:
                  _context.next = 3;
                  break;

                case 18:
                  _context.next = 23;
                  break;

                case 20:
                  _context.prev = 20;
                  _context.t1 = _context["catch"](1);

                  _iterator.e(_context.t1);

                case 23:
                  _context.prev = 23;

                  _iterator.f();

                  return _context.finish(23);

                case 26:
                  // Since the contents of the table have changed, we must reset the pagination
                  // and re-fetch. Otherwise, the Nth page we are on could be empty of jobs.
                  _this.setState(function () {
                    return {
                      page: 0
                    };
                  }, _this.fetchJobs);

                case 27:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, null, [[1, 20, 23, 26], [5, 12]]);
        }));

        return function performDelete() {
          return _ref.apply(this, arguments);
        };
      }();

      return /*#__PURE__*/React.createElement(ReportDeleteButton, _extends({
        jobsToDelete: selectedJobs,
        performDelete: performDelete
      }, _this.props));
    });

    _defineProperty(_assertThisInitialized(_this), "onTableChange", function (_ref2) {
      var page = _ref2.page;
      var pageIndex = page.index;

      _this.setState(function () {
        return {
          page: pageIndex
        };
      }, _this.fetchJobs);
    });

    _defineProperty(_assertThisInitialized(_this), "fetchJobs", /*#__PURE__*/_asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
      var jobs, total;
      return regeneratorRuntime.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              // avoid page flicker when poller is updating table - only display loading screen on first load
              if (_this.isInitialJobsFetch) {
                _this.setState(function () {
                  return {
                    isLoading: true
                  };
                });
              }

              _context2.prev = 1;
              _context2.next = 4;
              return _this.props.apiClient.list(_this.state.page);

            case 4:
              jobs = _context2.sent;
              _context2.next = 7;
              return _this.props.apiClient.total();

            case 7:
              total = _context2.sent;
              _this.isInitialJobsFetch = false;
              _context2.next = 20;
              break;

            case 11:
              _context2.prev = 11;
              _context2.t0 = _context2["catch"](1);

              if (_this.licenseAllowsToShowThisPage()) {
                _context2.next = 17;
                break;
              }

              _this.props.toasts.addDanger(_this.state.badLicenseMessage);

              _this.props.redirect('management');

              return _context2.abrupt("return");

            case 17:
              if (_context2.t0.message === 'Failed to fetch') {
                _this.props.toasts.addDanger(_context2.t0.message || _this.props.intl.formatMessage({
                  id: 'xpack.reporting.listing.table.requestFailedErrorMessage',
                  defaultMessage: 'Request failed'
                }));
              }

              if (_this.mounted) {
                _this.setState(function () {
                  return {
                    isLoading: false,
                    jobs: [],
                    total: 0
                  };
                });
              }

              return _context2.abrupt("return");

            case 20:
              if (_this.mounted) {
                _this.setState(function () {
                  return {
                    isLoading: false,
                    total: total,
                    jobs: jobs.map(function (job) {
                      var source = job._source;
                      return {
                        id: job._id,
                        type: source.jobtype,
                        object_type: source.payload.type,
                        object_title: source.payload.title,
                        created_by: source.created_by,
                        created_at: source.created_at,
                        started_at: source.started_at,
                        completed_at: source.completed_at,
                        status: source.status,
                        statusLabel: jobStatusLabelsMap.get(source.status) || source.status,
                        max_size_reached: source.output ? source.output.max_size_reached : false,
                        attempts: source.attempts,
                        max_attempts: source.max_attempts,
                        csv_contains_formulas: get(source, 'output.csv_contains_formulas'),
                        warnings: source.output ? source.output.warnings : undefined
                      };
                    })
                  };
                });
              }

            case 21:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2, null, [[1, 11]]);
    })));

    _defineProperty(_assertThisInitialized(_this), "licenseAllowsToShowThisPage", function () {
      return _this.state.showLinks && _this.state.enableLinks;
    });

    _this.state = {
      page: 0,
      total: 0,
      jobs: [],
      selectedJobs: [],
      isLoading: false,
      showLinks: false,
      enableLinks: false,
      badLicenseMessage: ''
    };
    _this.isInitialJobsFetch = true;
    return _this;
  }

  _createClass(ReportListingUi, [{
    key: "render",
    value: function render() {
      return /*#__PURE__*/React.createElement(EuiPageContent, {
        horizontalPosition: "center",
        className: "euiPageBody--restrictWidth-default"
      }, /*#__PURE__*/React.createElement(EuiTitle, null, /*#__PURE__*/React.createElement("h1", null, /*#__PURE__*/React.createElement(FormattedMessage, {
        id: "xpack.reporting.listing.reportstitle",
        defaultMessage: "Reports"
      }))), /*#__PURE__*/React.createElement(EuiText, {
        color: "subdued",
        size: "s"
      }, /*#__PURE__*/React.createElement("p", null, /*#__PURE__*/React.createElement(FormattedMessage, {
        id: "xpack.reporting.listing.reports.subtitle",
        defaultMessage: "Find reports generated in Kibana applications here"
      }))), /*#__PURE__*/React.createElement(EuiSpacer, null), this.renderTable());
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.mounted = false;
      this.poller.stop();

      if (this.licenseSubscription) {
        this.licenseSubscription.unsubscribe();
      }
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      this.mounted = true;
      this.poller = new Poller({
        functionToPoll: function functionToPoll() {
          return _this2.fetchJobs();
        },
        pollFrequencyInMillis: this.props.pollConfig.jobsRefresh.interval,
        trailing: false,
        continuePollingOnError: true,
        pollFrequencyErrorMultiplier: this.props.pollConfig.jobsRefresh.intervalErrorMultiplier
      });
      this.poller.start();
      this.licenseSubscription = this.props.license$.subscribe(this.licenseHandler);
    }
  }, {
    key: "formatDate",
    value: function formatDate(timestamp) {
      try {
        return moment(timestamp).format('YYYY-MM-DD @ hh:mm A');
      } catch (error) {
        // ignore parse error and display unformatted value
        return timestamp;
      }
    }
  }, {
    key: "renderTable",
    value: function renderTable() {
      var _this3 = this;

      var intl = this.props.intl;
      var tableColumns = [{
        field: 'object_title',
        name: intl.formatMessage({
          id: 'xpack.reporting.listing.tableColumns.reportTitle',
          defaultMessage: 'Report'
        }),
        render: function render(objectTitle, record) {
          return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", null, objectTitle), /*#__PURE__*/React.createElement(EuiText, {
            size: "s"
          }, /*#__PURE__*/React.createElement(EuiTextColor, {
            color: "subdued"
          }, record.object_type)));
        }
      }, {
        field: 'created_at',
        name: intl.formatMessage({
          id: 'xpack.reporting.listing.tableColumns.createdAtTitle',
          defaultMessage: 'Created at'
        }),
        render: function render(createdAt, record) {
          if (record.created_by) {
            return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", null, _this3.formatDate(createdAt)), /*#__PURE__*/React.createElement("span", null, record.created_by));
          }

          return _this3.formatDate(createdAt);
        }
      }, {
        field: 'status',
        name: intl.formatMessage({
          id: 'xpack.reporting.listing.tableColumns.statusTitle',
          defaultMessage: 'Status'
        }),
        render: function render(status, record) {
          if (status === 'pending') {
            return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(FormattedMessage, {
              id: "xpack.reporting.listing.tableValue.statusDetail.pendingStatusReachedText",
              defaultMessage: "Pending - waiting for job to be processed"
            }));
          }

          var maxSizeReached;

          if (record.max_size_reached) {
            maxSizeReached = /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(FormattedMessage, {
              id: "xpack.reporting.listing.tableValue.statusDetail.maxSizeReachedText",
              defaultMessage: " - Max size reached"
            }));
          }

          var warnings;

          if (record.warnings) {
            warnings = /*#__PURE__*/React.createElement(EuiText, {
              size: "s"
            }, /*#__PURE__*/React.createElement(EuiTextColor, {
              color: "subdued"
            }, /*#__PURE__*/React.createElement(FormattedMessage, {
              id: "xpack.reporting.listing.tableValue.statusDetail.warningsText",
              defaultMessage: "Errors occurred: see job info for details."
            })));
          }

          var statusTimestamp;

          if (status === JobStatuses.PROCESSING && record.started_at) {
            statusTimestamp = _this3.formatDate(record.started_at);
          } else if (record.completed_at && [JobStatuses.COMPLETED, JobStatuses.FAILED, JobStatuses.WARNINGS].includes(status)) {
            statusTimestamp = _this3.formatDate(record.completed_at);
          }

          var statusLabel = jobStatusLabelsMap.get(status) || status;

          if (status === JobStatuses.PROCESSING) {
            statusLabel = statusLabel + " (attempt ".concat(record.attempts, " of ").concat(record.max_attempts, ")");
          }

          if (statusTimestamp) {
            return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(FormattedMessage, {
              id: "xpack.reporting.listing.tableValue.statusDetail.statusTimestampText",
              defaultMessage: "{statusLabel} at {statusTimestamp}",
              values: {
                statusLabel: statusLabel,
                statusTimestamp: /*#__PURE__*/React.createElement("span", {
                  className: "eui-textNoWrap"
                }, statusTimestamp)
              }
            }), maxSizeReached, warnings);
          } // unknown status


          return /*#__PURE__*/React.createElement("div", null, statusLabel, maxSizeReached);
        }
      }, {
        name: intl.formatMessage({
          id: 'xpack.reporting.listing.tableColumns.actionsTitle',
          defaultMessage: 'Actions'
        }),
        actions: [{
          render: function render(record) {
            return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(ReportDownloadButton, _extends({}, _this3.props, {
              record: record
            })), /*#__PURE__*/React.createElement(ReportErrorButton, _extends({}, _this3.props, {
              record: record
            })), /*#__PURE__*/React.createElement(ReportInfoButton, _extends({}, _this3.props, {
              jobId: record.id
            })));
          }
        }]
      }];
      var pagination = {
        pageIndex: this.state.page,
        pageSize: 10,
        totalItemCount: this.state.total,
        hidePerPageOptions: true
      };
      var selection = {
        itemId: 'id',
        onSelectionChange: this.onSelectionChange
      };
      return /*#__PURE__*/React.createElement(Fragment, null, /*#__PURE__*/React.createElement(EuiBasicTable, {
        itemId: "id",
        items: this.state.jobs,
        loading: this.state.isLoading,
        columns: tableColumns,
        noItemsMessage: this.state.isLoading ? intl.formatMessage({
          id: 'xpack.reporting.listing.table.loadingReportsDescription',
          defaultMessage: 'Loading reports'
        }) : intl.formatMessage({
          id: 'xpack.reporting.listing.table.noCreatedReportsDescription',
          defaultMessage: 'No reports have been created'
        }),
        pagination: pagination,
        selection: selection,
        isSelectable: true,
        onChange: this.onTableChange,
        "data-test-subj": "reportJobListing",
        "data-test-page": this.state.page
      }), this.state.selectedJobs.length > 0 ? this.renderDeleteButton() : null);
    }
  }]);

  return ReportListingUi;
}(Component);

export var ReportListing = injectI18n(ReportListingUi);