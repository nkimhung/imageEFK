/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { FormattedMessage } from '@kbn/i18n/react';
export var ReportLink = function ReportLink(_ref) {
  var getUrl = _ref.getUrl;
  return /*#__PURE__*/React.createElement(FormattedMessage, {
    id: "xpack.reporting.publicNotifier.reportLink.pickItUpFromPathDescription",
    defaultMessage: "Pick it up from {path}.",
    values: {
      path: /*#__PURE__*/React.createElement("a", {
        href: getUrl()
      }, /*#__PURE__*/React.createElement(FormattedMessage, {
        id: "xpack.reporting.publicNotifier.reportLink.reportingSectionUrlLinkLabel",
        defaultMessage: "Management > Kibana > Reporting"
      }))
    }
  });
};