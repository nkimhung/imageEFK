/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiButtonIcon, EuiToolTip } from '@elastic/eui';
import React from 'react';
import { JobStatuses } from '../../../constants';
export var ReportDownloadButton = function ReportDownloadButton(props) {
  var record = props.record,
      apiClient = props.apiClient,
      intl = props.intl;

  if (record.status !== JobStatuses.COMPLETED && record.status !== JobStatuses.WARNINGS) {
    return null;
  }

  var button = /*#__PURE__*/React.createElement(EuiButtonIcon, {
    onClick: function onClick() {
      return apiClient.downloadReport(record.id);
    },
    iconType: "importAction",
    "aria-label": intl.formatMessage({
      id: 'xpack.reporting.listing.table.downloadReportAriaLabel',
      defaultMessage: 'Download report'
    })
  });

  if (record.csv_contains_formulas) {
    return /*#__PURE__*/React.createElement(EuiToolTip, {
      position: "top",
      content: intl.formatMessage({
        id: 'xpack.reporting.listing.table.csvContainsFormulas',
        defaultMessage: 'Your CSV contains characters which spreadsheet applications can interpret as formulas.'
      })
    }, button);
  }

  if (record.max_size_reached) {
    return /*#__PURE__*/React.createElement(EuiToolTip, {
      position: "top",
      content: intl.formatMessage({
        id: 'xpack.reporting.listing.table.maxSizeReachedTooltip',
        defaultMessage: 'Max size reached, contains partial data.'
      })
    }, button);
  }

  return /*#__PURE__*/React.createElement(EuiToolTip, {
    position: "top",
    content: intl.formatMessage({
      id: 'xpack.reporting.listing.table.downloadReport',
      defaultMessage: 'Download report'
    })
  }, button);
};