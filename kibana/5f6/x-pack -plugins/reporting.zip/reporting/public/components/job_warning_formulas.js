/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { FormattedMessage } from '@kbn/i18n/react';
import React, { Fragment } from 'react';
import { toMountPoint } from '../../../../../src/plugins/kibana_react/public';
import { DownloadButton } from './job_download_button';
import { ReportLink } from './report_link';
export var getWarningFormulasToast = function getWarningFormulasToast(job, getReportLink, getDownloadLink) {
  return {
    title: toMountPoint( /*#__PURE__*/React.createElement(FormattedMessage, {
      id: "xpack.reporting.publicNotifier.csvContainsFormulas.formulaReportTitle",
      defaultMessage: "Report may contain formulas {reportObjectType} '{reportObjectTitle}'",
      values: {
        reportObjectType: job.type,
        reportObjectTitle: job.title
      }
    })),
    text: toMountPoint( /*#__PURE__*/React.createElement(Fragment, null, /*#__PURE__*/React.createElement("p", null, /*#__PURE__*/React.createElement(FormattedMessage, {
      id: "xpack.reporting.publicNotifier.csvContainsFormulas.formulaReportMessage",
      defaultMessage: "The report contains characters which spreadsheet applications can interpret as formulas."
    })), /*#__PURE__*/React.createElement("p", null, /*#__PURE__*/React.createElement(ReportLink, {
      getUrl: getReportLink
    })), /*#__PURE__*/React.createElement(DownloadButton, {
      getUrl: getDownloadLink,
      job: job
    }))),
    'data-test-subj': 'completeReportCsvFormulasWarning'
  };
};