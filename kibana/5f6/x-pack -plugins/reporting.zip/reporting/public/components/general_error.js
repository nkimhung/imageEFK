/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React, { Fragment } from 'react';
import { FormattedMessage } from '@kbn/i18n/react';
import { EuiCallOut, EuiSpacer } from '@elastic/eui';
import { toMountPoint } from '../../../../../src/plugins/kibana_react/public';
export var getGeneralErrorToast = function getGeneralErrorToast(errorText, err) {
  return {
    text: toMountPoint( /*#__PURE__*/React.createElement(Fragment, null, /*#__PURE__*/React.createElement(EuiCallOut, {
      title: errorText,
      color: "danger",
      iconType: "alert"
    }, err.toString()), /*#__PURE__*/React.createElement(EuiSpacer, null), /*#__PURE__*/React.createElement(FormattedMessage, {
      id: "xpack.reporting.publicNotifier.error.tryRefresh",
      defaultMessage: "Try refreshing the page."
    }))),
    iconType: undefined
  };
};