function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { i18n } from '@kbn/i18n';
import moment from 'moment-timezone';
import React from 'react';
import { ReportingPanelContent } from '../components/reporting_panel_content';
import { checkLicense } from '../lib/license_check';
export var csvReportingProvider = function csvReportingProvider(_ref) {
  var apiClient = _ref.apiClient,
      toasts = _ref.toasts,
      license$ = _ref.license$,
      uiSettings = _ref.uiSettings;
  var toolTipContent = '';
  var disabled = true;
  var hasCSVReporting = false;
  license$.subscribe(function (license) {
    var _checkLicense = checkLicense(license.check('reporting', 'basic')),
        enableLinks = _checkLicense.enableLinks,
        showLinks = _checkLicense.showLinks,
        message = _checkLicense.message;

    toolTipContent = message;
    hasCSVReporting = showLinks;
    disabled = !enableLinks;
  }); // If the TZ is set to the default "Browser", it will not be useful for
  // server-side export. We need to derive the timezone and pass it as a param
  // to the export API.

  var browserTimezone = uiSettings.get('dateFormat:tz') === 'Browser' ? moment.tz.guess() : uiSettings.get('dateFormat:tz');

  var getShareMenuItems = function getShareMenuItems(_ref2) {
    var objectType = _ref2.objectType,
        objectId = _ref2.objectId,
        sharingData = _ref2.sharingData,
        isDirty = _ref2.isDirty,
        onClose = _ref2.onClose;

    if ('search' !== objectType) {
      return [];
    }

    var jobParams = {
      browserTimezone: browserTimezone,
      objectType: objectType,
      title: sharingData.title,
      indexPatternId: sharingData.indexPatternId,
      searchRequest: sharingData.searchRequest,
      fields: sharingData.fields,
      metaFields: sharingData.metaFields,
      conflictedTypesFields: sharingData.conflictedTypesFields
    };

    var getJobParams = function getJobParams() {
      return jobParams;
    };

    var shareActions = [];

    if (hasCSVReporting) {
      var _shareMenuItem;

      var panelTitle = i18n.translate('xpack.reporting.shareContextMenu.csvReportsButtonLabel', {
        defaultMessage: 'CSV Reports'
      });
      shareActions.push({
        shareMenuItem: (_shareMenuItem = {
          name: panelTitle,
          icon: 'document',
          toolTipContent: toolTipContent,
          disabled: disabled
        }, _defineProperty(_shareMenuItem, 'data-test-subj', 'csvReportMenuItem'), _defineProperty(_shareMenuItem, "sortOrder", 1), _shareMenuItem),
        panel: {
          id: 'csvReportingPanel',
          title: panelTitle,
          content: /*#__PURE__*/React.createElement(ReportingPanelContent, {
            apiClient: apiClient,
            toasts: toasts,
            reportType: "csv",
            layoutId: undefined,
            objectType: objectType,
            objectId: objectId,
            getJobParams: getJobParams,
            isDirty: isDirty,
            onClose: onClose
          })
        }
      });
    }

    return shareActions;
  };

  return {
    id: 'csvReports',
    getShareMenuItems: getShareMenuItems
  };
};