function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { i18n } from '@kbn/i18n';
import moment from 'moment-timezone';
import React from 'react';
import { ScreenCapturePanelContent } from '../components/screen_capture_panel_content';
import { checkLicense } from '../lib/license_check';
export var reportingPDFPNGProvider = function reportingPDFPNGProvider(_ref) {
  var apiClient = _ref.apiClient,
      toasts = _ref.toasts,
      license$ = _ref.license$,
      uiSettings = _ref.uiSettings;
  var toolTipContent = '';
  var disabled = true;
  var hasPDFPNGReporting = false;
  license$.subscribe(function (license) {
    var _checkLicense = checkLicense(license.check('reporting', 'gold')),
        enableLinks = _checkLicense.enableLinks,
        showLinks = _checkLicense.showLinks,
        message = _checkLicense.message;

    toolTipContent = message;
    hasPDFPNGReporting = showLinks;
    disabled = !enableLinks;
  }); // If the TZ is set to the default "Browser", it will not be useful for
  // server-side export. We need to derive the timezone and pass it as a param
  // to the export API.

  var browserTimezone = uiSettings.get('dateFormat:tz') === 'Browser' ? moment.tz.guess() : uiSettings.get('dateFormat:tz');

  var getShareMenuItems = function getShareMenuItems(_ref2) {
    var objectType = _ref2.objectType,
        objectId = _ref2.objectId,
        sharingData = _ref2.sharingData,
        isDirty = _ref2.isDirty,
        onClose = _ref2.onClose,
        shareableUrl = _ref2.shareableUrl;

    if (!['dashboard', 'visualization'].includes(objectType)) {
      return [];
    } // Dashboard only mode does not currently support reporting
    // https://github.com/elastic/kibana/issues/18286
    // @TODO For NP


    if (objectType === 'dashboard' && false) {
      return [];
    }

    var getPdfJobParams = function getPdfJobParams() {
      // Relative URL must have URL prefix (Spaces ID prefix), but not server basePath
      // Replace hashes with original RISON values.
      var relativeUrl = shareableUrl.replace(window.location.origin + apiClient.getServerBasePath(), '');
      return {
        objectType: objectType,
        browserTimezone: browserTimezone,
        relativeUrls: [relativeUrl],
        // multi URL for PDF
        layout: sharingData.layout,
        title: sharingData.title
      };
    };

    var getPngJobParams = function getPngJobParams() {
      // Replace hashes with original RISON values.
      var relativeUrl = shareableUrl.replace(window.location.origin + apiClient.getServerBasePath(), '');
      return {
        objectType: objectType,
        browserTimezone: browserTimezone,
        relativeUrl: relativeUrl,
        // single URL for PNG
        layout: sharingData.layout,
        title: sharingData.title
      };
    };

    var shareActions = [];

    if (hasPDFPNGReporting) {
      var _shareMenuItem, _shareMenuItem2;

      var pngPanelTitle = i18n.translate('xpack.reporting.shareContextMenu.pngReportsButtonLabel', {
        defaultMessage: 'PNG Reports'
      });
      var pdfPanelTitle = i18n.translate('xpack.reporting.shareContextMenu.pdfReportsButtonLabel', {
        defaultMessage: 'PDF Reports'
      });
      shareActions.push({
        shareMenuItem: (_shareMenuItem = {
          name: pngPanelTitle,
          icon: 'document',
          toolTipContent: toolTipContent,
          disabled: disabled
        }, _defineProperty(_shareMenuItem, 'data-test-subj', 'pngReportMenuItem'), _defineProperty(_shareMenuItem, "sortOrder", 10), _shareMenuItem),
        panel: {
          id: 'reportingPngPanel',
          title: pngPanelTitle,
          content: /*#__PURE__*/React.createElement(ScreenCapturePanelContent, {
            apiClient: apiClient,
            toasts: toasts,
            reportType: "png",
            objectType: objectType,
            objectId: objectId,
            getJobParams: getPngJobParams,
            isDirty: isDirty,
            onClose: onClose
          })
        }
      });
      shareActions.push({
        shareMenuItem: (_shareMenuItem2 = {
          name: pdfPanelTitle,
          icon: 'document',
          toolTipContent: toolTipContent,
          disabled: disabled
        }, _defineProperty(_shareMenuItem2, 'data-test-subj', 'pdfReportMenuItem'), _defineProperty(_shareMenuItem2, "sortOrder", 10), _shareMenuItem2),
        panel: {
          id: 'reportingPdfPanel',
          title: pdfPanelTitle,
          content: /*#__PURE__*/React.createElement(ScreenCapturePanelContent, {
            apiClient: apiClient,
            toasts: toasts,
            reportType: "printablePdf",
            objectType: objectType,
            objectId: objectId,
            getJobParams: getPdfJobParams,
            isDirty: isDirty,
            onClose: onClose
          })
        }
      });
    }

    return shareActions;
  };

  return {
    id: 'screenCaptureReports',
    getShareMenuItems: getShareMenuItems
  };
};