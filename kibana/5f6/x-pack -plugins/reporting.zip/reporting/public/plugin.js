function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { i18n } from '@kbn/i18n';
import { I18nProvider } from '@kbn/i18n/react';
import React from 'react';
import ReactDOM from 'react-dom';
import * as Rx from 'rxjs';
import { catchError, filter, map, mergeMap, takeUntil } from 'rxjs/operators';
import { CONTEXT_MENU_TRIGGER } from '../../../../src/plugins/embeddable/public';
import { FeatureCatalogueCategory } from '../../../../src/plugins/home/public';
import { JOB_COMPLETION_NOTIFICATIONS_SESSION_KEY } from '../constants';
import { getGeneralErrorToast } from './components';
import { ReportListing } from './components/report_listing';
import { ReportingAPIClient } from './lib/reporting_api_client';
import { ReportingNotifierStreamHandler as StreamHandler } from './lib/stream_handler';
import { GetCsvReportPanelAction } from './panel_actions/get_csv_panel_action';
import { csvReportingProvider } from './share_context_menu/register_csv_reporting';
import { reportingPDFPNGProvider } from './share_context_menu/register_pdf_png_reporting';

function getStored() {
  var sessionValue = sessionStorage.getItem(JOB_COMPLETION_NOTIFICATIONS_SESSION_KEY);
  return sessionValue ? JSON.parse(sessionValue) : [];
}

function handleError(notifications, err) {
  notifications.toasts.addDanger(getGeneralErrorToast(i18n.translate('xpack.reporting.publicNotifier.pollingErrorMessage', {
    defaultMessage: 'Reporting notifier error!'
  }), err));
  window.console.error(err);
  return Rx.of({
    completed: [],
    failed: []
  });
}

export var ReportingPublicPlugin = /*#__PURE__*/function () {
  function ReportingPublicPlugin(initializerContext) {
    _classCallCheck(this, ReportingPublicPlugin);

    _defineProperty(this, "config", void 0);

    _defineProperty(this, "stop$", new Rx.ReplaySubject(1));

    _defineProperty(this, "title", i18n.translate('xpack.reporting.management.reportingTitle', {
      defaultMessage: 'Reporting'
    }));

    _defineProperty(this, "breadcrumbText", i18n.translate('xpack.reporting.breadcrumb', {
      defaultMessage: 'Reporting'
    }));

    this.config = initializerContext.config.get();
  }

  _createClass(ReportingPublicPlugin, [{
    key: "setup",
    value: function setup(core, _ref) {
      var _this = this;

      var home = _ref.home,
          management = _ref.management,
          licensing = _ref.licensing,
          uiActions = _ref.uiActions,
          share = _ref.share;
      var http = core.http,
          toasts = core.notifications.toasts,
          getStartServices = core.getStartServices,
          uiSettings = core.uiSettings;
      var license$ = licensing.license$;
      var apiClient = new ReportingAPIClient(http);
      var action = new GetCsvReportPanelAction(core, license$);
      home.featureCatalogue.register({
        id: 'reporting',
        title: i18n.translate('xpack.reporting.registerFeature.reportingTitle', {
          defaultMessage: 'Reporting'
        }),
        description: i18n.translate('xpack.reporting.registerFeature.reportingDescription', {
          defaultMessage: 'Manage your reports generated from Discover, Visualize, and Dashboard.'
        }),
        icon: 'reportingApp',
        path: '/app/management/insightsAndAlerting/reporting',
        showOnHomePage: false,
        category: FeatureCatalogueCategory.ADMIN
      });
      management.sections.section.insightsAndAlerting.registerApp({
        id: 'reporting',
        title: this.title,
        order: 1,
        mount: function () {
          var _mount = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(params) {
            var _yield$getStartServic, _yield$getStartServic2, start;

            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return getStartServices();

                  case 2:
                    _yield$getStartServic = _context.sent;
                    _yield$getStartServic2 = _slicedToArray(_yield$getStartServic, 1);
                    start = _yield$getStartServic2[0];
                    params.setBreadcrumbs([{
                      text: _this.breadcrumbText
                    }]);
                    ReactDOM.render( /*#__PURE__*/React.createElement(I18nProvider, null, /*#__PURE__*/React.createElement(ReportListing, {
                      toasts: toasts,
                      license$: license$,
                      pollConfig: _this.config.poll,
                      redirect: start.application.navigateToApp,
                      apiClient: apiClient
                    })), params.element);
                    return _context.abrupt("return", function () {
                      ReactDOM.unmountComponentAtNode(params.element);
                    });

                  case 8:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee);
          }));

          function mount(_x) {
            return _mount.apply(this, arguments);
          }

          return mount;
        }()
      });
      uiActions.addTriggerAction(CONTEXT_MENU_TRIGGER, action);
      share.register(csvReportingProvider({
        apiClient: apiClient,
        toasts: toasts,
        license$: license$,
        uiSettings: uiSettings
      }));
      share.register(reportingPDFPNGProvider({
        apiClient: apiClient,
        toasts: toasts,
        license$: license$,
        uiSettings: uiSettings
      }));
    }
  }, {
    key: "start",
    value: function start(core) {
      var http = core.http,
          notifications = core.notifications;
      var apiClient = new ReportingAPIClient(http);
      var streamHandler = new StreamHandler(notifications, apiClient);
      var interval = this.config.poll.jobsRefresh.interval;
      Rx.timer(0, interval).pipe(takeUntil(this.stop$), // stop the interval when stop method is called
      map(function () {
        return getStored();
      }), // read all pending job IDs from session storage
      filter(function (storedJobs) {
        return storedJobs.length > 0;
      }), // stop the pipeline here if there are none pending
      mergeMap(function (storedJobs) {
        return streamHandler.findChangedStatusJobs(storedJobs);
      }), // look up the latest status of all pending jobs on the server
      mergeMap(function (_ref2) {
        var completed = _ref2.completed,
            failed = _ref2.failed;
        return streamHandler.showNotifications({
          completed: completed,
          failed: failed
        });
      }), catchError(function (err) {
        return handleError(notifications, err);
      })).subscribe();
    }
  }, {
    key: "stop",
    value: function stop() {
      this.stop$.next();
    }
  }]);

  return ReportingPublicPlugin;
}();