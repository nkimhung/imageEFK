"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ReportingCore = void 0;

var Rx = _interopRequireWildcard(require("rxjs"));

var _operators = require("rxjs/operators");

var _screenshots = require("./lib/screenshots");

var _lib = require("./lib");

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function () { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class ReportingCore {
  // observe async background setupDeps and config each are done
  // observe async background startDeps
  constructor() {
    _defineProperty(this, "pluginSetupDeps", void 0);

    _defineProperty(this, "pluginStartDeps", void 0);

    _defineProperty(this, "pluginSetup$", new Rx.ReplaySubject());

    _defineProperty(this, "pluginStart$", new Rx.ReplaySubject());

    _defineProperty(this, "exportTypesRegistry", (0, _lib.getExportTypesRegistry)());

    _defineProperty(this, "config", void 0);
  }
  /*
   * Register setupDeps
   */


  pluginSetup(setupDeps) {
    this.pluginSetup$.next(true); // trigger the observer

    this.pluginSetupDeps = setupDeps; // cache
  }
  /*
   * Register startDeps
   */


  pluginStart(startDeps) {
    this.pluginStart$.next(startDeps); // trigger the observer

    this.pluginStartDeps = startDeps; // cache
  }
  /*
   * Blocks the caller until setup is done
   */


  async pluginSetsUp() {
    // use deps and config as a cached resolver
    if (this.pluginSetupDeps && this.config) {
      return true;
    }

    return await this.pluginSetup$.pipe((0, _operators.take)(2)).toPromise(); // once for pluginSetupDeps (sync) and twice for config (async)
  }
  /*
   * Blocks the caller until start is done
   */


  async pluginStartsUp() {
    return await this.getPluginStartDeps().then(() => true);
  }
  /*
   * Synchronously checks if all async background setup and startup is completed
   */


  pluginIsStarted() {
    return this.pluginSetupDeps != null && this.config != null && this.pluginStartDeps != null;
  }
  /*
   * Allows config to be set in the background
   */


  setConfig(config) {
    this.config = config;
    this.pluginSetup$.next(true);
  }
  /*
   * Gives synchronous access to the config
   */


  getConfig() {
    if (!this.config) {
      throw new Error('Config is not yet initialized');
    }

    return this.config;
  }
  /*
   * Gives async access to the startDeps
   */


  async getPluginStartDeps() {
    if (this.pluginStartDeps) {
      return this.pluginStartDeps;
    }

    return await this.pluginStart$.pipe((0, _operators.first)()).toPromise();
  }

  getExportTypesRegistry() {
    return this.exportTypesRegistry;
  }

  async getEsqueue() {
    return (await this.getPluginStartDeps()).esqueue;
  }

  async getEnqueueJob() {
    return (await this.getPluginStartDeps()).enqueueJob;
  }

  async getLicenseInfo() {
    const {
      licensing
    } = this.getPluginSetupDeps();
    return await licensing.license$.pipe((0, _operators.map)(license => (0, _lib.checkLicense)(this.getExportTypesRegistry(), license)), (0, _operators.first)()).toPromise();
  }

  async getScreenshotsObservable() {
    const config = this.getConfig();
    const {
      browserDriverFactory
    } = await this.getPluginStartDeps();
    return (0, _screenshots.screenshotsObservableFactory)(config.get('capture'), browserDriverFactory);
  }
  /*
   * Gives synchronous access to the setupDeps
   */


  getPluginSetupDeps() {
    if (!this.pluginSetupDeps) {
      throw new Error(`"pluginSetupDeps" dependencies haven't initialized yet`);
    }

    return this.pluginSetupDeps;
  }

  getElasticsearchService() {
    return this.getPluginSetupDeps().elasticsearch;
  }

  async getSavedObjectsClient(fakeRequest) {
    const {
      savedObjects
    } = await this.getPluginStartDeps();
    return savedObjects.getScopedClient(fakeRequest);
  }

  async getUiSettingsServiceFactory(savedObjectsClient) {
    const {
      uiSettings: uiSettingsService
    } = await this.getPluginStartDeps();
    const scopedUiSettingsService = uiSettingsService.asScopedToClient(savedObjectsClient);
    return scopedUiSettingsService;
  }

}

exports.ReportingCore = ReportingCore;