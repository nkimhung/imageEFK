"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "ConfigSchema", {
  enumerable: true,
  get: function () {
    return _schema.ConfigSchema;
  }
});
Object.defineProperty(exports, "ReportingConfigType", {
  enumerable: true,
  get: function () {
    return _schema.ReportingConfigType;
  }
});
Object.defineProperty(exports, "buildConfig", {
  enumerable: true,
  get: function () {
    return _config.buildConfig;
  }
});
exports.config = void 0;

var _schema = require("./schema");

var _config = require("./config");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
const config = {
  exposeToBrowser: {
    poll: true
  },
  schema: _schema.ConfigSchema,
  deprecations: ({
    unused
  }) => [unused('capture.browser.chromium.maxScreenshotDimension'), unused('capture.concurrency'), unused('capture.settleTime'), unused('capture.timeout'), unused('kibanaApp')]
};
exports.config = config;