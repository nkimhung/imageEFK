"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.createMockReportingCore = exports.createMockStartDeps = exports.createMockConfigSchema = void 0;

var Rx = _interopRequireWildcard(require("rxjs"));

var _ = require("../");

var _browsers = require("../browsers");

var _lib = require("../lib");

var _create_mock_levellogger = require("./create_mock_levellogger");

var _store = require("../lib/store");

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function () { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
jest.mock('../routes');
jest.mock('../usage');
jest.mock('../browsers');
jest.mock('../lib/create_queue');
jest.mock('../lib/enqueue_job');
jest.mock('../lib/validate');

_browsers.initializeBrowserDriverFactory.mockImplementation(() => Promise.resolve({}));

_browsers.chromium.createDriverFactory.mockImplementation(() => ({}));

const createMockPluginSetup = setupMock => {
  return {
    elasticsearch: setupMock.elasticsearch || {
      legacy: {
        client: {}
      }
    },
    basePath: setupMock.basePath,
    router: setupMock.router,
    security: setupMock.security,
    licensing: {
      license$: Rx.of({
        isAvailable: true,
        isActive: true,
        type: 'basic'
      })
    }
  };
};

const createMockPluginStart = (mockReportingCore, startMock) => {
  const logger = (0, _create_mock_levellogger.createMockLevelLogger)();
  const store = new _lib.ReportingStore(mockReportingCore, logger);
  return {
    browserDriverFactory: startMock.browserDriverFactory,
    enqueueJob: startMock.enqueueJob || jest.fn().mockResolvedValue(new _store.Report({})),
    esqueue: startMock.esqueue,
    savedObjects: startMock.savedObjects || {
      getScopedClient: jest.fn()
    },
    uiSettings: startMock.uiSettings || {
      asScopedToClient: () => ({
        get: jest.fn()
      })
    },
    store
  };
};

const createMockConfigSchema = overrides => ({
  index: '.reporting',
  kibanaServer: {
    hostname: 'localhost',
    port: '80'
  },
  capture: {
    browser: {
      chromium: {
        disableSandbox: true
      }
    }
  },
  ...overrides
});

exports.createMockConfigSchema = createMockConfigSchema;

const createMockStartDeps = startMock => ({
  data: startMock.data
});

exports.createMockStartDeps = createMockStartDeps;

const createMockReportingCore = async (config, setupDepsMock = undefined, startDepsMock = undefined) => {
  if (!setupDepsMock) {
    setupDepsMock = createMockPluginSetup({});
  }

  const mockReportingCore = {
    getConfig: () => config,
    getElasticsearchService: () => {
      var _setupDepsMock;

      return (_setupDepsMock = setupDepsMock) === null || _setupDepsMock === void 0 ? void 0 : _setupDepsMock.elasticsearch;
    }
  };

  if (!startDepsMock) {
    startDepsMock = createMockPluginStart(mockReportingCore, {});
  }

  config = config || {};
  const core = new _.ReportingCore();
  core.pluginSetup(setupDepsMock);
  core.setConfig(config);
  await core.pluginSetsUp();
  core.pluginStart(startDepsMock);
  await core.pluginStartsUp();
  return core;
};

exports.createMockReportingCore = createMockReportingCore;