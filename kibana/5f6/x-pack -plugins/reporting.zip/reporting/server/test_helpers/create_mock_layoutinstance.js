"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.createMockLayoutInstance = void 0;

var _layouts = require("../lib/layouts");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
const createMockLayoutInstance = captureConfig => {
  const mockLayout = (0, _layouts.createLayout)(captureConfig, {
    id: _layouts.LayoutTypes.PRESERVE_LAYOUT,
    dimensions: {
      height: 100,
      width: 100
    }
  });
  mockLayout.selectors = {
    renderComplete: 'renderedSelector',
    itemsCountAttribute: 'itemsSelector',
    screenshot: 'screenshotSelector',
    timefilterDurationAttribute: 'timefilterDurationSelector'
  };
  return mockLayout;
};

exports.createMockLayoutInstance = createMockLayoutInstance;