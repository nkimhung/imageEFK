"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "registerReportingUsageCollector", {
  enumerable: true,
  get: function () {
    return _reporting_usage_collector.registerReportingUsageCollector;
  }
});

var _reporting_usage_collector = require("./reporting_usage_collector");