"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.chromium = void 0;

var _driver_factory = require("./driver_factory");

var _paths = require("./paths");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
const chromium = {
  paths: _paths.paths,
  createDriverFactory: (binaryPath, captureConfig, logger) => new _driver_factory.HeadlessChromiumDriverFactory(binaryPath, captureConfig, logger)
};
exports.chromium = chromium;