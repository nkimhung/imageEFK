"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "HeadlessChromiumDriver", {
  enumerable: true,
  get: function () {
    return _chromium_driver.HeadlessChromiumDriver;
  }
});

var _chromium_driver = require("./chromium_driver");