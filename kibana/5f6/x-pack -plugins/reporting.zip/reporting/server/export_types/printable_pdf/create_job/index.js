"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.scheduleTaskFnFactory = void 0;

var _lib = require("../../../lib");

var _common = require("../../common");

var _compatibility_shim = require("./compatibility_shim");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
// @ts-ignore no module def (deprecated module)
const scheduleTaskFnFactory = function createJobFactoryFn(reporting, logger) {
  const config = reporting.getConfig();
  const crypto = (0, _lib.cryptoFactory)(config.get('encryptionKey'));
  const compatibilityShim = (0, _compatibility_shim.compatibilityShimFactory)(logger);
  return compatibilityShim(async function createJobFn({
    title,
    relativeUrls,
    browserTimezone,
    layout,
    objectType
  }, context, req) {
    const serializedEncryptedHeaders = await crypto.encrypt(req.headers);
    (0, _common.validateUrls)(relativeUrls);
    return {
      basePath: config.kbnConfig.get('server', 'basePath'),
      browserTimezone,
      forceNow: new Date().toISOString(),
      headers: serializedEncryptedHeaders,
      layout,
      objects: relativeUrls.map(u => ({
        relativeUrl: u
      })),
      title,
      type: objectType // Note: this changes the shape of the job params object

    };
  });
};

exports.scheduleTaskFnFactory = scheduleTaskFnFactory;