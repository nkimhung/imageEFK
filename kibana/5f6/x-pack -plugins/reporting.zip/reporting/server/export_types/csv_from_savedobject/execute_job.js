"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.runTaskFnFactory = void 0;

var _common = require("../../../common");

var _constants = require("../../../common/constants");

var _generate_csv = require("../csv/generate_csv");

var _get_fake_request = require("./lib/get_fake_request");

var _get_csv_job = require("./lib/get_csv_job");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
const runTaskFnFactory = function executeJobFactoryFn(reporting, parentLogger) {
  const config = reporting.getConfig();
  const logger = parentLogger.clone([_constants.CSV_FROM_SAVEDOBJECT_JOB_TYPE, 'execute-job']);
  return async function runTask(jobId, jobPayload, context, req) {
    // There will not be a jobID for "immediate" generation.
    // jobID is only for "queued" jobs
    // Use the jobID as a logging tag or "immediate"
    const {
      jobParams
    } = jobPayload;
    const jobLogger = logger.clone([jobId === null ? 'immediate' : jobId]);
    const generateCsv = (0, _generate_csv.createGenerateCsv)(jobLogger);
    const {
      isImmediate,
      panel,
      visType
    } = jobParams;
    jobLogger.debug(`Execute job generating [${visType}] csv`);

    if (isImmediate && req) {
      jobLogger.info(`Executing job from Immediate API using request context`);
    } else {
      jobLogger.info(`Executing job async using encrypted headers`);
      req = await (0, _get_fake_request.getFakeRequest)(jobPayload, config.get('encryptionKey'), jobLogger);
    }

    const savedObjectsClient = context.core.savedObjects.client;
    const uiConfig = await reporting.getUiSettingsServiceFactory(savedObjectsClient);
    const job = await (0, _get_csv_job.getGenerateCsvParams)(jobParams, panel, savedObjectsClient, uiConfig);
    const elasticsearch = reporting.getElasticsearchService();
    const {
      callAsCurrentUser
    } = elasticsearch.legacy.client.asScoped(req);
    const {
      content,
      maxSizeReached,
      size,
      csvContainsFormulas,
      warnings
    } = await generateCsv(job, config, uiConfig, callAsCurrentUser, new _common.CancellationToken() // can not be cancelled
    );

    if (csvContainsFormulas) {
      jobLogger.warn(`CSV may contain formulas whose values have been escaped`);
    }

    if (maxSizeReached) {
      jobLogger.warn(`Max size reached: CSV output truncated to ${size} bytes`);
    }

    return {
      content_type: _constants.CONTENT_TYPE_CSV,
      content,
      max_size_reached: maxSizeReached,
      size,
      csv_contains_formulas: csvContainsFormulas,
      warnings
    };
  };
};

exports.runTaskFnFactory = runTaskFnFactory;