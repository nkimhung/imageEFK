"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.scheduleTaskFnFactory = void 0;

var _boom = require("boom");

var _lodash = require("lodash");

var _constants = require("../../../common/constants");

var _lib = require("../../lib");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
const scheduleTaskFnFactory = function createJobFactoryFn(reporting, parentLogger) {
  const config = reporting.getConfig();
  const crypto = (0, _lib.cryptoFactory)(config.get('encryptionKey'));
  const logger = parentLogger.clone([_constants.CSV_FROM_SAVEDOBJECT_JOB_TYPE, 'create-job']);
  return async function scheduleTask(jobParams, headers, context, req) {
    const {
      savedObjectType,
      savedObjectId
    } = jobParams;
    const serializedEncryptedHeaders = await crypto.encrypt(headers);
    const {
      panel,
      title,
      visType
    } = await Promise.resolve().then(() => context.core.savedObjects.client.get(savedObjectType, savedObjectId)).then(async savedObject => {
      const {
        attributes,
        references
      } = savedObject;
      const {
        kibanaSavedObjectMeta: kibanaSavedObjectMetaJSON
      } = attributes;
      const {
        timerange
      } = req.body;

      if (!kibanaSavedObjectMetaJSON) {
        throw new Error('Could not parse saved object data!');
      }

      const kibanaSavedObjectMeta = { ...kibanaSavedObjectMetaJSON,
        searchSource: JSON.parse(kibanaSavedObjectMetaJSON.searchSourceJSON)
      };
      const {
        visState: visStateJSON
      } = attributes;

      if (visStateJSON) {
        throw (0, _boom.notImplemented)('Visualization types are not yet implemented');
      } // saved search type


      const {
        searchSource
      } = kibanaSavedObjectMeta;

      if (!searchSource || !references) {
        throw new Error('The saved search object is missing configuration fields!');
      }

      const indexPatternMeta = references.find(ref => ref.type === 'index-pattern');

      if (!indexPatternMeta) {
        throw new Error('Could not find index pattern for the saved search!');
      }

      const sPanel = {
        attributes: { ...attributes,
          kibanaSavedObjectMeta: {
            searchSource
          }
        },
        indexPatternSavedObjectId: indexPatternMeta.id,
        timerange
      };
      return {
        panel: sPanel,
        title: attributes.title,
        visType: 'search'
      };
    }).catch(err => {
      const boomErr = err;

      if (boomErr.isBoom) {
        throw err;
      }

      const errPayload = (0, _lodash.get)(err, 'output.payload', {
        statusCode: 0
      });

      if (errPayload.statusCode === 404) {
        throw (0, _boom.notFound)(errPayload.message);
      }

      if (err.stack) {
        logger.error(err.stack);
      }

      throw new Error(`Unable to create a job from saved object data! Error: ${err}`);
    });
    return {
      headers: serializedEncryptedHeaders,
      jobParams: { ...jobParams,
        panel,
        visType
      },
      type: visType,
      title
    };
  };
};

exports.scheduleTaskFnFactory = scheduleTaskFnFactory;