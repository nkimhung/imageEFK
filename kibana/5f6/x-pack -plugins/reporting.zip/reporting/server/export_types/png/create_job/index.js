"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.scheduleTaskFnFactory = void 0;

var _lib = require("../../../lib");

var _common = require("../../common");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
const scheduleTaskFnFactory = function createJobFactoryFn(reporting) {
  const config = reporting.getConfig();
  const crypto = (0, _lib.cryptoFactory)(config.get('encryptionKey'));
  return async function scheduleTask({
    objectType,
    title,
    relativeUrl,
    browserTimezone,
    layout
  }, context, req) {
    const serializedEncryptedHeaders = await crypto.encrypt(req.headers);
    (0, _common.validateUrls)([relativeUrl]);
    return {
      objectType,
      title,
      relativeUrl,
      headers: serializedEncryptedHeaders,
      browserTimezone,
      layout,
      basePath: config.kbnConfig.get('server', 'basePath'),
      forceNow: new Date().toISOString()
    };
  };
};

exports.scheduleTaskFnFactory = scheduleTaskFnFactory;