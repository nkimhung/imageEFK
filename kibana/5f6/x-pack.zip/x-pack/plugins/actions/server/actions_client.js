"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ActionsClient = exports.MAX_ACTIONS_RETURNED = void 0;

var _boom = _interopRequireDefault(require("boom"));

var _i18n = require("@kbn/i18n");

var _lib = require("./lib");

var _preconfigured_action_disabled_modification = require("./lib/errors/preconfigured_action_disabled_modification");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// We are assuming there won't be many actions. This is why we will load
// all the actions in advance and assume the total count to not go over 10000.
// We'll set this max setting assuming it's never reached.
const MAX_ACTIONS_RETURNED = 10000;
exports.MAX_ACTIONS_RETURNED = MAX_ACTIONS_RETURNED;

class ActionsClient {
  constructor({
    actionTypeRegistry,
    defaultKibanaIndex,
    scopedClusterClient,
    savedObjectsClient,
    preconfiguredActions,
    actionExecutor,
    executionEnqueuer,
    request
  }) {
    _defineProperty(this, "defaultKibanaIndex", void 0);

    _defineProperty(this, "scopedClusterClient", void 0);

    _defineProperty(this, "savedObjectsClient", void 0);

    _defineProperty(this, "actionTypeRegistry", void 0);

    _defineProperty(this, "preconfiguredActions", void 0);

    _defineProperty(this, "actionExecutor", void 0);

    _defineProperty(this, "request", void 0);

    _defineProperty(this, "executionEnqueuer", void 0);

    this.actionTypeRegistry = actionTypeRegistry;
    this.savedObjectsClient = savedObjectsClient;
    this.scopedClusterClient = scopedClusterClient;
    this.defaultKibanaIndex = defaultKibanaIndex;
    this.preconfiguredActions = preconfiguredActions;
    this.actionExecutor = actionExecutor;
    this.executionEnqueuer = executionEnqueuer;
    this.request = request;
  }
  /**
   * Create an action
   */


  async create({
    action
  }) {
    const {
      actionTypeId,
      name,
      config,
      secrets
    } = action;
    const actionType = this.actionTypeRegistry.get(actionTypeId);
    const validatedActionTypeConfig = (0, _lib.validateConfig)(actionType, config);
    const validatedActionTypeSecrets = (0, _lib.validateSecrets)(actionType, secrets);
    this.actionTypeRegistry.ensureActionTypeEnabled(actionTypeId);
    const result = await this.savedObjectsClient.create('action', {
      actionTypeId,
      name,
      config: validatedActionTypeConfig,
      secrets: validatedActionTypeSecrets
    });
    return {
      id: result.id,
      actionTypeId: result.attributes.actionTypeId,
      name: result.attributes.name,
      config: result.attributes.config,
      isPreconfigured: false
    };
  }
  /**
   * Update action
   */


  async update({
    id,
    action
  }) {
    if (this.preconfiguredActions.find(preconfiguredAction => preconfiguredAction.id === id) !== undefined) {
      throw new _preconfigured_action_disabled_modification.PreconfiguredActionDisabledModificationError(_i18n.i18n.translate('xpack.actions.serverSideErrors.predefinedActionUpdateDisabled', {
        defaultMessage: 'Preconfigured action {id} is not allowed to update.',
        values: {
          id
        }
      }), 'update');
    }

    const existingObject = await this.savedObjectsClient.get('action', id);
    const {
      actionTypeId
    } = existingObject.attributes;
    const {
      name,
      config,
      secrets
    } = action;
    const actionType = this.actionTypeRegistry.get(actionTypeId);
    const validatedActionTypeConfig = (0, _lib.validateConfig)(actionType, config);
    const validatedActionTypeSecrets = (0, _lib.validateSecrets)(actionType, secrets);
    this.actionTypeRegistry.ensureActionTypeEnabled(actionTypeId);
    const result = await this.savedObjectsClient.update('action', id, {
      actionTypeId,
      name,
      config: validatedActionTypeConfig,
      secrets: validatedActionTypeSecrets
    });
    return {
      id,
      actionTypeId: result.attributes.actionTypeId,
      name: result.attributes.name,
      config: result.attributes.config,
      isPreconfigured: false
    };
  }
  /**
   * Get an action
   */


  async get({
    id
  }) {
    const preconfiguredActionsList = this.preconfiguredActions.find(preconfiguredAction => preconfiguredAction.id === id);

    if (preconfiguredActionsList !== undefined) {
      return {
        id,
        actionTypeId: preconfiguredActionsList.actionTypeId,
        name: preconfiguredActionsList.name,
        isPreconfigured: true
      };
    }

    const result = await this.savedObjectsClient.get('action', id);
    return {
      id,
      actionTypeId: result.attributes.actionTypeId,
      name: result.attributes.name,
      config: result.attributes.config,
      isPreconfigured: false
    };
  }
  /**
   * Get all actions with preconfigured list
   */


  async getAll() {
    const savedObjectsActions = (await this.savedObjectsClient.find({
      perPage: MAX_ACTIONS_RETURNED,
      type: 'action'
    })).saved_objects.map(actionFromSavedObject);
    const mergedResult = [...savedObjectsActions, ...this.preconfiguredActions.map(preconfiguredAction => ({
      id: preconfiguredAction.id,
      actionTypeId: preconfiguredAction.actionTypeId,
      name: preconfiguredAction.name,
      isPreconfigured: true
    }))].sort((a, b) => a.name.localeCompare(b.name));
    return await injectExtraFindData(this.defaultKibanaIndex, this.scopedClusterClient, mergedResult);
  }
  /**
   * Get bulk actions with preconfigured list
   */


  async getBulk(ids) {
    const actionResults = new Array();

    for (const actionId of ids) {
      const action = this.preconfiguredActions.find(preconfiguredAction => preconfiguredAction.id === actionId);

      if (action !== undefined) {
        actionResults.push(action);
      }
    } // Fetch action objects in bulk
    // Excluding preconfigured actions to avoid an not found error, which is already added


    const actionSavedObjectsIds = [...new Set(ids.filter(actionId => !actionResults.find(actionResult => actionResult.id === actionId)))];
    const bulkGetOpts = actionSavedObjectsIds.map(id => ({
      id,
      type: 'action'
    }));
    const bulkGetResult = await this.savedObjectsClient.bulkGet(bulkGetOpts);

    for (const action of bulkGetResult.saved_objects) {
      if (action.error) {
        throw _boom.default.badRequest(`Failed to load action ${action.id} (${action.error.statusCode}): ${action.error.message}`);
      }

      actionResults.push(actionFromSavedObject(action));
    }

    return actionResults;
  }
  /**
   * Delete action
   */


  async delete({
    id
  }) {
    if (this.preconfiguredActions.find(preconfiguredAction => preconfiguredAction.id === id) !== undefined) {
      throw new _preconfigured_action_disabled_modification.PreconfiguredActionDisabledModificationError(_i18n.i18n.translate('xpack.actions.serverSideErrors.predefinedActionDeleteDisabled', {
        defaultMessage: 'Preconfigured action {id} is not allowed to delete.',
        values: {
          id
        }
      }), 'delete');
    }

    return await this.savedObjectsClient.delete('action', id);
  }

  async execute({
    actionId,
    params
  }) {
    return this.actionExecutor.execute({
      actionId,
      params,
      request: this.request
    });
  }

  async enqueueExecution(options) {
    return this.executionEnqueuer(this.savedObjectsClient, options);
  }

}

exports.ActionsClient = ActionsClient;

function actionFromSavedObject(savedObject) {
  return {
    id: savedObject.id,
    ...savedObject.attributes,
    isPreconfigured: false
  };
}

async function injectExtraFindData(defaultKibanaIndex, scopedClusterClient, actionResults) {
  const aggs = {};

  for (const actionResult of actionResults) {
    aggs[actionResult.id] = {
      filter: {
        bool: {
          must: {
            nested: {
              path: 'references',
              query: {
                bool: {
                  filter: {
                    bool: {
                      must: [{
                        term: {
                          'references.id': actionResult.id
                        }
                      }, {
                        term: {
                          'references.type': 'action'
                        }
                      }]
                    }
                  }
                }
              }
            }
          }
        }
      }
    };
  }

  const aggregationResult = await scopedClusterClient.callAsInternalUser('search', {
    index: defaultKibanaIndex,
    body: {
      aggs,
      size: 0,
      query: {
        match_all: {}
      }
    }
  });
  return actionResults.map(actionResult => ({ ...actionResult,
    referencedByCount: aggregationResult.aggregations[actionResult.id].doc_count
  }));
}