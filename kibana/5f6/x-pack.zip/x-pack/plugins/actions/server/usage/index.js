"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "registerActionsUsageCollector", {
  enumerable: true,
  get: function () {
    return _actions_usage_collector.registerActionsUsageCollector;
  }
});

var _actions_usage_collector = require("./actions_usage_collector");