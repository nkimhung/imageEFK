"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.createExecutionEnqueuerFunction = createExecutionEnqueuerFunction;

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
function createExecutionEnqueuerFunction({
  taskManager,
  actionTypeRegistry,
  isESOUsingEphemeralEncryptionKey,
  preconfiguredActions
}) {
  return async function execute(savedObjectsClient, {
    id,
    params,
    spaceId,
    apiKey
  }) {
    if (isESOUsingEphemeralEncryptionKey === true) {
      throw new Error(`Unable to execute action due to the Encrypted Saved Objects plugin using an ephemeral encryption key. Please set xpack.encryptedSavedObjects.encryptionKey in kibana.yml`);
    }

    const actionTypeId = await getActionTypeId(id);

    if (!actionTypeRegistry.isActionExecutable(id, actionTypeId)) {
      actionTypeRegistry.ensureActionTypeEnabled(actionTypeId);
    }

    const actionTaskParamsRecord = await savedObjectsClient.create('action_task_params', {
      actionId: id,
      params,
      apiKey
    });
    await taskManager.schedule({
      taskType: `actions:${actionTypeId}`,
      params: {
        spaceId,
        actionTaskParamsId: actionTaskParamsRecord.id
      },
      state: {},
      scope: ['actions']
    });

    async function getActionTypeId(actionId) {
      const pcAction = preconfiguredActions.find(action => action.id === actionId);

      if (pcAction) {
        return pcAction.actionTypeId;
      }

      const actionSO = await savedObjectsClient.get('action', actionId);
      return actionSO.attributes.actionTypeId;
    }
  };
}