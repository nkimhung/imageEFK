"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ActionsPlugin = exports.EVENT_LOG_ACTIONS = void 0;

var _operators = require("rxjs/operators");

var _types = require("../../licensing/common/types");

var _lib = require("./lib");

var _actions_client = require("./actions_client");

var _action_type_registry = require("./action_type_registry");

var _create_execute_function = require("./create_execute_function");

var _builtin_action_types = require("./builtin_action_types");

var _usage = require("./usage");

var _actions_config = require("./actions_config");

var _routes = require("./routes");

var _task = require("./usage/task");

var _saved_objects = require("./saved_objects");

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const EVENT_LOG_PROVIDER = 'actions';
const EVENT_LOG_ACTIONS = {
  execute: 'execute',
  executeViaHttp: 'execute-via-http'
};
exports.EVENT_LOG_ACTIONS = EVENT_LOG_ACTIONS;
const includedHiddenTypes = ['action', 'action_task_params'];

class ActionsPlugin {
  constructor(initContext) {
    _defineProperty(this, "kibanaIndex", void 0);

    _defineProperty(this, "config", void 0);

    _defineProperty(this, "logger", void 0);

    _defineProperty(this, "serverBasePath", void 0);

    _defineProperty(this, "taskRunnerFactory", void 0);

    _defineProperty(this, "actionTypeRegistry", void 0);

    _defineProperty(this, "actionExecutor", void 0);

    _defineProperty(this, "licenseState", null);

    _defineProperty(this, "spaces", void 0);

    _defineProperty(this, "eventLogger", void 0);

    _defineProperty(this, "isESOUsingEphemeralEncryptionKey", void 0);

    _defineProperty(this, "telemetryLogger", void 0);

    _defineProperty(this, "preconfiguredActions", void 0);

    _defineProperty(this, "createRouteHandlerContext", (core, defaultKibanaIndex) => {
      const {
        actionTypeRegistry,
        isESOUsingEphemeralEncryptionKey,
        preconfiguredActions,
        actionExecutor
      } = this;
      return async function actionsRouteHandlerContext(context, request) {
        const [{
          savedObjects
        }, {
          taskManager
        }] = await core.getStartServices();
        return {
          getActionsClient: () => {
            if (isESOUsingEphemeralEncryptionKey === true) {
              throw new Error(`Unable to create actions client due to the Encrypted Saved Objects plugin using an ephemeral encryption key. Please set xpack.encryptedSavedObjects.encryptionKey in kibana.yml`);
            }

            return new _actions_client.ActionsClient({
              savedObjectsClient: savedObjects.getScopedClient(request, {
                includedHiddenTypes
              }),
              actionTypeRegistry: actionTypeRegistry,
              defaultKibanaIndex,
              scopedClusterClient: context.core.elasticsearch.legacy.client,
              preconfiguredActions,
              request,
              actionExecutor: actionExecutor,
              executionEnqueuer: (0, _create_execute_function.createExecutionEnqueuerFunction)({
                taskManager,
                actionTypeRegistry: actionTypeRegistry,
                isESOUsingEphemeralEncryptionKey: isESOUsingEphemeralEncryptionKey,
                preconfiguredActions
              })
            });
          },
          listTypes: actionTypeRegistry.list.bind(actionTypeRegistry)
        };
      };
    });

    _defineProperty(this, "spaceIdToNamespace", spaceId => {
      return this.spaces && spaceId ? this.spaces.spaceIdToNamespace(spaceId) : undefined;
    });

    _defineProperty(this, "getBasePath", spaceId => {
      return this.spaces && spaceId ? this.spaces.getBasePath(spaceId) : this.serverBasePath;
    });

    this.config = initContext.config.create().pipe((0, _operators.first)()).toPromise();
    this.kibanaIndex = initContext.config.legacy.globalConfig$.pipe((0, _operators.first)(), (0, _operators.map)(config => config.kibana.index)).toPromise();
    this.logger = initContext.logger.get('actions');
    this.telemetryLogger = initContext.logger.get('telemetry');
    this.preconfiguredActions = [];
  }

  async setup(core, plugins) {
    var _plugins$spaces;

    this.licenseState = new _lib.LicenseState(plugins.licensing.license$);
    this.isESOUsingEphemeralEncryptionKey = plugins.encryptedSavedObjects.usingEphemeralEncryptionKey;

    if (this.isESOUsingEphemeralEncryptionKey) {
      this.logger.warn('APIs are disabled due to the Encrypted Saved Objects plugin using an ephemeral encryption key. Please set xpack.encryptedSavedObjects.encryptionKey in kibana.yml.');
    }

    (0, _saved_objects.setupSavedObjects)(core.savedObjects, plugins.encryptedSavedObjects);
    plugins.eventLog.registerProviderActions(EVENT_LOG_PROVIDER, Object.values(EVENT_LOG_ACTIONS));
    this.eventLogger = plugins.eventLog.getLogger({
      event: {
        provider: EVENT_LOG_PROVIDER
      }
    });
    const actionExecutor = new _lib.ActionExecutor({
      isESOUsingEphemeralEncryptionKey: this.isESOUsingEphemeralEncryptionKey
    }); // get executions count

    const taskRunnerFactory = new _lib.TaskRunnerFactory(actionExecutor);
    const actionsConfig = await this.config;
    const actionsConfigUtils = (0, _actions_config.getActionsConfigurationUtilities)(actionsConfig);

    for (const preconfiguredId of Object.keys(actionsConfig.preconfigured)) {
      this.preconfiguredActions.push({ ...actionsConfig.preconfigured[preconfiguredId],
        id: preconfiguredId,
        isPreconfigured: true
      });
    }

    const actionTypeRegistry = new _action_type_registry.ActionTypeRegistry({
      taskRunnerFactory,
      taskManager: plugins.taskManager,
      actionsConfigUtils,
      licenseState: this.licenseState,
      preconfiguredActions: this.preconfiguredActions
    });
    this.taskRunnerFactory = taskRunnerFactory;
    this.actionTypeRegistry = actionTypeRegistry;
    this.serverBasePath = core.http.basePath.serverBasePath;
    this.actionExecutor = actionExecutor;
    this.spaces = (_plugins$spaces = plugins.spaces) === null || _plugins$spaces === void 0 ? void 0 : _plugins$spaces.spacesService;
    (0, _builtin_action_types.registerBuiltInActionTypes)({
      logger: this.logger,
      actionTypeRegistry,
      actionsConfigUtils
    });
    const usageCollection = plugins.usageCollection;

    if (usageCollection) {
      (0, _task.initializeActionsTelemetry)(this.telemetryLogger, plugins.taskManager, core, await this.kibanaIndex);
      core.getStartServices().then(async ([, startPlugins]) => {
        (0, _usage.registerActionsUsageCollector)(usageCollection, startPlugins.taskManager);
      });
    }

    core.http.registerRouteHandlerContext('actions', this.createRouteHandlerContext(core, await this.kibanaIndex)); // Routes

    const router = core.http.createRouter();
    (0, _routes.createActionRoute)(router, this.licenseState);
    (0, _routes.deleteActionRoute)(router, this.licenseState);
    (0, _routes.getActionRoute)(router, this.licenseState);
    (0, _routes.getAllActionRoute)(router, this.licenseState);
    (0, _routes.updateActionRoute)(router, this.licenseState);
    (0, _routes.listActionTypesRoute)(router, this.licenseState);
    (0, _routes.executeActionRoute)(router, this.licenseState);
    return {
      registerType: actionType => {
        if (!(actionType.minimumLicenseRequired in _types.LICENSE_TYPE)) {
          throw new Error(`"${actionType.minimumLicenseRequired}" is not a valid license type`);
        }

        if (_types.LICENSE_TYPE[actionType.minimumLicenseRequired] < _types.LICENSE_TYPE.gold) {
          throw new Error(`Third party action type "${actionType.id}" can only set minimumLicenseRequired to a gold license or higher`);
        }

        actionTypeRegistry.register(actionType);
      }
    };
  }

  start(core, plugins) {
    const {
      logger,
      actionExecutor,
      actionTypeRegistry,
      taskRunnerFactory,
      kibanaIndex,
      isESOUsingEphemeralEncryptionKey,
      preconfiguredActions
    } = this;
    const encryptedSavedObjectsClient = plugins.encryptedSavedObjects.getClient({
      includedHiddenTypes
    });

    const getScopedSavedObjectsClient = request => core.savedObjects.getScopedClient(request, {
      includedHiddenTypes
    });

    const getScopedSavedObjectsClientWithoutAccessToActions = request => core.savedObjects.getScopedClient(request);

    actionExecutor.initialize({
      logger,
      eventLogger: this.eventLogger,
      spaces: this.spaces,
      getScopedSavedObjectsClient,
      getServices: this.getServicesFactory(getScopedSavedObjectsClientWithoutAccessToActions, core.elasticsearch),
      encryptedSavedObjectsClient,
      actionTypeRegistry: actionTypeRegistry,
      preconfiguredActions
    });
    taskRunnerFactory.initialize({
      logger,
      actionTypeRegistry: actionTypeRegistry,
      encryptedSavedObjectsClient,
      getBasePath: this.getBasePath,
      spaceIdToNamespace: this.spaceIdToNamespace,
      getScopedSavedObjectsClient
    });
    (0, _task.scheduleActionsTelemetry)(this.telemetryLogger, plugins.taskManager);
    return {
      isActionTypeEnabled: id => {
        return this.actionTypeRegistry.isActionTypeEnabled(id);
      },
      isActionExecutable: (actionId, actionTypeId) => {
        return this.actionTypeRegistry.isActionExecutable(actionId, actionTypeId);
      },

      // Ability to get an actions client from legacy code
      async getActionsClientWithRequest(request) {
        if (isESOUsingEphemeralEncryptionKey === true) {
          throw new Error(`Unable to create actions client due to the Encrypted Saved Objects plugin using an ephemeral encryption key. Please set xpack.encryptedSavedObjects.encryptionKey in kibana.yml`);
        }

        return new _actions_client.ActionsClient({
          savedObjectsClient: getScopedSavedObjectsClient(request),
          actionTypeRegistry: actionTypeRegistry,
          defaultKibanaIndex: await kibanaIndex,
          scopedClusterClient: core.elasticsearch.legacy.client.asScoped(request),
          preconfiguredActions,
          request,
          actionExecutor: actionExecutor,
          executionEnqueuer: (0, _create_execute_function.createExecutionEnqueuerFunction)({
            taskManager: plugins.taskManager,
            actionTypeRegistry: actionTypeRegistry,
            isESOUsingEphemeralEncryptionKey: isESOUsingEphemeralEncryptionKey,
            preconfiguredActions
          })
        });
      },

      preconfiguredActions
    };
  }

  getServicesFactory(getScopedClient, elasticsearch) {
    return request => ({
      callCluster: elasticsearch.legacy.client.asScoped(request).callAsCurrentUser,
      savedObjectsClient: getScopedClient(request),

      getLegacyScopedClusterClient(clusterClient) {
        return clusterClient.asScoped(request);
      }

    });
  }

  stop() {
    if (this.licenseState) {
      this.licenseState.clean();
    }
  }

}

exports.ActionsPlugin = ActionsPlugin;