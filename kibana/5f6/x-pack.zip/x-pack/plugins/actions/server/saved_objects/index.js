"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.setupSavedObjects = setupSavedObjects;

var _mappings = _interopRequireDefault(require("./mappings.json"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
function setupSavedObjects(savedObjects, encryptedSavedObjects) {
  savedObjects.registerType({
    name: 'action',
    hidden: true,
    namespaceType: 'single',
    mappings: _mappings.default.action
  }); // Encrypted attributes
  // - `secrets` properties will be encrypted
  // - `config` will be included in AAD
  // - everything else excluded from AAD

  encryptedSavedObjects.registerType({
    type: 'action',
    attributesToEncrypt: new Set(['secrets']),
    attributesToExcludeFromAAD: new Set(['name'])
  });
  savedObjects.registerType({
    name: 'action_task_params',
    hidden: true,
    namespaceType: 'single',
    mappings: _mappings.default.action_task_params
  });
  encryptedSavedObjects.registerType({
    type: 'action_task_params',
    attributesToEncrypt: new Set(['apiKey'])
  });
}