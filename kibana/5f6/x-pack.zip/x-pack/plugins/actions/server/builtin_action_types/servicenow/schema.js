"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ExecutorParamsSchema = exports.ExecutorSubActionHandshakeParamsSchema = exports.ExecutorSubActionGetIncidentParamsSchema = exports.ExecutorSubActionPushParamsSchema = exports.ExecutorSubActionSchema = exports.ExternalIncidentServiceSecretConfigurationSchema = exports.ExternalIncidentServiceSecretConfiguration = exports.ExternalIncidentServiceConfigurationSchema = exports.ExternalIncidentServiceConfiguration = void 0;

var _configSchema = require("@kbn/config-schema");

var _case_shema = require("./case_shema");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
const ExternalIncidentServiceConfiguration = {
  apiUrl: _configSchema.schema.string(),
  // TODO: to remove - set it optional for the current stage to support Case ServiceNow implementation
  incidentConfiguration: _configSchema.schema.nullable(_case_shema.IncidentConfigurationSchema),
  isCaseOwned: _configSchema.schema.maybe(_configSchema.schema.boolean())
};
exports.ExternalIncidentServiceConfiguration = ExternalIncidentServiceConfiguration;

const ExternalIncidentServiceConfigurationSchema = _configSchema.schema.object(ExternalIncidentServiceConfiguration);

exports.ExternalIncidentServiceConfigurationSchema = ExternalIncidentServiceConfigurationSchema;
const ExternalIncidentServiceSecretConfiguration = {
  password: _configSchema.schema.string(),
  username: _configSchema.schema.string()
};
exports.ExternalIncidentServiceSecretConfiguration = ExternalIncidentServiceSecretConfiguration;

const ExternalIncidentServiceSecretConfigurationSchema = _configSchema.schema.object(ExternalIncidentServiceSecretConfiguration);

exports.ExternalIncidentServiceSecretConfigurationSchema = ExternalIncidentServiceSecretConfigurationSchema;

const ExecutorSubActionSchema = _configSchema.schema.oneOf([_configSchema.schema.literal('getIncident'), _configSchema.schema.literal('pushToService'), _configSchema.schema.literal('handshake')]);

exports.ExecutorSubActionSchema = ExecutorSubActionSchema;

const ExecutorSubActionPushParamsSchema = _configSchema.schema.object({
  savedObjectId: _configSchema.schema.string(),
  title: _configSchema.schema.string(),
  description: _configSchema.schema.nullable(_configSchema.schema.string()),
  comment: _configSchema.schema.nullable(_configSchema.schema.string()),
  externalId: _configSchema.schema.nullable(_configSchema.schema.string()),
  severity: _configSchema.schema.nullable(_configSchema.schema.string()),
  urgency: _configSchema.schema.nullable(_configSchema.schema.string()),
  impact: _configSchema.schema.nullable(_configSchema.schema.string()),
  // TODO: remove later  - need for support Case push multiple comments
  comments: _configSchema.schema.maybe(_configSchema.schema.arrayOf(_case_shema.CommentSchema)),
  ..._case_shema.EntityInformation
});

exports.ExecutorSubActionPushParamsSchema = ExecutorSubActionPushParamsSchema;

const ExecutorSubActionGetIncidentParamsSchema = _configSchema.schema.object({
  externalId: _configSchema.schema.string()
}); // Reserved for future implementation


exports.ExecutorSubActionGetIncidentParamsSchema = ExecutorSubActionGetIncidentParamsSchema;

const ExecutorSubActionHandshakeParamsSchema = _configSchema.schema.object({});

exports.ExecutorSubActionHandshakeParamsSchema = ExecutorSubActionHandshakeParamsSchema;

const ExecutorParamsSchema = _configSchema.schema.oneOf([_configSchema.schema.object({
  subAction: _configSchema.schema.literal('getIncident'),
  subActionParams: ExecutorSubActionGetIncidentParamsSchema
}), _configSchema.schema.object({
  subAction: _configSchema.schema.literal('handshake'),
  subActionParams: ExecutorSubActionHandshakeParamsSchema
}), _configSchema.schema.object({
  subAction: _configSchema.schema.literal('pushToService'),
  subActionParams: ExecutorSubActionPushParamsSchema
})]);

exports.ExecutorParamsSchema = ExecutorParamsSchema;