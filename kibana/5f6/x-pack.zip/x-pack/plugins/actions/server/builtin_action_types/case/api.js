"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.api = void 0;

var _utils = require("./utils");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
const handshakeHandler = async ({
  externalService,
  mapping,
  params
}) => {};

const getIncidentHandler = async ({
  externalService,
  mapping,
  params
}) => {};

const pushToServiceHandler = async ({
  externalService,
  mapping,
  params
}) => {
  var _mapping$get;

  const {
    externalId,
    comments
  } = params;
  const updateIncident = externalId ? true : false;
  const defaultPipes = updateIncident ? ['informationUpdated'] : ['informationCreated'];
  let currentIncident;
  let res;

  if (externalId) {
    currentIncident = await externalService.getIncident(externalId);
  }

  const fields = (0, _utils.prepareFieldsForTransformation)({
    externalCase: params.externalCase,
    mapping,
    defaultPipes
  });
  const incident = (0, _utils.transformFields)({
    params,
    fields,
    currentIncident
  });

  if (updateIncident) {
    res = await externalService.updateIncident({
      incidentId: externalId,
      incident
    });
  } else {
    res = await externalService.createIncident({
      incident
    });
  }

  if (comments && Array.isArray(comments) && comments.length > 0 && ((_mapping$get = mapping.get('comments')) === null || _mapping$get === void 0 ? void 0 : _mapping$get.actionType) !== 'nothing') {
    const commentsTransformed = (0, _utils.transformComments)(comments, ['informationAdded']);
    res.comments = [];

    for (const currentComment of commentsTransformed) {
      var _mapping$get$target, _mapping$get2, _res$comments;

      const comment = await externalService.createComment({
        incidentId: res.id,
        comment: currentComment,
        field: (_mapping$get$target = (_mapping$get2 = mapping.get('comments')) === null || _mapping$get2 === void 0 ? void 0 : _mapping$get2.target) !== null && _mapping$get$target !== void 0 ? _mapping$get$target : 'comments'
      });
      res.comments = [...((_res$comments = res.comments) !== null && _res$comments !== void 0 ? _res$comments : []), {
        commentId: comment.commentId,
        pushedDate: comment.pushedDate
      }];
    }
  }

  return res;
};

const api = {
  handshake: handshakeHandler,
  pushToService: pushToServiceHandler,
  getIncident: getIncidentHandler
};
exports.api = api;