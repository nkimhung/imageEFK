"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.createExternalService = void 0;

var _axios = _interopRequireDefault(require("axios"));

var i18n = _interopRequireWildcard(require("./translations"));

var _axios_utils = require("../lib/axios_utils");

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function () { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
const API_VERSION = 'v2';
const INCIDENT_URL = `api/now/${API_VERSION}/table/incident`; // Based on: https://docs.servicenow.com/bundle/orlando-platform-user-interface/page/use/navigation/reference/r_NavigatingByURLExamples.html

const VIEW_INCIDENT_URL = `nav_to.do?uri=incident.do?sys_id=`;

const createExternalService = ({
  config,
  secrets
}) => {
  const {
    apiUrl: url
  } = config;
  const {
    username,
    password
  } = secrets;

  if (!url || !username || !password) {
    throw Error(`[Action]${i18n.NAME}: Wrong configuration.`);
  }

  const incidentUrl = `${url}/${INCIDENT_URL}`;

  const axiosInstance = _axios.default.create({
    auth: {
      username,
      password
    }
  });

  const getIncidentViewURL = id => {
    return `${url}/${VIEW_INCIDENT_URL}${id}`;
  };

  const getIncident = async id => {
    try {
      const res = await (0, _axios_utils.request)({
        axios: axiosInstance,
        url: `${incidentUrl}/${id}`
      });
      return { ...res.data.result
      };
    } catch (error) {
      throw new Error((0, _axios_utils.getErrorMessage)(i18n.NAME, `Unable to get incident with id ${id}. Error: ${error.message}`));
    }
  };

  const findIncidents = async params => {
    try {
      const res = await (0, _axios_utils.request)({
        axios: axiosInstance,
        url: incidentUrl,
        params
      });
      return res.data.result.length > 0 ? { ...res.data.result
      } : undefined;
    } catch (error) {
      throw new Error((0, _axios_utils.getErrorMessage)(i18n.NAME, `Unable to find incidents by query. Error: ${error.message}`));
    }
  };

  const createIncident = async ({
    incident
  }) => {
    try {
      const res = await (0, _axios_utils.request)({
        axios: axiosInstance,
        url: `${incidentUrl}`,
        method: 'post',
        data: { ...incident
        }
      });
      return {
        title: res.data.result.number,
        id: res.data.result.sys_id,
        pushedDate: new Date((0, _axios_utils.addTimeZoneToDate)(res.data.result.sys_created_on)).toISOString(),
        url: getIncidentViewURL(res.data.result.sys_id)
      };
    } catch (error) {
      throw new Error((0, _axios_utils.getErrorMessage)(i18n.NAME, `Unable to create incident. Error: ${error.message}`));
    }
  };

  const updateIncident = async ({
    incidentId,
    incident
  }) => {
    try {
      const res = await (0, _axios_utils.patch)({
        axios: axiosInstance,
        url: `${incidentUrl}/${incidentId}`,
        data: { ...incident
        }
      });
      return {
        title: res.data.result.number,
        id: res.data.result.sys_id,
        pushedDate: new Date((0, _axios_utils.addTimeZoneToDate)(res.data.result.sys_updated_on)).toISOString(),
        url: getIncidentViewURL(res.data.result.sys_id)
      };
    } catch (error) {
      throw new Error((0, _axios_utils.getErrorMessage)(i18n.NAME, `Unable to update incident with id ${incidentId}. Error: ${error.message}`));
    }
  };

  return {
    getIncident,
    createIncident,
    updateIncident,
    findIncidents
  };
};

exports.createExternalService = createExternalService;