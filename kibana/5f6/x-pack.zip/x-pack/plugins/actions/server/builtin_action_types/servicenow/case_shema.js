"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CommentSchema = exports.EntityInformation = exports.IncidentConfigurationSchema = exports.MapRecordSchema = exports.MappingActionType = void 0;

var _configSchema = require("@kbn/config-schema");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
const MappingActionType = _configSchema.schema.oneOf([_configSchema.schema.literal('nothing'), _configSchema.schema.literal('overwrite'), _configSchema.schema.literal('append')]);

exports.MappingActionType = MappingActionType;

const MapRecordSchema = _configSchema.schema.object({
  source: _configSchema.schema.string(),
  target: _configSchema.schema.string(),
  actionType: MappingActionType
});

exports.MapRecordSchema = MapRecordSchema;

const IncidentConfigurationSchema = _configSchema.schema.object({
  mapping: _configSchema.schema.arrayOf(MapRecordSchema)
});

exports.IncidentConfigurationSchema = IncidentConfigurationSchema;
const EntityInformation = {
  createdAt: _configSchema.schema.maybe(_configSchema.schema.string()),
  createdBy: _configSchema.schema.maybe(_configSchema.schema.any()),
  updatedAt: _configSchema.schema.nullable(_configSchema.schema.string()),
  updatedBy: _configSchema.schema.nullable(_configSchema.schema.any())
};
exports.EntityInformation = EntityInformation;

const CommentSchema = _configSchema.schema.object({
  commentId: _configSchema.schema.string(),
  comment: _configSchema.schema.string(),
  ...EntityInformation
});

exports.CommentSchema = CommentSchema;