"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.validate = void 0;

var _validators = require("../case/validators");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
const validate = {
  config: _validators.validateCommonConfig,
  secrets: _validators.validateCommonSecrets
};
exports.validate = validate;