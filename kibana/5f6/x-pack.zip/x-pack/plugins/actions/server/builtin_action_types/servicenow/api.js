"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.api = exports.transformFields = void 0;

var _lodash = require("lodash");

var _transformers = require("../case/transformers");

var _utils = require("../case/utils");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
// TODO: to remove, need to support Case
const handshakeHandler = async ({
  externalService,
  mapping,
  params
}) => {};

const getIncidentHandler = async ({
  externalService,
  mapping,
  params
}) => {};

const pushToServiceHandler = async ({
  externalService,
  mapping,
  params,
  secrets,
  logger
}) => {
  var _mapping$get;

  const {
    externalId,
    comments
  } = params;
  const updateIncident = externalId ? true : false;
  const defaultPipes = updateIncident ? ['informationUpdated'] : ['informationCreated'];
  let currentIncident;
  let res;

  if (externalId) {
    try {
      currentIncident = await externalService.getIncident(externalId);
    } catch (ex) {
      logger.debug(`Retrieving Incident by id ${externalId} from ServiceNow was failed with exception: ${ex}`);
    }
  }

  let incident = {}; // TODO: should be removed later but currently keep it for the Case implementation support

  if (mapping && Array.isArray(params.comments)) {
    const fields = (0, _utils.prepareFieldsForTransformation)({
      externalCase: params.externalObject,
      mapping,
      defaultPipes
    });
    incident = transformFields({
      params,
      fields,
      currentIncident
    });
  } else {
    incident = { ...params,
      short_description: params.title,
      comments: params.comment
    };
  }

  if (updateIncident) {
    res = await externalService.updateIncident({
      incidentId: externalId,
      incident
    });
  } else {
    res = await externalService.createIncident({
      incident: { ...incident,
        caller_id: secrets.username
      }
    });
  } // TODO: should temporary keep comments for a Case usage


  if (comments && Array.isArray(comments) && comments.length > 0 && mapping && ((_mapping$get = mapping.get('comments')) === null || _mapping$get === void 0 ? void 0 : _mapping$get.actionType) !== 'nothing') {
    var _mapping$get$target, _mapping$get2;

    res.comments = [];
    const fieldsKey = (_mapping$get$target = (_mapping$get2 = mapping.get('comments')) === null || _mapping$get2 === void 0 ? void 0 : _mapping$get2.target) !== null && _mapping$get$target !== void 0 ? _mapping$get$target : 'comments';

    for (const currentComment of comments) {
      var _res$comments;

      await externalService.updateIncident({
        incidentId: res.id,
        incident: { ...incident,
          [fieldsKey]: currentComment.comment
        }
      });
      res.comments = [...((_res$comments = res.comments) !== null && _res$comments !== void 0 ? _res$comments : []), {
        commentId: currentComment.commentId,
        pushedDate: res.pushedDate
      }];
    }
  }

  return res;
};

const transformFields = ({
  params,
  fields,
  currentIncident
}) => {
  return fields.reduce((prev, cur) => {
    var _params$updatedAt, _ref;

    const transform = (0, _lodash.flow)(...cur.pipes.map(p => _transformers.transformers[p]));
    return { ...prev,
      [cur.key]: transform({
        value: cur.value,
        date: (_params$updatedAt = params.updatedAt) !== null && _params$updatedAt !== void 0 ? _params$updatedAt : params.createdAt,
        user: (_ref = params.updatedBy != null ? params.updatedBy.fullName ? params.updatedBy.fullName : params.updatedBy.username : params.createdBy.fullName ? params.createdBy.fullName : params.createdBy.username) !== null && _ref !== void 0 ? _ref : '',
        previousValue: currentIncident ? currentIncident[cur.key] : ''
      }).value
    };
  }, {});
};

exports.transformFields = transformFields;
const api = {
  handshake: handshakeHandler,
  pushToService: pushToServiceHandler,
  getIncident: getIncidentHandler
};
exports.api = api;