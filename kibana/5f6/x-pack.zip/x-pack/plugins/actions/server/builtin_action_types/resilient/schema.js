"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ResilientSecretConfigurationSchema = exports.ResilientSecretConfiguration = exports.ResilientPublicConfigurationSchema = exports.ResilientPublicConfiguration = void 0;

var _configSchema = require("@kbn/config-schema");

var _schema = require("../case/schema");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
const ResilientPublicConfiguration = {
  orgId: _configSchema.schema.string(),
  ..._schema.ExternalIncidentServiceConfiguration
};
exports.ResilientPublicConfiguration = ResilientPublicConfiguration;

const ResilientPublicConfigurationSchema = _configSchema.schema.object(ResilientPublicConfiguration);

exports.ResilientPublicConfigurationSchema = ResilientPublicConfigurationSchema;
const ResilientSecretConfiguration = {
  apiKeyId: _configSchema.schema.string(),
  apiKeySecret: _configSchema.schema.string()
};
exports.ResilientSecretConfiguration = ResilientSecretConfiguration;

const ResilientSecretConfigurationSchema = _configSchema.schema.object(ResilientSecretConfiguration);

exports.ResilientSecretConfigurationSchema = ResilientSecretConfigurationSchema;