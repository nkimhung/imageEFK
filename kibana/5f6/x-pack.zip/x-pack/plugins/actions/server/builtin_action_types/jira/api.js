"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "api", {
  enumerable: true,
  get: function () {
    return _api.api;
  }
});

var _api = require("../case/api");