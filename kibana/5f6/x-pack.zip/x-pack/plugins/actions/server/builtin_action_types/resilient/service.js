"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.createExternalService = exports.formatUpdateRequest = exports.getValueTextContent = void 0;

var _axios = _interopRequireDefault(require("axios"));

var i18n = _interopRequireWildcard(require("./translations"));

var _axios_utils = require("../lib/axios_utils");

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function () { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
const BASE_URL = `rest`;
const INCIDENT_URL = `incidents`;
const COMMENT_URL = `comments`;
const VIEW_INCIDENT_URL = `#incidents`;

const getValueTextContent = (field, value) => {
  if (field === 'description') {
    return {
      textarea: {
        format: 'html',
        content: value
      }
    };
  }

  return {
    text: value
  };
};

exports.getValueTextContent = getValueTextContent;

const formatUpdateRequest = ({
  oldIncident,
  newIncident
}) => {
  return {
    changes: Object.keys(newIncident).map(key => ({
      field: {
        name: key
      },
      old_value: getValueTextContent(key, oldIncident[key]),
      new_value: getValueTextContent(key, newIncident[key])
    }))
  };
};

exports.formatUpdateRequest = formatUpdateRequest;

const createExternalService = ({
  config,
  secrets
}) => {
  const {
    apiUrl: url,
    orgId
  } = config;
  const {
    apiKeyId,
    apiKeySecret
  } = secrets;

  if (!url || !orgId || !apiKeyId || !apiKeySecret) {
    throw Error(`[Action]${i18n.NAME}: Wrong configuration.`);
  }

  const urlWithoutTrailingSlash = url.endsWith('/') ? url.slice(0, -1) : url;
  const incidentUrl = `${urlWithoutTrailingSlash}/${BASE_URL}/orgs/${orgId}/${INCIDENT_URL}`;
  const commentUrl = `${incidentUrl}/{inc_id}/${COMMENT_URL}`;

  const axiosInstance = _axios.default.create({
    auth: {
      username: apiKeyId,
      password: apiKeySecret
    }
  });

  const getIncidentViewURL = key => {
    return `${urlWithoutTrailingSlash}/${VIEW_INCIDENT_URL}/${key}`;
  };

  const getCommentsURL = incidentId => {
    return commentUrl.replace('{inc_id}', incidentId);
  };

  const getIncident = async id => {
    try {
      var _res$data$description, _res$data$description2;

      const res = await (0, _axios_utils.request)({
        axios: axiosInstance,
        url: `${incidentUrl}/${id}`,
        params: {
          text_content_output_format: 'objects_convert'
        }
      });
      return { ...res.data,
        description: (_res$data$description = (_res$data$description2 = res.data.description) === null || _res$data$description2 === void 0 ? void 0 : _res$data$description2.content) !== null && _res$data$description !== void 0 ? _res$data$description : ''
      };
    } catch (error) {
      throw new Error((0, _axios_utils.getErrorMessage)(i18n.NAME, `Unable to get incident with id ${id}. Error: ${error.message}`));
    }
  };

  const createIncident = async ({
    incident
  }) => {
    try {
      var _incident$description;

      const res = await (0, _axios_utils.request)({
        axios: axiosInstance,
        url: `${incidentUrl}`,
        method: 'post',
        data: { ...incident,
          description: {
            format: 'html',
            content: (_incident$description = incident.description) !== null && _incident$description !== void 0 ? _incident$description : ''
          },
          discovered_date: Date.now()
        }
      });
      return {
        title: `${res.data.id}`,
        id: `${res.data.id}`,
        pushedDate: new Date(res.data.create_date).toISOString(),
        url: getIncidentViewURL(res.data.id)
      };
    } catch (error) {
      throw new Error((0, _axios_utils.getErrorMessage)(i18n.NAME, `Unable to create incident. Error: ${error.message}`));
    }
  };

  const updateIncident = async ({
    incidentId,
    incident
  }) => {
    try {
      const latestIncident = await getIncident(incidentId);
      const data = formatUpdateRequest({
        oldIncident: latestIncident,
        newIncident: incident
      });
      const res = await (0, _axios_utils.request)({
        axios: axiosInstance,
        method: 'patch',
        url: `${incidentUrl}/${incidentId}`,
        data
      });

      if (!res.data.success) {
        throw new Error(res.data.message);
      }

      const updatedIncident = await getIncident(incidentId);
      return {
        title: `${updatedIncident.id}`,
        id: `${updatedIncident.id}`,
        pushedDate: new Date(updatedIncident.inc_last_modified_date).toISOString(),
        url: getIncidentViewURL(updatedIncident.id)
      };
    } catch (error) {
      throw new Error((0, _axios_utils.getErrorMessage)(i18n.NAME, `Unable to update incident with id ${incidentId}. Error: ${error.message}`));
    }
  };

  const createComment = async ({
    incidentId,
    comment,
    field
  }) => {
    try {
      const res = await (0, _axios_utils.request)({
        axios: axiosInstance,
        method: 'post',
        url: getCommentsURL(incidentId),
        data: {
          text: {
            format: 'text',
            content: comment.comment
          }
        }
      });
      return {
        commentId: comment.commentId,
        externalCommentId: res.data.id,
        pushedDate: new Date(res.data.create_date).toISOString()
      };
    } catch (error) {
      throw new Error((0, _axios_utils.getErrorMessage)(i18n.NAME, `Unable to create comment at incident with id ${incidentId}. Error: ${error.message}`));
    }
  };

  return {
    getIncident,
    createIncident,
    updateIncident,
    createComment
  };
};

exports.createExternalService = createExternalService;