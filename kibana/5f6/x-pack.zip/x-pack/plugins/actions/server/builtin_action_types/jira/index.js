"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getActionType = void 0;

var _utils = require("../case/utils");

var _api = require("./api");

var _config = require("./config");

var _validators = require("./validators");

var _service = require("./service");

var _schema = require("./schema");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
const getActionType = (0, _utils.createConnector)({
  api: _api.api,
  config: _config.config,
  validate: _validators.validate,
  createExternalService: _service.createExternalService,
  validationSchema: {
    config: _schema.JiraPublicConfiguration,
    secrets: _schema.JiraSecretConfiguration
  }
});
exports.getActionType = getActionType;