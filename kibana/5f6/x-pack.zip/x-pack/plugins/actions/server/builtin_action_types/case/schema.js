"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ExecutorParamsSchema = exports.ExecutorSubActionHandshakeParamsSchema = exports.ExecutorSubActionGetIncidentParamsSchema = exports.ExecutorSubActionPushParamsSchema = exports.ExecutorSubActionSchema = exports.CommentSchema = exports.EntityInformationSchema = exports.UserSchema = exports.ExternalIncidentServiceSecretConfigurationSchema = exports.ExternalIncidentServiceSecretConfiguration = exports.ExternalIncidentServiceConfigurationSchema = exports.ExternalIncidentServiceConfiguration = exports.CaseConfigurationSchema = exports.MapRecordSchema = exports.MappingActionType = void 0;

var _configSchema = require("@kbn/config-schema");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
const MappingActionType = _configSchema.schema.oneOf([_configSchema.schema.literal('nothing'), _configSchema.schema.literal('overwrite'), _configSchema.schema.literal('append')]);

exports.MappingActionType = MappingActionType;

const MapRecordSchema = _configSchema.schema.object({
  source: _configSchema.schema.string(),
  target: _configSchema.schema.string(),
  actionType: MappingActionType
});

exports.MapRecordSchema = MapRecordSchema;

const CaseConfigurationSchema = _configSchema.schema.object({
  mapping: _configSchema.schema.arrayOf(MapRecordSchema)
});

exports.CaseConfigurationSchema = CaseConfigurationSchema;
const ExternalIncidentServiceConfiguration = {
  apiUrl: _configSchema.schema.string(),
  casesConfiguration: CaseConfigurationSchema
};
exports.ExternalIncidentServiceConfiguration = ExternalIncidentServiceConfiguration;

const ExternalIncidentServiceConfigurationSchema = _configSchema.schema.object(ExternalIncidentServiceConfiguration);

exports.ExternalIncidentServiceConfigurationSchema = ExternalIncidentServiceConfigurationSchema;
const ExternalIncidentServiceSecretConfiguration = {
  password: _configSchema.schema.string(),
  username: _configSchema.schema.string()
};
exports.ExternalIncidentServiceSecretConfiguration = ExternalIncidentServiceSecretConfiguration;

const ExternalIncidentServiceSecretConfigurationSchema = _configSchema.schema.object(ExternalIncidentServiceSecretConfiguration);

exports.ExternalIncidentServiceSecretConfigurationSchema = ExternalIncidentServiceSecretConfigurationSchema;

const UserSchema = _configSchema.schema.object({
  fullName: _configSchema.schema.nullable(_configSchema.schema.string()),
  username: _configSchema.schema.nullable(_configSchema.schema.string())
});

exports.UserSchema = UserSchema;
const EntityInformation = {
  createdAt: _configSchema.schema.string(),
  createdBy: UserSchema,
  updatedAt: _configSchema.schema.nullable(_configSchema.schema.string()),
  updatedBy: _configSchema.schema.nullable(UserSchema)
};

const EntityInformationSchema = _configSchema.schema.object(EntityInformation);

exports.EntityInformationSchema = EntityInformationSchema;

const CommentSchema = _configSchema.schema.object({
  commentId: _configSchema.schema.string(),
  comment: _configSchema.schema.string(),
  ...EntityInformation
});

exports.CommentSchema = CommentSchema;

const ExecutorSubActionSchema = _configSchema.schema.oneOf([_configSchema.schema.literal('getIncident'), _configSchema.schema.literal('pushToService'), _configSchema.schema.literal('handshake')]);

exports.ExecutorSubActionSchema = ExecutorSubActionSchema;

const ExecutorSubActionPushParamsSchema = _configSchema.schema.object({
  savedObjectId: _configSchema.schema.string(),
  title: _configSchema.schema.string(),
  description: _configSchema.schema.nullable(_configSchema.schema.string()),
  comments: _configSchema.schema.nullable(_configSchema.schema.arrayOf(CommentSchema)),
  externalId: _configSchema.schema.nullable(_configSchema.schema.string()),
  ...EntityInformation
});

exports.ExecutorSubActionPushParamsSchema = ExecutorSubActionPushParamsSchema;

const ExecutorSubActionGetIncidentParamsSchema = _configSchema.schema.object({
  externalId: _configSchema.schema.string()
}); // Reserved for future implementation


exports.ExecutorSubActionGetIncidentParamsSchema = ExecutorSubActionGetIncidentParamsSchema;

const ExecutorSubActionHandshakeParamsSchema = _configSchema.schema.object({});

exports.ExecutorSubActionHandshakeParamsSchema = ExecutorSubActionHandshakeParamsSchema;

const ExecutorParamsSchema = _configSchema.schema.oneOf([_configSchema.schema.object({
  subAction: _configSchema.schema.literal('getIncident'),
  subActionParams: ExecutorSubActionGetIncidentParamsSchema
}), _configSchema.schema.object({
  subAction: _configSchema.schema.literal('handshake'),
  subActionParams: ExecutorSubActionHandshakeParamsSchema
}), _configSchema.schema.object({
  subAction: _configSchema.schema.literal('pushToService'),
  subActionParams: ExecutorSubActionPushParamsSchema
})]);

exports.ExecutorParamsSchema = ExecutorParamsSchema;