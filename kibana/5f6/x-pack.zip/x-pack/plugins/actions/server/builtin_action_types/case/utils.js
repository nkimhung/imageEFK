"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getErrorMessage = exports.transformComments = exports.transformFields = exports.prepareFieldsForTransformation = exports.createConnector = exports.createConnectorExecutor = exports.mapParams = exports.buildMap = exports.normalizeMapping = void 0;

var _lodash = require("lodash");

var _configSchema = require("@kbn/config-schema");

var _schema = require("./schema");

var _transformers = require("./transformers");

var _constants = require("./constants");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
const normalizeMapping = (supportedFields, mapping) => {
  // Prevent prototype pollution and remove unsupported fields
  return mapping.filter(m => m.source !== '__proto__' && m.target !== '__proto__' && supportedFields.includes(m.source));
};

exports.normalizeMapping = normalizeMapping;

const buildMap = mapping => {
  return normalizeMapping(_constants.SUPPORTED_SOURCE_FIELDS, mapping).reduce((fieldsMap, field) => {
    const {
      source,
      target,
      actionType
    } = field;
    fieldsMap.set(source, {
      target,
      actionType
    });
    fieldsMap.set(target, {
      target: source,
      actionType
    });
    return fieldsMap;
  }, new Map());
};

exports.buildMap = buildMap;

const mapParams = (params, mapping) => {
  return Object.keys(params).reduce((prev, curr) => {
    const field = mapping.get(curr);

    if (field) {
      prev[field.target] = (0, _lodash.get)(params, curr);
    }

    return prev;
  }, {});
};

exports.mapParams = mapParams;

const createConnectorExecutor = ({
  api,
  createExternalService
}) => async execOptions => {
  const {
    actionId,
    config,
    params,
    secrets
  } = execOptions;
  const {
    subAction,
    subActionParams
  } = params;
  let data = {};
  const res = {
    status: 'ok',
    actionId
  };
  const externalService = createExternalService({
    config,
    secrets
  });

  if (!api[subAction]) {
    throw new Error('[Action][ExternalService] Unsupported subAction type.');
  }

  if (subAction !== 'pushToService') {
    throw new Error('[Action][ExternalService] subAction not implemented.');
  }

  if (subAction === 'pushToService') {
    const pushToServiceParams = subActionParams;
    const {
      comments,
      externalId,
      ...restParams
    } = pushToServiceParams;
    const mapping = buildMap(config.casesConfiguration.mapping);
    const externalCase = mapParams(restParams, mapping);
    data = await api.pushToService({
      externalService,
      mapping,
      params: { ...pushToServiceParams,
        externalCase
      }
    });
  }

  return { ...res,
    data
  };
};

exports.createConnectorExecutor = createConnectorExecutor;

const createConnector = ({
  api,
  config,
  validate,
  createExternalService,
  validationSchema
}) => {
  return ({
    configurationUtilities,
    executor = createConnectorExecutor({
      api,
      createExternalService
    })
  }) => ({ ...config,
    validate: {
      config: _configSchema.schema.object(validationSchema.config, {
        validate: (0, _lodash.curry)(validate.config)(configurationUtilities)
      }),
      secrets: _configSchema.schema.object(validationSchema.secrets, {
        validate: (0, _lodash.curry)(validate.secrets)(configurationUtilities)
      }),
      params: _schema.ExecutorParamsSchema
    },
    executor
  });
};

exports.createConnector = createConnector;

const prepareFieldsForTransformation = ({
  externalCase,
  mapping,
  defaultPipes = ['informationCreated']
}) => {
  return Object.keys(externalCase).filter(p => {
    var _mapping$get, _mapping$get2;

    return ((_mapping$get = mapping.get(p)) === null || _mapping$get === void 0 ? void 0 : _mapping$get.actionType) != null && ((_mapping$get2 = mapping.get(p)) === null || _mapping$get2 === void 0 ? void 0 : _mapping$get2.actionType) !== 'nothing';
  }).map(p => {
    var _mapping$get$actionTy, _mapping$get3;

    const actionType = (_mapping$get$actionTy = (_mapping$get3 = mapping.get(p)) === null || _mapping$get3 === void 0 ? void 0 : _mapping$get3.actionType) !== null && _mapping$get$actionTy !== void 0 ? _mapping$get$actionTy : 'nothing';
    return {
      key: p,
      value: externalCase[p],
      actionType,
      pipes: actionType === 'append' ? [...defaultPipes, 'append'] : defaultPipes
    };
  });
};

exports.prepareFieldsForTransformation = prepareFieldsForTransformation;

const transformFields = ({
  params,
  fields,
  currentIncident
}) => {
  return fields.reduce((prev, cur) => {
    var _params$updatedAt, _ref;

    const transform = (0, _lodash.flow)(...cur.pipes.map(p => _transformers.transformers[p]));
    return { ...prev,
      [cur.key]: transform({
        value: cur.value,
        date: (_params$updatedAt = params.updatedAt) !== null && _params$updatedAt !== void 0 ? _params$updatedAt : params.createdAt,
        user: (_ref = params.updatedBy != null ? params.updatedBy.fullName ? params.updatedBy.fullName : params.updatedBy.username : params.createdBy.fullName ? params.createdBy.fullName : params.createdBy.username) !== null && _ref !== void 0 ? _ref : '',
        previousValue: currentIncident ? currentIncident[cur.key] : ''
      }).value
    };
  }, {});
};

exports.transformFields = transformFields;

const transformComments = (comments, pipes) => {
  return comments.map(c => {
    var _c$updatedAt, _ref2;

    return { ...c,
      comment: (0, _lodash.flow)(...pipes.map(p => _transformers.transformers[p]))({
        value: c.comment,
        date: (_c$updatedAt = c.updatedAt) !== null && _c$updatedAt !== void 0 ? _c$updatedAt : c.createdAt,
        user: (_ref2 = c.updatedBy != null ? c.updatedBy.fullName ? c.updatedBy.fullName : c.updatedBy.username : c.createdBy.fullName ? c.createdBy.fullName : c.createdBy.username) !== null && _ref2 !== void 0 ? _ref2 : ''
      }).value
    };
  });
};

exports.transformComments = transformComments;

const getErrorMessage = (connector, msg) => {
  return `[Action][${connector}]: ${msg}`;
};

exports.getErrorMessage = getErrorMessage;