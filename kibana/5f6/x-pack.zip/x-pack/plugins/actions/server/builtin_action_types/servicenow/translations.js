"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.MAPPING_EMPTY = exports.WHITE_LISTED_ERROR = exports.NAME = void 0;

var _i18n = require("@kbn/i18n");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
const NAME = _i18n.i18n.translate('xpack.actions.builtin.servicenowTitle', {
  defaultMessage: 'ServiceNow'
});

exports.NAME = NAME;

const WHITE_LISTED_ERROR = message => _i18n.i18n.translate('xpack.actions.builtin.configuration.apiWhitelistError', {
  defaultMessage: 'error configuring connector action: {message}',
  values: {
    message
  }
}); // TODO: remove when Case mappings will be removed


exports.WHITE_LISTED_ERROR = WHITE_LISTED_ERROR;

const MAPPING_EMPTY = _i18n.i18n.translate('xpack.actions.builtin.servicenow.configuration.emptyMapping', {
  defaultMessage: '[incidentConfiguration.mapping]: expected non-empty but got empty'
});

exports.MAPPING_EMPTY = MAPPING_EMPTY;