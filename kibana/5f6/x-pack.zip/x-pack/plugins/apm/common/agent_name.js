"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.isAgentName = isAgentName;
exports.isRumAgentName = isRumAgentName;
exports.isJavaAgentName = isJavaAgentName;
exports.getNormalizedAgentName = getNormalizedAgentName;
exports.RUM_AGENTS = exports.AGENT_NAMES = void 0;

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */

/*
 * Agent names can be any string. This list only defines the official agents
 * that we might want to target specifically eg. linking to their documentation
 * & telemetry reporting. Support additional agent types by appending
 * definitions in mappings.json (for telemetry), the AgentName type, and the
 * AGENT_NAMES array.
 */
const AGENT_NAMES = ['dotnet', 'go', 'java', 'js-base', 'nodejs', 'python', 'ruby', 'rum-js'];
exports.AGENT_NAMES = AGENT_NAMES;

function isAgentName(agentName) {
  return AGENT_NAMES.includes(agentName);
}

const RUM_AGENTS = ['js-base', 'rum-js'];
exports.RUM_AGENTS = RUM_AGENTS;

function isRumAgentName(agentName) {
  return RUM_AGENTS.includes(agentName);
}

function isJavaAgentName(agentName) {
  return agentName === 'java';
}
/**
 * "Normalizes" and agent name by:
 *
 * * Converting to lowercase
 * * Converting "rum-js" to "js-base"
 *
 * This helps dealing with some older agent versions
 */


function getNormalizedAgentName(agentName) {
  const lowercased = agentName && agentName.toLowerCase();
  return isRumAgentName(lowercased) ? 'js-base' : lowercased;
}