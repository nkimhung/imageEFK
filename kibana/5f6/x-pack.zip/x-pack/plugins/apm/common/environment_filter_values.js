"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getEnvironmentLabel = getEnvironmentLabel;
exports.ENVIRONMENT_NOT_DEFINED = exports.ENVIRONMENT_ALL = void 0;

var _i18n = require("@kbn/i18n");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
const ENVIRONMENT_ALL = 'ENVIRONMENT_ALL';
exports.ENVIRONMENT_ALL = ENVIRONMENT_ALL;
const ENVIRONMENT_NOT_DEFINED = 'ENVIRONMENT_NOT_DEFINED';
exports.ENVIRONMENT_NOT_DEFINED = ENVIRONMENT_NOT_DEFINED;

function getEnvironmentLabel(environment) {
  if (environment === ENVIRONMENT_NOT_DEFINED) {
    return _i18n.i18n.translate('xpack.apm.filter.environment.notDefinedLabel', {
      defaultMessage: 'Not defined'
    });
  }

  return environment;
}