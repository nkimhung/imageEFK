/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import d3 from 'd3';
export var getEmptySeries = function getEmptySeries() {
  var start = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : Date.now() - 3600000;
  var end = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : Date.now();
  var dates = d3.time.scale().domain([new Date(start), new Date(end)]).ticks();
  return [{
    title: '',
    type: 'line',
    legendValue: '',
    color: '',
    data: dates.map(function (x) {
      return {
        x: x.getTime(),
        y: null
      };
    })
  }];
};