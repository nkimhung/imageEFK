/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiCard, EuiFlexGroup, EuiFlexItem } from '@elastic/eui';
import { storiesOf } from '@storybook/react';
import cytoscape from 'cytoscape';
import React from 'react';
import { Cytoscape } from '../Cytoscape';
import { iconForNode } from '../icons';
import { EuiThemeProvider } from '../../../../../../observability/public';
storiesOf('app/ServiceMap/Cytoscape', module).addDecorator(function (storyFn) {
  return /*#__PURE__*/React.createElement(EuiThemeProvider, null, storyFn());
}).add('example', function () {
  var elements = [{
    data: {
      id: 'opbeans-python',
      'service.name': 'opbeans-python',
      'agent.name': 'python'
    }
  }, {
    data: {
      id: 'opbeans-node',
      'service.name': 'opbeans-node',
      'agent.name': 'nodejs'
    }
  }, {
    data: {
      id: 'opbeans-ruby',
      'service.name': 'opbeans-ruby',
      'agent.name': 'ruby'
    }
  }, {
    data: {
      source: 'opbeans-python',
      target: 'opbeans-node'
    }
  }, {
    data: {
      bidirectional: true,
      source: 'opbeans-python',
      target: 'opbeans-ruby'
    }
  }];
  var height = 300;
  var width = 1340;
  var serviceName = 'opbeans-python';
  return /*#__PURE__*/React.createElement(Cytoscape, {
    elements: elements,
    height: height,
    width: width,
    serviceName: serviceName
  });
}, {
  info: {
    propTables: false,
    source: false
  }
});
storiesOf('app/ServiceMap/Cytoscape', module).add('node icons', function () {
  var cy = cytoscape();
  var elements = [{
    data: {
      id: 'default'
    }
  }, {
    data: {
      id: 'aws',
      'span.type': 'aws',
      'span.subtype': 'servicename'
    }
  }, {
    data: {
      id: 'cache',
      'span.type': 'cache'
    }
  }, {
    data: {
      id: 'database',
      'span.type': 'db'
    }
  }, {
    data: {
      id: 'cassandra',
      'span.type': 'db',
      'span.subtype': 'cassandra'
    }
  }, {
    data: {
      id: 'elasticsearch',
      'span.type': 'db',
      'span.subtype': 'elasticsearch'
    }
  }, {
    data: {
      id: 'mongodb',
      'span.type': 'db',
      'span.subtype': 'mongodb'
    }
  }, {
    data: {
      id: 'mysql',
      'span.type': 'db',
      'span.subtype': 'mysql'
    }
  }, {
    data: {
      id: 'postgresql',
      'span.type': 'db',
      'span.subtype': 'postgresql'
    }
  }, {
    data: {
      id: 'redis',
      'span.type': 'db',
      'span.subtype': 'redis'
    }
  }, {
    data: {
      id: 'external',
      'span.type': 'external'
    }
  }, {
    data: {
      id: 'ext',
      'span.type': 'ext'
    }
  }, {
    data: {
      id: 'graphql',
      'span.type': 'external',
      'span.subtype': 'graphql'
    }
  }, {
    data: {
      id: 'grpc',
      'span.type': 'external',
      'span.subtype': 'grpc'
    }
  }, {
    data: {
      id: 'websocket',
      'span.type': 'external',
      'span.subtype': 'websocket'
    }
  }, {
    data: {
      id: 'messaging',
      'span.type': 'messaging'
    }
  }, {
    data: {
      id: 'jms',
      'span.type': 'messaging',
      'span.subtype': 'jms'
    }
  }, {
    data: {
      id: 'kafka',
      'span.type': 'messaging',
      'span.subtype': 'kafka'
    }
  }, {
    data: {
      id: 'template',
      'span.type': 'template'
    }
  }, {
    data: {
      id: 'handlebars',
      'span.type': 'template',
      'span.subtype': 'handlebars'
    }
  }, {
    data: {
      id: 'dark',
      'service.name': 'dark service',
      'agent.name': 'dark'
    }
  }, {
    data: {
      id: 'dotnet',
      'service.name': 'dotnet service',
      'agent.name': 'dotnet'
    }
  }, {
    data: {
      id: 'dotNet',
      'service.name': 'dotNet service',
      'agent.name': 'dotNet'
    }
  }, {
    data: {
      id: 'go',
      'service.name': 'go service',
      'agent.name': 'go'
    }
  }, {
    data: {
      id: 'java',
      'service.name': 'java service',
      'agent.name': 'java'
    }
  }, {
    data: {
      id: 'RUM (js-base)',
      'service.name': 'RUM service',
      'agent.name': 'js-base'
    }
  }, {
    data: {
      id: 'RUM (rum-js)',
      'service.name': 'RUM service',
      'agent.name': 'rum-js'
    }
  }, {
    data: {
      id: 'nodejs',
      'service.name': 'nodejs service',
      'agent.name': 'nodejs'
    }
  }, {
    data: {
      id: 'php',
      'service.name': 'php service',
      'agent.name': 'php'
    }
  }, {
    data: {
      id: 'python',
      'service.name': 'python service',
      'agent.name': 'python'
    }
  }, {
    data: {
      id: 'ruby',
      'service.name': 'ruby service',
      'agent.name': 'ruby'
    }
  }];
  cy.add(elements);
  return /*#__PURE__*/React.createElement(EuiFlexGroup, {
    gutterSize: "l",
    wrap: true
  }, cy.nodes().map(function (node) {
    return /*#__PURE__*/React.createElement(EuiFlexItem, {
      key: node.data('id')
    }, /*#__PURE__*/React.createElement(EuiCard, {
      description: /*#__PURE__*/React.createElement("code", {
        style: {
          textAlign: 'left',
          whiteSpace: 'nowrap'
        }
      }, "agent.name: ", node.data('agent.name') || 'undefined', /*#__PURE__*/React.createElement("br", null), "span.type: ", node.data('span.type') || 'undefined', /*#__PURE__*/React.createElement("br", null), "span.subtype: ", node.data('span.subtype') || 'undefined'),
      icon: /*#__PURE__*/React.createElement("img", {
        alt: node.data('label'),
        src: iconForNode(node),
        height: 80,
        width: 80
      }),
      title: node.data('id')
    }));
  }));
}, {
  info: {
    propTables: false,
    source: false
  }
});
storiesOf('app/ServiceMap/Cytoscape', module).add('node severity', function () {
  var elements = [{
    data: {
      id: 'undefined',
      'service.name': 'severity: undefined'
    }
  }, {
    data: {
      id: 'warning',
      'service.name': 'severity: warning',
      severity: 'warning'
    }
  }, {
    data: {
      id: 'minor',
      'service.name': 'severity: minor',
      severity: 'minor'
    }
  }, {
    data: {
      id: 'major',
      'service.name': 'severity: major',
      severity: 'major'
    }
  }, {
    data: {
      id: 'critical',
      'service.name': 'severity: critical',
      severity: 'critical'
    }
  }];
  return /*#__PURE__*/React.createElement(Cytoscape, {
    elements: elements,
    height: 600,
    width: 1340
  });
}, {
  info: {
    propTables: false,
    source: false
  }
});