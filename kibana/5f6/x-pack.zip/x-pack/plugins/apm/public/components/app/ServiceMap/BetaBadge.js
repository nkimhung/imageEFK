/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiBetaBadge } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React from 'react';
import styled from 'styled-components';
var BetaBadgeContainer = styled.div.withConfig({
  displayName: "BetaBadgeContainer",
  componentId: "sc-1hpz46-0"
})(["right:", ";position:absolute;top:", ";z-index:1;"], function (_ref) {
  var theme = _ref.theme;
  return theme.eui.gutterTypes.gutterMedium;
}, function (_ref2) {
  var theme = _ref2.theme;
  return theme.eui.gutterTypes.gutterSmall;
});
export function BetaBadge() {
  return /*#__PURE__*/React.createElement(BetaBadgeContainer, null, /*#__PURE__*/React.createElement(EuiBetaBadge, {
    label: i18n.translate('xpack.apm.serviceMap.betaBadge', {
      defaultMessage: 'Beta'
    }),
    tooltipContent: i18n.translate('xpack.apm.serviceMap.betaTooltipMessage', {
      defaultMessage: 'This feature is currently in beta. If you encounter any bugs or have feedback, please open an issue or visit our discussion forum.'
    })
  }));
}