/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiEmptyPrompt } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React from 'react';

var EmptyMessage = function EmptyMessage(_ref) {
  var _ref$heading = _ref.heading,
      heading = _ref$heading === void 0 ? i18n.translate('xpack.apm.emptyMessage.noDataFoundLabel', {
    defaultMessage: 'No data found.'
  }) : _ref$heading,
      _ref$subheading = _ref.subheading,
      subheading = _ref$subheading === void 0 ? i18n.translate('xpack.apm.emptyMessage.noDataFoundDescription', {
    defaultMessage: 'Try another time range or reset the search filter.'
  }) : _ref$subheading,
      _ref$hideSubheading = _ref.hideSubheading,
      hideSubheading = _ref$hideSubheading === void 0 ? false : _ref$hideSubheading;
  return /*#__PURE__*/React.createElement(EuiEmptyPrompt, {
    titleSize: "s",
    title: /*#__PURE__*/React.createElement("div", null, heading),
    body: !hideSubheading && subheading
  });
};

export { EmptyMessage };