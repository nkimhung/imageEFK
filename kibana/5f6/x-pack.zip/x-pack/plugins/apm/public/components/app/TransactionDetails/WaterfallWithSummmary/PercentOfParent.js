/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { i18n } from '@kbn/i18n';
import { EuiToolTip } from '@elastic/eui';
import { asPercent } from '../../../../utils/formatters';
export function PercentOfParent(_ref) {
  var duration = _ref.duration,
      totalDuration = _ref.totalDuration,
      parentType = _ref.parentType;
  totalDuration = totalDuration || duration;
  var isOver100 = duration > totalDuration;
  var percentOfParent = isOver100 ? '>100%' : asPercent(duration, totalDuration, '');
  var percentOfParentText = i18n.translate('xpack.apm.percentOfParent', {
    defaultMessage: '({value} of {parentType, select, transaction { transaction } trace {trace} })',
    values: {
      value: percentOfParent,
      parentType: parentType
    }
  });
  var childType = parentType === 'trace' ? 'transaction' : 'span';
  return /*#__PURE__*/React.createElement(React.Fragment, null, isOver100 ? /*#__PURE__*/React.createElement(EuiToolTip, {
    content: i18n.translate('xpack.apm.transactionDetails.percentOfTraceLabelExplanation', {
      defaultMessage: 'The % of {parentType, select, transaction {transaction} trace {trace} } exceeds 100% because this {childType, select, span {span} transaction {transaction} } takes longer than the root transaction.',
      values: {
        parentType: parentType,
        childType: childType
      }
    })
  }, /*#__PURE__*/React.createElement(React.Fragment, null, percentOfParentText)) : percentOfParentText);
}