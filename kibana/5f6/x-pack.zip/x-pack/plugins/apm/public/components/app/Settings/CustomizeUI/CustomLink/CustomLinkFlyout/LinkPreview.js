function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React, { useEffect, useState } from 'react';
import { EuiPanel, EuiText, EuiSpacer, EuiLink, EuiToolTip, EuiIcon, EuiFlexGroup, EuiFlexItem } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import { debounce } from 'lodash';
import { callApmApi } from '../../../../../../services/rest/createCallApmApi';
import { replaceTemplateVariables, convertFiltersToQuery } from './helper';
var fetchTransaction = debounce( /*#__PURE__*/function () {
  var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(filters, callback) {
    var transaction;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return callApmApi({
              pathname: '/api/apm/settings/custom_links/transaction',
              params: {
                query: convertFiltersToQuery(filters)
              }
            });

          case 2:
            transaction = _context.sent;
            callback(transaction);

          case 4:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function (_x, _x2) {
    return _ref.apply(this, arguments);
  };
}(), 1000);

var getTextColor = function getTextColor(value) {
  return value ? 'default' : 'subdued';
};

export var LinkPreview = function LinkPreview(_ref2) {
  var label = _ref2.label,
      url = _ref2.url,
      filters = _ref2.filters;

  var _useState = useState(),
      _useState2 = _slicedToArray(_useState, 2),
      transaction = _useState2[0],
      setTransaction = _useState2[1];

  useEffect(function () {
    /*
      React throwns "Can't perform a React state update on an unmounted component"
      It happens when the Custom Link flyout is closed before the return of the api request.
      To avoid such case, sets the isUnmounted to true when component unmount and check its value before update the transaction.
    */
    var isUnmounted = false;
    fetchTransaction(filters, function (_transaction) {
      if (!isUnmounted) {
        setTransaction(_transaction);
      }
    });
    return function () {
      isUnmounted = true;
    };
  }, [filters]);

  var _replaceTemplateVaria = replaceTemplateVariables(url, transaction),
      formattedUrl = _replaceTemplateVaria.formattedUrl,
      error = _replaceTemplateVaria.error;

  return /*#__PURE__*/React.createElement(EuiPanel, {
    betaBadgeLabel: "Preview",
    paddingSize: "l"
  }, /*#__PURE__*/React.createElement(EuiText, {
    size: "s",
    color: getTextColor(label),
    className: "eui-textBreakWord",
    "data-test-subj": "preview-label"
  }, label ? label : i18n.translate('xpack.apm.settings.customizeUI.customLink.default.label', {
    defaultMessage: 'Elastic.co'
  })), /*#__PURE__*/React.createElement(EuiText, {
    size: "s",
    color: getTextColor(url),
    className: "eui-textBreakWord",
    "data-test-subj": "preview-url"
  }, url ? /*#__PURE__*/React.createElement(EuiLink, {
    href: formattedUrl,
    target: "_blank",
    "data-test-subj": "preview-link"
  }, formattedUrl) : i18n.translate('xpack.apm.settings.customizeUI.customLink.default.url', {
    defaultMessage: 'https://www.elastic.co'
  })), /*#__PURE__*/React.createElement(EuiSpacer, null), /*#__PURE__*/React.createElement(EuiFlexGroup, {
    justifyContent: "spaceBetween"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiText, {
    size: "s",
    color: "subdued"
  }, i18n.translate('xpack.apm.settings.customizeUI.customLink.linkPreview.descrition', {
    defaultMessage: 'Test your link with values from an example transaction document based on the filters above.'
  }))), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, error && /*#__PURE__*/React.createElement(EuiToolTip, {
    position: "top",
    content: error
  }, /*#__PURE__*/React.createElement(EuiIcon, {
    type: "alert",
    color: "warning",
    "data-test-subj": "preview-warning"
  })))));
};