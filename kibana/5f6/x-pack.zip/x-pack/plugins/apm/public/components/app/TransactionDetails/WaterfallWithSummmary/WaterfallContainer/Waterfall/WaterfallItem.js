/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import styled from 'styled-components';
import { EuiIcon, EuiText, EuiTitle, EuiToolTip } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import { isRumAgentName } from '../../../../../../../common/agent_name';
import { px, unit, units } from '../../../../../../style/variables';
import { asDuration } from '../../../../../../utils/formatters';
import { ErrorCount } from '../../ErrorCount';
import { ErrorOverviewLink } from '../../../../../shared/Links/apm/ErrorOverviewLink';
import { TRACE_ID } from '../../../../../../../common/elasticsearch_fieldnames';
import { SyncBadge } from './SyncBadge';
var Container = styled.div.withConfig({
  displayName: "Container",
  componentId: "mkivh2-0"
})(["position:relative;display:block;user-select:none;padding-top:", ";padding-bottom:", ";margin-right:", ";margin-left:", ";border-top:1px solid ", ";background-color:", ";cursor:pointer;&:hover{background-color:", ";}"], px(units.half), px(units.plus), function (props) {
  return px(props.timelineMargins.right);
}, function (props) {
  return px(props.timelineMargins.left);
}, function (_ref) {
  var theme = _ref.theme;
  return theme.eui.euiColorLightShade;
}, function (_ref2) {
  var isSelected = _ref2.isSelected,
      theme = _ref2.theme;
  return isSelected ? theme.eui.euiColorLightestShade : 'initial';
}, function (_ref3) {
  var theme = _ref3.theme;
  return theme.eui.euiColorLightestShade;
});
var ItemBar = styled.div.withConfig({
  displayName: "ItemBar",
  componentId: "mkivh2-1"
})(["box-sizing:border-box;position:relative;height:", ";min-width:2px;background-color:", ";"], px(unit), function (props) {
  return props.color;
});
var ItemText = styled.span.withConfig({
  displayName: "ItemText",
  componentId: "mkivh2-2"
})(["position:absolute;right:0;display:flex;align-items:center;height:", ";& > *{margin-right:", ";white-space:nowrap;}"], px(units.plus), px(units.half));

function PrefixIcon(_ref4) {
  var item = _ref4.item;

  switch (item.docType) {
    case 'span':
      {
        // icon for database spans
        var isDbType = item.doc.span.type.startsWith('db');

        if (isDbType) {
          return /*#__PURE__*/React.createElement(EuiIcon, {
            type: "database"
          });
        } // omit icon for other spans


        return null;
      }

    case 'transaction':
      {
        // icon for RUM agent transactions
        if (isRumAgentName(item.doc.agent.name)) {
          return /*#__PURE__*/React.createElement(EuiIcon, {
            type: "globe"
          });
        } // icon for other transactions


        return /*#__PURE__*/React.createElement(EuiIcon, {
          type: "merge"
        });
      }

    default:
      return null;
  }
}

var SpanActionToolTip = function SpanActionToolTip(_ref5) {
  var item = _ref5.item,
      children = _ref5.children;

  if ((item === null || item === void 0 ? void 0 : item.docType) === 'span') {
    return /*#__PURE__*/React.createElement(EuiToolTip, {
      content: "".concat(item.doc.span.subtype, ".").concat(item.doc.span.action)
    }, /*#__PURE__*/React.createElement(React.Fragment, null, children));
  }

  return /*#__PURE__*/React.createElement(React.Fragment, null, children);
};

function Duration(_ref6) {
  var item = _ref6.item;
  return /*#__PURE__*/React.createElement(EuiText, {
    color: "subdued",
    size: "xs"
  }, asDuration(item.duration));
}

function HttpStatusCode(_ref7) {
  var item = _ref7.item;
  // http status code for transactions of type 'request'
  var httpStatusCode = item.docType === 'transaction' && item.doc.transaction.type === 'request' ? item.doc.transaction.result : undefined;

  if (!httpStatusCode) {
    return null;
  }

  return /*#__PURE__*/React.createElement(EuiText, {
    size: "xs"
  }, httpStatusCode);
}

function NameLabel(_ref8) {
  var item = _ref8.item;

  switch (item.docType) {
    case 'span':
      return /*#__PURE__*/React.createElement(EuiText, {
        size: "s"
      }, item.doc.span.name);

    case 'transaction':
      return /*#__PURE__*/React.createElement(EuiTitle, {
        size: "xxs"
      }, /*#__PURE__*/React.createElement("h5", null, item.doc.transaction.name));

    default:
      return null;
  }
}

export function WaterfallItem(_ref9) {
  var timelineMargins = _ref9.timelineMargins,
      totalDuration = _ref9.totalDuration,
      item = _ref9.item,
      color = _ref9.color,
      isSelected = _ref9.isSelected,
      errorCount = _ref9.errorCount,
      onClick = _ref9.onClick;

  if (!totalDuration) {
    return null;
  }

  var width = item.duration / totalDuration * 100;
  var left = (item.offset + item.skew) / totalDuration * 100;
  var tooltipContent = i18n.translate('xpack.apm.transactionDetails.errorsOverviewLinkTooltip', {
    values: {
      errorCount: errorCount
    },
    defaultMessage: '{errorCount, plural, one {View 1 related error} other {View # related errors}}'
  });
  return /*#__PURE__*/React.createElement(Container, {
    type: item.docType,
    timelineMargins: timelineMargins,
    isSelected: isSelected,
    onClick: onClick
  }, /*#__PURE__*/React.createElement(ItemBar // using inline styles instead of props to avoid generating a css class for each item
  , {
    style: {
      left: "".concat(left, "%"),
      width: "".concat(width, "%")
    },
    color: color,
    type: item.docType
  }), /*#__PURE__*/React.createElement(ItemText // using inline styles instead of props to avoid generating a css class for each item
  , {
    style: {
      minWidth: "".concat(Math.max(100 - left, 0), "%")
    }
  }, /*#__PURE__*/React.createElement(SpanActionToolTip, {
    item: item
  }, /*#__PURE__*/React.createElement(PrefixIcon, {
    item: item
  })), /*#__PURE__*/React.createElement(HttpStatusCode, {
    item: item
  }), /*#__PURE__*/React.createElement(NameLabel, {
    item: item
  }), errorCount > 0 && item.docType === 'transaction' ? /*#__PURE__*/React.createElement(ErrorOverviewLink, {
    serviceName: item.doc.service.name,
    query: {
      kuery: encodeURIComponent("".concat(TRACE_ID, " : \"").concat(item.doc.trace.id, "\" and transaction.id : \"").concat(item.doc.transaction.id, "\""))
    },
    color: "danger",
    style: {
      textDecoration: 'none'
    }
  }, /*#__PURE__*/React.createElement(EuiToolTip, {
    content: tooltipContent
  }, /*#__PURE__*/React.createElement(ErrorCount, {
    count: errorCount
  }))) : null, /*#__PURE__*/React.createElement(Duration, {
    item: item
  }), item.docType === 'span' && /*#__PURE__*/React.createElement(SyncBadge, {
    sync: item.doc.span.sync
  })));
}