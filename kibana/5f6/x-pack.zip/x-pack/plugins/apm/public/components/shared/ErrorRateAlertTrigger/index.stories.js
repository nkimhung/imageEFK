/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { storiesOf } from '@storybook/react';
import React from 'react';
import { ErrorRateAlertTrigger } from '.';
import { mockApmPluginContextValue, MockApmPluginContextWrapper } from '../../../context/ApmPluginContext/MockApmPluginContext';
storiesOf('app/ErrorRateAlertTrigger', module).add('example', function () {
  var params = {
    threshold: 2,
    window: '5m'
  };
  return /*#__PURE__*/React.createElement(MockApmPluginContextWrapper, {
    value: mockApmPluginContextValue
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 400
    }
  }, /*#__PURE__*/React.createElement(ErrorRateAlertTrigger, {
    alertParams: params,
    setAlertParams: function setAlertParams() {
      return undefined;
    },
    setAlertProperty: function setAlertProperty() {
      return undefined;
    }
  })));
});