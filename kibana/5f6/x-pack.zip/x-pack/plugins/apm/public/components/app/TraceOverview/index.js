function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiPanel, EuiFlexGroup, EuiFlexItem, EuiSpacer } from '@elastic/eui';
import React, { useMemo } from 'react';
import { FETCH_STATUS, useFetcher } from '../../../hooks/useFetcher';
import { TraceList } from './TraceList';
import { useUrlParams } from '../../../hooks/useUrlParams';
import { useTrackPageview } from '../../../../../observability/public';
import { LocalUIFilters } from '../../shared/LocalUIFilters';
import { PROJECTION } from '../../../../common/projections/typings';
var DEFAULT_RESPONSE = {
  items: [],
  isAggregationAccurate: true,
  bucketSize: 0
};
export function TraceOverview() {
  var _useUrlParams = useUrlParams(),
      urlParams = _useUrlParams.urlParams,
      uiFilters = _useUrlParams.uiFilters;

  var start = urlParams.start,
      end = urlParams.end;

  var _useFetcher = useFetcher(function (callApmApi) {
    if (start && end) {
      return callApmApi({
        pathname: '/api/apm/traces',
        params: {
          query: {
            start: start,
            end: end,
            uiFilters: JSON.stringify(uiFilters)
          }
        }
      });
    }
  }, [start, end, uiFilters]),
      status = _useFetcher.status,
      _useFetcher$data = _useFetcher.data,
      data = _useFetcher$data === void 0 ? DEFAULT_RESPONSE : _useFetcher$data;

  useTrackPageview({
    app: 'apm',
    path: 'traces_overview'
  });
  useTrackPageview({
    app: 'apm',
    path: 'traces_overview',
    delay: 15000
  });
  var localUIFiltersConfig = useMemo(function () {
    var config = {
      filterNames: ['transactionResult', 'host', 'containerId', 'podName'],
      projection: PROJECTION.TRACES
    };
    return config;
  }, []);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiSpacer, null), /*#__PURE__*/React.createElement(EuiFlexGroup, null, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: 1
  }, /*#__PURE__*/React.createElement(LocalUIFilters, _extends({}, localUIFiltersConfig, {
    showCount: false
  }))), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: 7
  }, /*#__PURE__*/React.createElement(EuiPanel, null, /*#__PURE__*/React.createElement(TraceList, {
    items: data.items,
    isLoading: status === FETCH_STATUS.LOADING
  })))));
}