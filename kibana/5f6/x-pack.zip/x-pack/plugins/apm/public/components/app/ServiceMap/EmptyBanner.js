function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React, { useContext, useEffect, useState } from 'react';
import { EuiCallOut } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import styled from 'styled-components';
import { ElasticDocsLink } from '../../shared/Links/ElasticDocsLink';
import { CytoscapeContext } from './Cytoscape';
import { useTheme } from '../../../hooks/useTheme';
var EmptyBannerContainer = styled.div.withConfig({
  displayName: "EmptyBannerContainer",
  componentId: "vw5rtg-0"
})(["margin:", ";left:calc( ", " + ", " );position:absolute;z-index:1;"], function (_ref) {
  var theme = _ref.theme;
  return theme.eui.gutterTypes.gutterSmall;
}, function (_ref2) {
  var theme = _ref2.theme;
  return theme.eui.gutterTypes.gutterExtraLarge;
}, function (_ref3) {
  var theme = _ref3.theme;
  return theme.eui.gutterTypes.gutterSmall;
});
export function EmptyBanner() {
  var theme = useTheme();
  var cy = useContext(CytoscapeContext);

  var _useState = useState(0),
      _useState2 = _slicedToArray(_useState, 2),
      nodeCount = _useState2[0],
      setNodeCount = _useState2[1];

  useEffect(function () {
    var handler = function handler(event) {
      return setNodeCount(event.cy.nodes().length);
    };

    if (cy) {
      cy.on('add remove', 'node', handler);
    }

    return function () {
      if (cy) {
        cy.removeListener('add remove', 'node', handler);
      }
    };
  }, [cy]); // Only show if there's a single node.

  if (!cy || nodeCount !== 1) {
    return null;
  } // Since we're absolutely positioned, we need to get the full width and
  // subtract the space for controls and margins.


  var width = cy.width() - parseInt(theme.eui.gutterTypes.gutterExtraLarge, 10) - parseInt(theme.eui.gutterTypes.gutterLarge, 10);
  return /*#__PURE__*/React.createElement(EmptyBannerContainer, {
    style: {
      width: width
    }
  }, /*#__PURE__*/React.createElement(EuiCallOut, {
    title: i18n.translate('xpack.apm.serviceMap.emptyBanner.title', {
      defaultMessage: "Looks like there's only a single service."
    })
  }, i18n.translate('xpack.apm.serviceMap.emptyBanner.message', {
    defaultMessage: "We will map out connected services and external requests if we can detect them. Please make sure you're running the latest version of the APM agent."
  }), ' ', /*#__PURE__*/React.createElement(ElasticDocsLink, {
    section: "/kibana",
    path: "/service-maps.html#service-maps-supported"
  }, i18n.translate('xpack.apm.serviceMap.emptyBanner.docsLink', {
    defaultMessage: 'Learn more in the docs'
  }))));
}