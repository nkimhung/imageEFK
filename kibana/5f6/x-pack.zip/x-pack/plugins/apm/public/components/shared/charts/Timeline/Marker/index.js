/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import styled from 'styled-components';
import { px } from '../../../../../style/variables';
import { AgentMarker } from './AgentMarker';
import { ErrorMarker } from './ErrorMarker';
var MarkerContainer = styled.div.withConfig({
  displayName: "MarkerContainer",
  componentId: "ragw2h-0"
})(["position:absolute;bottom:0;"]);
export var Marker = function Marker(_ref) {
  var mark = _ref.mark,
      x = _ref.x;
  var legendWidth = 11;
  return /*#__PURE__*/React.createElement(MarkerContainer, {
    style: {
      left: px(x - legendWidth / 2)
    }
  }, mark.type === 'errorMark' ? /*#__PURE__*/React.createElement(ErrorMarker, {
    mark: mark
  }) : /*#__PURE__*/React.createElement(AgentMarker, {
    mark: mark
  }));
};