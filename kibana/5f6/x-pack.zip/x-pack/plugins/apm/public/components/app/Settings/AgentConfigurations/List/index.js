function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React, { useState } from 'react';
import { i18n } from '@kbn/i18n';
import { EuiEmptyPrompt, EuiButton, EuiButtonEmpty, EuiHealth, EuiToolTip, EuiButtonIcon } from '@elastic/eui';
import { isEmpty } from 'lodash';
import { useTheme } from '../../../../../hooks/useTheme';
import { FETCH_STATUS } from '../../../../../hooks/useFetcher';
import { ManagedTable } from '../../../../shared/ManagedTable';
import { LoadingStatePrompt } from '../../../../shared/LoadingStatePrompt'; // eslint-disable-next-line @kbn/eslint/no-restricted-paths

import { TimestampTooltip } from '../../../../shared/TimestampTooltip';
import { px, units } from '../../../../../style/variables';
import { getOptionLabel } from '../../../../../../common/agent_configuration/all_option';
import { createAgentConfigurationHref, editAgentConfigurationHref } from '../../../../shared/Links/apm/agentConfigurationLinks';
import { ConfirmDeleteModal } from './ConfirmDeleteModal';
export var AgentConfigurationList = function AgentConfigurationList(_ref) {
  var status = _ref.status,
      data = _ref.data,
      refetch = _ref.refetch;
  var theme = useTheme();

  var _useState = useState(null),
      _useState2 = _slicedToArray(_useState, 2),
      configToBeDeleted = _useState2[0],
      setConfigToBeDeleted = _useState2[1];

  var emptyStatePrompt = /*#__PURE__*/React.createElement(EuiEmptyPrompt, {
    iconType: "controlsHorizontal",
    title: /*#__PURE__*/React.createElement("h2", null, i18n.translate('xpack.apm.agentConfig.configTable.emptyPromptTitle', {
      defaultMessage: 'No configurations found.'
    })),
    body: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("p", null, i18n.translate('xpack.apm.agentConfig.configTable.emptyPromptText', {
      defaultMessage: "Let's change that! You can fine-tune agent configuration directly from Kibana without having to redeploy. Get started by creating your first configuration."
    }))),
    actions: /*#__PURE__*/React.createElement(EuiButton, {
      color: "primary",
      fill: true,
      href: createAgentConfigurationHref()
    }, i18n.translate('xpack.apm.agentConfig.configTable.createConfigButtonLabel', {
      defaultMessage: 'Create configuration'
    }))
  });
  var failurePrompt = /*#__PURE__*/React.createElement(EuiEmptyPrompt, {
    iconType: "alert",
    body: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("p", null, i18n.translate('xpack.apm.agentConfig.configTable.configTable.failurePromptText', {
      defaultMessage: 'The list of agent configurations could not be fetched. Your user may not have the sufficient permissions.'
    })))
  });

  if (status === FETCH_STATUS.FAILURE) {
    return failurePrompt;
  }

  if (status === FETCH_STATUS.SUCCESS && isEmpty(data)) {
    return emptyStatePrompt;
  }

  var columns = [{
    field: 'applied_by_agent',
    align: 'center',
    width: px(units.double),
    name: '',
    sortable: true,
    render: function render(isApplied) {
      return /*#__PURE__*/React.createElement(EuiToolTip, {
        content: isApplied ? i18n.translate('xpack.apm.agentConfig.configTable.appliedTooltipMessage', {
          defaultMessage: 'Applied by at least one agent'
        }) : i18n.translate('xpack.apm.agentConfig.configTable.notAppliedTooltipMessage', {
          defaultMessage: 'Not yet applied by any agents'
        })
      }, /*#__PURE__*/React.createElement(EuiHealth, {
        color: isApplied ? 'success' : theme.eui.euiColorLightShade
      }));
    }
  }, {
    field: 'service.name',
    name: i18n.translate('xpack.apm.agentConfig.configTable.serviceNameColumnLabel', {
      defaultMessage: 'Service name'
    }),
    sortable: true,
    render: function render(_, config) {
      return /*#__PURE__*/React.createElement(EuiButtonEmpty, {
        flush: "left",
        size: "s",
        color: "primary",
        href: editAgentConfigurationHref(config.service)
      }, getOptionLabel(config.service.name));
    }
  }, {
    field: 'service.environment',
    name: i18n.translate('xpack.apm.agentConfig.configTable.environmentColumnLabel', {
      defaultMessage: 'Service environment'
    }),
    sortable: true,
    render: function render(environment) {
      return getOptionLabel(environment);
    }
  }, {
    align: 'right',
    field: '@timestamp',
    name: i18n.translate('xpack.apm.agentConfig.configTable.lastUpdatedColumnLabel', {
      defaultMessage: 'Last updated'
    }),
    sortable: true,
    render: function render(value) {
      return /*#__PURE__*/React.createElement(TimestampTooltip, {
        time: value,
        timeUnit: "minutes"
      });
    }
  }, {
    width: px(units.double),
    name: '',
    render: function render(config) {
      return /*#__PURE__*/React.createElement(EuiButtonIcon, {
        "aria-label": "Edit",
        iconType: "pencil",
        href: editAgentConfigurationHref(config.service)
      });
    }
  }, {
    width: px(units.double),
    name: '',
    render: function render(config) {
      return /*#__PURE__*/React.createElement(EuiButtonIcon, {
        "aria-label": "Delete",
        iconType: "trash",
        onClick: function onClick() {
          return setConfigToBeDeleted(config);
        }
      });
    }
  }];
  return /*#__PURE__*/React.createElement(React.Fragment, null, configToBeDeleted && /*#__PURE__*/React.createElement(ConfirmDeleteModal, {
    config: configToBeDeleted,
    onCancel: function onCancel() {
      return setConfigToBeDeleted(null);
    },
    onConfirm: function onConfirm() {
      setConfigToBeDeleted(null);
      refetch();
    }
  }), /*#__PURE__*/React.createElement(ManagedTable, {
    noItemsMessage: /*#__PURE__*/React.createElement(LoadingStatePrompt, null),
    columns: columns,
    items: data,
    initialSortField: "service.name",
    initialSortDirection: "asc",
    initialPageSize: 20
  }));
};