/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiTitle } from '@elastic/eui';
import theme from '@elastic/eui/dist/eui_theme_light.json';
import numeral from '@elastic/numeral';
import { i18n } from '@kbn/i18n';
import d3 from 'd3';
import { scaleUtc } from 'd3-scale';
import { mean } from 'lodash';
import React from 'react';
import { asRelativeDateTimeRange } from '../../../../utils/formatters';
import { getTimezoneOffsetInMs } from '../../../shared/charts/CustomPlot/getTimezoneOffsetInMs'; // @ts-ignore

import Histogram from '../../../shared/charts/Histogram';
import { EmptyMessage } from '../../../shared/EmptyMessage';
export function getFormattedBuckets(buckets, bucketSize) {
  if (!buckets) {
    return null;
  }

  return buckets.map(function (_ref) {
    var count = _ref.count,
        key = _ref.key;
    return {
      x0: key,
      x: key + bucketSize,
      y: count
    };
  });
}

var tooltipHeader = function tooltipHeader(bucket) {
  return asRelativeDateTimeRange(bucket.x0, bucket.x);
};

export function ErrorDistribution(_ref2) {
  var distribution = _ref2.distribution,
      title = _ref2.title;
  var buckets = getFormattedBuckets(distribution.buckets, distribution.bucketSize);

  if (!buckets) {
    return /*#__PURE__*/React.createElement(EmptyMessage, {
      heading: i18n.translate('xpack.apm.errorGroupDetails.noErrorsLabel', {
        defaultMessage: 'No errors were found'
      })
    });
  }

  var averageValue = mean(buckets.map(function (bucket) {
    return bucket.y;
  })) || 0;
  var xMin = d3.min(buckets, function (d) {
    return d.x0;
  });
  var xMax = d3.max(buckets, function (d) {
    return d.x;
  });
  var tickFormat = scaleUtc().domain([xMin, xMax]).tickFormat();
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xs"
  }, /*#__PURE__*/React.createElement("span", null, title)), /*#__PURE__*/React.createElement(Histogram, {
    height: 180,
    noHits: distribution.noHits,
    tooltipHeader: tooltipHeader,
    verticalLineHover: function verticalLineHover(bucket) {
      return bucket.x;
    },
    xType: "time-utc",
    formatX: function formatX(value) {
      var time = value.getTime();
      return tickFormat(new Date(time - getTimezoneOffsetInMs(time)));
    },
    buckets: buckets,
    bucketSize: distribution.bucketSize,
    formatYShort: function formatYShort(value) {
      return i18n.translate('xpack.apm.errorGroupDetails.occurrencesShortLabel', {
        defaultMessage: '{occCount} occ.',
        values: {
          occCount: value
        }
      });
    },
    formatYLong: function formatYLong(value) {
      return i18n.translate('xpack.apm.errorGroupDetails.occurrencesLongLabel', {
        defaultMessage: '{occCount} {occCount, plural, one {occurrence} other {occurrences}}',
        values: {
          occCount: value
        }
      });
    },
    legends: [{
      color: theme.euiColorVis1,
      // 0a abbreviates large whole numbers with metric prefixes like: 1000 = 1k, 32000 = 32k, 1000000 = 1m
      legendValue: numeral(averageValue).format('0a'),
      title: i18n.translate('xpack.apm.errorGroupDetails.avgLabel', {
        defaultMessage: 'Avg.'
      }),
      legendClickDisabled: true
    }]
  }));
}