function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React, { useEffect, useRef } from 'react';
export var HeightRetainer = function HeightRetainer(props) {
  var containerElement = useRef(null);
  var minHeight = useRef(0);
  useEffect(function () {
    if (containerElement.current) {
      var currentHeight = containerElement.current.clientHeight;

      if (minHeight.current < currentHeight) {
        minHeight.current = currentHeight;
      }
    }
  });
  return /*#__PURE__*/React.createElement("div", _extends({}, props, {
    ref: containerElement,
    style: {
      minHeight: minHeight.current
    }
  }));
};