function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React, { useState } from 'react';
import { EuiTitle, EuiSpacer, EuiText } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import { EuiPanel, EuiEmptyPrompt } from '@elastic/eui';
import { ML_ERRORS } from '../../../../../common/anomaly_detection';
import { useApmPluginContext } from '../../../../hooks/useApmPluginContext';
import { JobsList } from './jobs_list';
import { AddEnvironments } from './add_environments';
import { useFetcher } from '../../../../hooks/useFetcher';
import { LicensePrompt } from '../../../shared/LicensePrompt';
import { useLicense } from '../../../../hooks/useLicense';
var DEFAULT_VALUE = {
  jobs: [],
  hasLegacyJobs: false
};
export var AnomalyDetection = function AnomalyDetection() {
  var _plugin$core$applicat;

  var plugin = useApmPluginContext();
  var canGetJobs = !!((_plugin$core$applicat = plugin.core.application.capabilities.ml) === null || _plugin$core$applicat === void 0 ? void 0 : _plugin$core$applicat.canGetJobs);
  var license = useLicense();
  var hasValidLicense = (license === null || license === void 0 ? void 0 : license.isActive) && (license === null || license === void 0 ? void 0 : license.hasAtLeast('platinum'));

  var _useState = useState(false),
      _useState2 = _slicedToArray(_useState, 2),
      viewAddEnvironments = _useState2[0],
      setViewAddEnvironments = _useState2[1];

  var _useFetcher = useFetcher(function (callApmApi) {
    if (canGetJobs) {
      return callApmApi({
        pathname: "/api/apm/settings/anomaly-detection"
      });
    }
  }, [canGetJobs], {
    preservePreviousData: false,
    showToastOnError: false
  }),
      refetch = _useFetcher.refetch,
      _useFetcher$data = _useFetcher.data,
      data = _useFetcher$data === void 0 ? DEFAULT_VALUE : _useFetcher$data,
      status = _useFetcher.status;

  if (!hasValidLicense) {
    return /*#__PURE__*/React.createElement(EuiPanel, null, /*#__PURE__*/React.createElement(LicensePrompt, {
      text: ML_ERRORS.INVALID_LICENSE
    }));
  }

  if (!canGetJobs) {
    return /*#__PURE__*/React.createElement(EuiPanel, null, /*#__PURE__*/React.createElement(EuiEmptyPrompt, {
      iconType: "alert",
      body: /*#__PURE__*/React.createElement(React.Fragment, null, ML_ERRORS.MISSING_READ_PRIVILEGES)
    }));
  }

  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "l"
  }, /*#__PURE__*/React.createElement("h1", null, i18n.translate('xpack.apm.settings.anomalyDetection.titleText', {
    defaultMessage: 'Anomaly detection'
  }))), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "l"
  }), /*#__PURE__*/React.createElement(EuiText, null, i18n.translate('xpack.apm.settings.anomalyDetection.descriptionText', {
    defaultMessage: 'The Machine Learning anomaly detection integration enables application health status indicators for each configured environment in the Service map by identifying transaction duration anomalies.'
  })), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "l"
  }), viewAddEnvironments ? /*#__PURE__*/React.createElement(AddEnvironments, {
    currentEnvironments: data.jobs.map(function (_ref) {
      var environment = _ref.environment;
      return environment;
    }),
    onCreateJobSuccess: function onCreateJobSuccess() {
      refetch();
      setViewAddEnvironments(false);
    },
    onCancel: function onCancel() {
      setViewAddEnvironments(false);
    }
  }) : /*#__PURE__*/React.createElement(JobsList, {
    data: data,
    status: status,
    onAddEnvironments: function onAddEnvironments() {
      setViewAddEnvironments(true);
    }
  }));
};