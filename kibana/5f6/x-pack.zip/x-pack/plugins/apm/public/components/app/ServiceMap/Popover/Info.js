/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { i18n } from '@kbn/i18n';
import React from 'react';
import styled from 'styled-components';
import { SPAN_SUBTYPE, SPAN_TYPE } from '../../../../../common/elasticsearch_fieldnames';
var ItemRow = styled.div.withConfig({
  displayName: "ItemRow",
  componentId: "sc-1ttgfc-0"
})(["line-height:2;"]);
var ItemTitle = styled.dt.withConfig({
  displayName: "ItemTitle",
  componentId: "sc-1ttgfc-1"
})(["color:", ";"], function (_ref) {
  var theme = _ref.theme;
  return theme.eui.textColors.subdued;
});
var ItemDescription = styled.dd.withConfig({
  displayName: "ItemDescription",
  componentId: "sc-1ttgfc-2"
})([""]);
export function Info(data) {
  // For nodes with span.type "db", convert it to "database".
  // Otherwise leave it as-is.
  var type = data[SPAN_TYPE] === 'db' ? 'database' : data[SPAN_TYPE]; // Externals should not have a subtype so make it undefined if the type is external.

  var subtype = data[SPAN_TYPE] !== 'external' && data[SPAN_SUBTYPE];
  var listItems = [{
    title: i18n.translate('xpack.apm.serviceMap.typePopoverStat', {
      defaultMessage: 'Type'
    }),
    description: type
  }, {
    title: i18n.translate('xpack.apm.serviceMap.subtypePopoverStat', {
      defaultMessage: 'Subtype'
    }),
    description: subtype
  }];
  return /*#__PURE__*/React.createElement(React.Fragment, null, listItems.map(function (_ref2) {
    var title = _ref2.title,
        description = _ref2.description;
    return description && /*#__PURE__*/React.createElement(ItemRow, {
      key: title
    }, /*#__PURE__*/React.createElement(ItemTitle, null, title), /*#__PURE__*/React.createElement(ItemDescription, null, description));
  }));
}