/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React, { Fragment } from 'react';
import styled from 'styled-components';
import { EuiSpacer, EuiTitle } from '@elastic/eui';
import { borderRadius, fontFamilyCode, fontSize, px, unit, units } from '../../../../../../../style/variables';
var ContextUrl = styled.div.withConfig({
  displayName: "ContextUrl",
  componentId: "e8m2kc-0"
})(["padding:", " ", ";background:", ";border-radius:", ";border:1px solid ", ";font-family:", ";font-size:", ";"], px(units.half), px(unit), function (_ref) {
  var theme = _ref.theme;
  return theme.eui.euiColorLightestShade;
}, borderRadius, function (_ref2) {
  var theme = _ref2.theme;
  return theme.eui.euiColorLightShade;
}, fontFamilyCode, fontSize);
export function HttpContext(_ref3) {
  var _httpContext$url;

  var httpContext = _ref3.httpContext;
  var url = httpContext === null || httpContext === void 0 ? void 0 : (_httpContext$url = httpContext.url) === null || _httpContext$url === void 0 ? void 0 : _httpContext$url.original;

  if (!url) {
    return null;
  }

  return /*#__PURE__*/React.createElement(Fragment, null, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xs"
  }, /*#__PURE__*/React.createElement("h3", null, "HTTP URL")), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "m"
  }), /*#__PURE__*/React.createElement(ContextUrl, null, url), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "l"
  }));
}