function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { i18n } from '@kbn/i18n';
import { callApmApi } from '../../../../services/rest/createCallApmApi';
var errorToastTitle = i18n.translate('xpack.apm.anomalyDetection.createJobs.failed.title', {
  defaultMessage: 'Anomaly detection jobs could not be created'
});
var successToastTitle = i18n.translate('xpack.apm.anomalyDetection.createJobs.succeeded.title', {
  defaultMessage: 'Anomaly detection jobs created'
});
export function createJobs(_x) {
  return _createJobs.apply(this, arguments);
}

function _createJobs() {
  _createJobs = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(_ref) {
    var environments, toasts;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            environments = _ref.environments, toasts = _ref.toasts;
            _context.prev = 1;
            _context.next = 4;
            return callApmApi({
              pathname: '/api/apm/settings/anomaly-detection/jobs',
              method: 'POST',
              params: {
                body: {
                  environments: environments
                }
              }
            });

          case 4:
            toasts.addSuccess({
              title: successToastTitle,
              text: getSuccessToastMessage(environments)
            });
            return _context.abrupt("return", true);

          case 8:
            _context.prev = 8;
            _context.t0 = _context["catch"](1);
            toasts.addDanger({
              title: errorToastTitle,
              text: getErrorToastMessage(environments, _context.t0)
            });
            return _context.abrupt("return", false);

          case 12:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[1, 8]]);
  }));
  return _createJobs.apply(this, arguments);
}

function getSuccessToastMessage(environments) {
  return i18n.translate('xpack.apm.anomalyDetection.createJobs.succeeded.text', {
    defaultMessage: 'Anomaly detection jobs successfully created for APM service environments [{environments}]. It will take some time for machine learning to start analyzing traffic for anomalies.',
    values: {
      environments: environments.join(', ')
    }
  });
}

function getErrorToastMessage(environments, error) {
  return i18n.translate('xpack.apm.anomalyDetection.createJobs.failed.text', {
    defaultMessage: 'Something went wrong when creating one ore more anomaly detection jobs for APM service environments [{environments}]. Error: "{errorMessage}"',
    values: {
      environments: environments.join(', '),
      errorMessage: error.message
    }
  });
}