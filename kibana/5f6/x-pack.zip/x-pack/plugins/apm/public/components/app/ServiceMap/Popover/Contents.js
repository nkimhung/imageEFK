function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiFlexGroup, EuiFlexItem, EuiHorizontalRule, EuiTitle } from '@elastic/eui';
import React from 'react';
import { Buttons } from './Buttons';
import { Info } from './Info';
import { ServiceStatsFetcher } from './ServiceStatsFetcher';
import { popoverWidth } from '../cytoscapeOptions';
// IE 11 does not handle flex properties as expected. With browser detection,
// we can use regular div elements to render contents that are almost identical.
//
// This method of detecting IE is from a Stack Overflow answer:
// https://stackoverflow.com/a/21825207
//
// @ts-ignore `documentMode` is not recognized as a valid property of `document`.
var isIE11 = !!window.MSInputMethodContext && !!document.documentMode;

var FlexColumnGroup = function FlexColumnGroup(props) {
  if (isIE11) {
    var direction = props.direction,
        gutterSize = props.gutterSize,
        rest = _objectWithoutProperties(props, ["direction", "gutterSize"]);

    return /*#__PURE__*/React.createElement("div", rest);
  }

  return /*#__PURE__*/React.createElement(EuiFlexGroup, props);
};

var FlexColumnItem = function FlexColumnItem(props) {
  return isIE11 ? /*#__PURE__*/React.createElement("div", props) : /*#__PURE__*/React.createElement(EuiFlexItem, props);
};

export function Contents(_ref) {
  var selectedNodeData = _ref.selectedNodeData,
      isService = _ref.isService,
      label = _ref.label,
      onFocusClick = _ref.onFocusClick,
      selectedNodeServiceName = _ref.selectedNodeServiceName;
  return /*#__PURE__*/React.createElement(FlexColumnGroup, {
    direction: "column",
    gutterSize: "s",
    style: {
      width: popoverWidth
    }
  }, /*#__PURE__*/React.createElement(FlexColumnItem, null, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xxs"
  }, /*#__PURE__*/React.createElement("h3", null, label)), /*#__PURE__*/React.createElement(EuiHorizontalRule, {
    margin: "xs"
  })), /*#__PURE__*/React.createElement(FlexColumnItem, null, isService ? /*#__PURE__*/React.createElement(ServiceStatsFetcher, {
    serviceName: selectedNodeServiceName,
    serviceAnomalyStats: selectedNodeData.serviceAnomalyStats
  }) : /*#__PURE__*/React.createElement(Info, selectedNodeData)), isService && /*#__PURE__*/React.createElement(Buttons, {
    onFocusClick: onFocusClick,
    selectedNodeServiceName: selectedNodeServiceName
  }));
}