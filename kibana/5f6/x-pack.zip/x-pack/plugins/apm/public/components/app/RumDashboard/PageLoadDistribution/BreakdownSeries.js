/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React, { useEffect } from 'react';
import { CurveType, LineSeries, ScaleType } from '@elastic/charts';
import { useBreakdowns } from './use_breakdowns';
export var BreakdownSeries = function BreakdownSeries(_ref) {
  var field = _ref.field,
      value = _ref.value,
      percentileRange = _ref.percentileRange,
      onLoadingChange = _ref.onLoadingChange;

  var _useBreakdowns = useBreakdowns({
    field: field,
    value: value,
    percentileRange: percentileRange
  }),
      data = _useBreakdowns.data,
      status = _useBreakdowns.status;

  useEffect(function () {
    onLoadingChange(status !== 'success');
  }, [status, onLoadingChange]);
  return /*#__PURE__*/React.createElement(React.Fragment, null, data === null || data === void 0 ? void 0 : data.map(function (_ref2) {
    var seriesData = _ref2.data,
        name = _ref2.name;
    return /*#__PURE__*/React.createElement(LineSeries, {
      id: "".concat(field, "-").concat(value, "-").concat(name),
      key: "".concat(field, "-").concat(value, "-").concat(name),
      name: name,
      xScaleType: ScaleType.Linear,
      yScaleType: ScaleType.Linear,
      data: seriesData !== null && seriesData !== void 0 ? seriesData : [],
      curve: CurveType.CURVE_NATURAL
    });
  }));
};