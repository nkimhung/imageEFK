/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiTitle } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React from 'react';
import { useAvgDurationByCountry } from '../../../../../hooks/useAvgDurationByCountry';
import { ChoroplethMap } from '../ChoroplethMap';
export var DurationByCountryMap = function DurationByCountryMap() {
  var _useAvgDurationByCoun = useAvgDurationByCountry(),
      data = _useAvgDurationByCoun.data;

  return /*#__PURE__*/React.createElement(React.Fragment, null, ' ', /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xs"
  }, /*#__PURE__*/React.createElement("span", null, i18n.translate('xpack.apm.metrics.durationByCountryMap.avgPageLoadByCountryLabel', {
    defaultMessage: 'Avg. page load duration distribution by country'
  }))), /*#__PURE__*/React.createElement(ChoroplethMap, {
    items: data
  }));
};