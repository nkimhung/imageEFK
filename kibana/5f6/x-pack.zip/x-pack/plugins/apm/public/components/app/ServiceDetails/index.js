/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiFlexGroup, EuiFlexItem, EuiTitle, EuiButtonEmpty } from '@elastic/eui';
import React from 'react';
import { i18n } from '@kbn/i18n';
import { ApmHeader } from '../../shared/ApmHeader';
import { ServiceDetailTabs } from './ServiceDetailTabs';
import { useUrlParams } from '../../../hooks/useUrlParams';
import { AlertIntegrations } from './AlertIntegrations';
import { useApmPluginContext } from '../../../hooks/useApmPluginContext';
export function ServiceDetails(_ref) {
  var tab = _ref.tab;
  var plugin = useApmPluginContext();

  var _useUrlParams = useUrlParams(),
      urlParams = _useUrlParams.urlParams;

  var serviceName = urlParams.serviceName;
  var canReadAlerts = !!plugin.core.application.capabilities.apm['alerting:show'];
  var canSaveAlerts = !!plugin.core.application.capabilities.apm['alerting:save'];
  var isAlertingPluginEnabled = ('alerts' in plugin.plugins);
  var isAlertingAvailable = isAlertingPluginEnabled && (canReadAlerts || canSaveAlerts);

  var _useApmPluginContext = useApmPluginContext(),
      core = _useApmPluginContext.core;

  var ADD_DATA_LABEL = i18n.translate('xpack.apm.addDataButtonLabel', {
    defaultMessage: 'Add data'
  });
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(ApmHeader, null, /*#__PURE__*/React.createElement(EuiFlexGroup, {
    alignItems: "center"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "l"
  }, /*#__PURE__*/React.createElement("h1", null, serviceName))), isAlertingAvailable && /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(AlertIntegrations, {
    canReadAlerts: canReadAlerts,
    canSaveAlerts: canSaveAlerts
  })), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiButtonEmpty, {
    href: core.http.basePath.prepend('/app/home#/tutorial/apm'),
    size: "s",
    color: "primary",
    iconType: "plusInCircle"
  }, ADD_DATA_LABEL)))), /*#__PURE__*/React.createElement(ServiceDetailTabs, {
    tab: tab
  }));
}