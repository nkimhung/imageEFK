/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { EuiButton, EuiFlexItem, EuiToolTip } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import { TransactionDetailLink } from '../../../shared/Links/apm/TransactionDetailLink';
export var MaybeViewTraceLink = function MaybeViewTraceLink(_ref) {
  var transaction = _ref.transaction,
      waterfall = _ref.waterfall;
  var viewFullTraceButtonLabel = i18n.translate('xpack.apm.transactionDetails.viewFullTraceButtonLabel', {
    defaultMessage: 'View full trace'
  });
  var rootTransaction = waterfall.rootTransaction; // the traceroot cannot be found, so we cannot link to it

  if (!rootTransaction) {
    return /*#__PURE__*/React.createElement(EuiFlexItem, {
      grow: false
    }, /*#__PURE__*/React.createElement(EuiToolTip, {
      content: i18n.translate('xpack.apm.transactionDetails.noTraceParentButtonTooltip', {
        defaultMessage: 'The trace parent cannot be found'
      })
    }, /*#__PURE__*/React.createElement(EuiButton, {
      iconType: "apmTrace",
      disabled: true
    }, viewFullTraceButtonLabel)));
  }

  var isRoot = transaction.transaction.id === rootTransaction.transaction.id; // the user is already viewing the full trace, so don't link to it

  if (isRoot) {
    return /*#__PURE__*/React.createElement(EuiFlexItem, {
      grow: false
    }, /*#__PURE__*/React.createElement(EuiToolTip, {
      content: i18n.translate('xpack.apm.transactionDetails.viewingFullTraceButtonTooltip', {
        defaultMessage: 'Currently viewing the full trace'
      })
    }, /*#__PURE__*/React.createElement(EuiButton, {
      iconType: "apmTrace",
      disabled: true
    }, viewFullTraceButtonLabel))); // the user is viewing a zoomed in version of the trace. Link to the full trace
  } else {
    return /*#__PURE__*/React.createElement(EuiFlexItem, {
      grow: false
    }, /*#__PURE__*/React.createElement(TransactionDetailLink, {
      serviceName: rootTransaction.service.name,
      transactionId: rootTransaction.transaction.id,
      traceId: rootTransaction.trace.id,
      transactionName: rootTransaction.transaction.name,
      transactionType: rootTransaction.transaction.type
    }, /*#__PURE__*/React.createElement(EuiButton, {
      iconType: "apmTrace"
    }, viewFullTraceButtonLabel)));
  }
};