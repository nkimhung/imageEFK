function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React, { useState } from 'react';
import { uniqueId, startsWith } from 'lodash';
import styled from 'styled-components';
import { i18n } from '@kbn/i18n';
import { fromQuery, toQuery } from '../Links/url_helpers'; // @ts-ignore

import { Typeahead } from './Typeahead';
import { getBoolFilter } from './get_bool_filter';
import { useLocation } from '../../../hooks/useLocation';
import { useUrlParams } from '../../../hooks/useUrlParams';
import { history } from '../../../utils/history';
import { useApmPluginContext } from '../../../hooks/useApmPluginContext';
import { useDynamicIndexPattern } from '../../../hooks/useDynamicIndexPattern';
import { esKuery } from '../../../../../../../src/plugins/data/public';
var Container = styled.div.withConfig({
  displayName: "Container",
  componentId: "iytvti-0"
})(["margin-bottom:10px;"]);

function convertKueryToEsQuery(kuery, indexPattern) {
  var ast = esKuery.fromKueryExpression(kuery);
  return esKuery.toElasticsearchQuery(ast, indexPattern);
}

export function KueryBar() {
  var _useState = useState({
    suggestions: [],
    isLoadingSuggestions: false
  }),
      _useState2 = _slicedToArray(_useState, 2),
      state = _useState2[0],
      setState = _useState2[1];

  var _useUrlParams = useUrlParams(),
      urlParams = _useUrlParams.urlParams;

  var location = useLocation();
  var data = useApmPluginContext().plugins.data;
  var currentRequestCheck;
  var processorEvent = urlParams.processorEvent;
  var examples = {
    transaction: 'transaction.duration.us > 300000',
    error: 'http.response.status_code >= 400',
    metric: 'process.pid = "1234"',
    defaults: 'transaction.duration.us > 300000 AND http.response.status_code >= 400'
  };
  var example = examples[processorEvent || 'defaults'];

  var _useDynamicIndexPatte = useDynamicIndexPattern(processorEvent),
      indexPattern = _useDynamicIndexPatte.indexPattern;

  var placeholder = i18n.translate('xpack.apm.kueryBar.placeholder', {
    defaultMessage: "Search {event, select,\n            transaction {transactions}\n            metric {metrics}\n            error {errors}\n            other {transactions, errors and metrics}\n          } (E.g. {queryExample})",
    values: {
      queryExample: example,
      event: processorEvent
    }
  }); // The bar should be disabled when viewing the service map

  var disabled = /\/(service-map)$/.test(location.pathname);
  var disabledPlaceholder = i18n.translate('xpack.apm.kueryBar.disabledPlaceholder', {
    defaultMessage: 'Search is not available here'
  });

  function onChange(_x, _x2) {
    return _onChange.apply(this, arguments);
  }

  function _onChange() {
    _onChange = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(inputValue, selectionStart) {
      var currentRequest, suggestions;
      return regeneratorRuntime.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              if (!(indexPattern == null)) {
                _context.next = 2;
                break;
              }

              return _context.abrupt("return");

            case 2:
              setState(_objectSpread(_objectSpread({}, state), {}, {
                suggestions: [],
                isLoadingSuggestions: true
              }));
              currentRequest = uniqueId();
              currentRequestCheck = currentRequest;
              _context.prev = 5;
              _context.next = 8;
              return data.autocomplete.getQuerySuggestions({
                language: 'kuery',
                indexPatterns: [indexPattern],
                boolFilter: getBoolFilter(urlParams),
                query: inputValue,
                selectionStart: selectionStart,
                selectionEnd: selectionStart
              });

            case 8:
              _context.t0 = _context.sent;

              if (_context.t0) {
                _context.next = 11;
                break;
              }

              _context.t0 = [];

            case 11:
              suggestions = _context.t0.filter(function (suggestion) {
                return !startsWith(suggestion.text, 'span.');
              }).slice(0, 15);

              if (!(currentRequest !== currentRequestCheck)) {
                _context.next = 14;
                break;
              }

              return _context.abrupt("return");

            case 14:
              setState(_objectSpread(_objectSpread({}, state), {}, {
                suggestions: suggestions,
                isLoadingSuggestions: false
              }));
              _context.next = 20;
              break;

            case 17:
              _context.prev = 17;
              _context.t1 = _context["catch"](5);
              // eslint-disable-next-line no-console
              console.error('Error while fetching suggestions', _context.t1);

            case 20:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, null, [[5, 17]]);
    }));
    return _onChange.apply(this, arguments);
  }

  function onSubmit(inputValue) {
    if (indexPattern == null) {
      return;
    }

    try {
      var res = convertKueryToEsQuery(inputValue, indexPattern);

      if (!res) {
        return;
      }

      history.push(_objectSpread(_objectSpread({}, location), {}, {
        search: fromQuery(_objectSpread(_objectSpread({}, toQuery(location.search)), {}, {
          kuery: encodeURIComponent(inputValue.trim())
        }))
      }));
    } catch (e) {
      console.log('Invalid kuery syntax'); // eslint-disable-line no-console
    }
  }

  return /*#__PURE__*/React.createElement(Container, null, /*#__PURE__*/React.createElement(Typeahead, {
    disabled: disabled,
    isLoading: state.isLoadingSuggestions,
    initialValue: urlParams.kuery,
    onChange: onChange,
    onSubmit: onSubmit,
    suggestions: state.suggestions,
    placeholder: disabled ? disabledPlaceholder : placeholder
  }));
}