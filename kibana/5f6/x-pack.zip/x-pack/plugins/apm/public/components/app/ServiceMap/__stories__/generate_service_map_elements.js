function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { getSeverity } from '../Popover/getSeverity';
export function generateServiceMapElements(size) {
  var services = range(size).map(function (i) {
    var name = getName();
    var anomalyScore = randn(101);
    return {
      id: name,
      'service.environment': 'production',
      'service.name': name,
      'agent.name': getAgentName(),
      anomaly_score: anomalyScore,
      anomaly_severity: getSeverity(anomalyScore),
      actual_value: Math.random() * 2000000,
      typical_value: Math.random() * 1000000,
      ml_job_id: "".concat(name, "-request-high_mean_response_time")
    };
  });
  var connections = range(Math.round(size * 1.5)).map(function (i) {
    var sourceNode = services[randn(size)];
    var targetNode = services[randn(size)];
    return _objectSpread({
      id: "".concat(sourceNode.id, "~").concat(targetNode.id),
      source: sourceNode.id,
      target: targetNode.id
    }, probability(0.3) ? {
      bidirectional: true
    } : null);
  }).filter(function (_ref) {
    var source = _ref.source,
        target = _ref.target;
    return source !== target;
  });
  return [].concat(_toConsumableArray(services.map(function (serviceData) {
    return {
      data: serviceData
    };
  })), _toConsumableArray(connections.map(function (connectionData) {
    return {
      data: connectionData
    };
  })));
}

function range(n) {
  return Array(n).fill(0).map(function (e, i) {
    return i;
  });
}

function randn(n) {
  return Math.floor(Math.random() * n);
}

function probability(p) {
  return Math.random() < p;
}

function getAgentName() {
  return AGENT_NAMES[Math.floor(Math.random() * AGENT_NAMES.length)];
}

function getName() {
  return NAMES[Math.floor(Math.random() * NAMES.length)];
}

var AGENT_NAMES = ['dotnet', 'go', 'java', 'rum-js', 'nodejs', 'php', 'python', 'ruby'];
var NAMES = ['abomination', 'anaconda', 'apocalypse', 'arcade', 'angel', 'asp', 'beast', 'beetle', 'bishop', 'black-knight', 'black-mamba', 'black-widow', 'blade', 'blob', 'boomerang', 'bullseye', 'black-panther', 'cable', 'cannonball', 'carnage', 'callisto', 'colossus', 'crimson-dynamo', 'cyclops', 'cypher', 'daredevil', 'dazzler', 'deadpool', 'deathbringer', 'death', 'deathlok', 'deathstrike', 'destiny', 'detonator', 'diablo', 'doctor-doom', 'doctor-octopus', 'doctor-strange', 'domino', 'dragonhart,', 'electro', 'elektra', 'falcon', 'forge', 'fury', 'gambit', 'gladiator', 'green', 'grizzly', 'hammerhead', 'havok', 'hawk-owl', 'hawkeye', 'hobgoblin', 'hulk', 'human-torch', 'hurricane', 'iceman', 'iron-man', 'invisible-woman', 'juggernaut', 'kingpin', 'ka-zar', 'leech', 'loki', 'longshot', 'lumpkin,', 'madame-web', 'magician', 'magneto', 'man-thing', 'mastermind', 'mister-fantastic', 'mister-sinister', 'mister-nix', 'modok', 'mojo', 'mole-man', 'morbius', 'morlocks', 'moondragon', 'moon', 'madrox', 'mystique', 'namor', 'nightmare', 'nightcrawler', 'nighthawk', 'nihil', 'northstar', 'omega-red', 'orb-weaver', 'ox', 'polaris', 'power-man', 'princess-python', 'proteus', 'punisher', 'pyro', 'quicksilver', 'rhino', 'rogue', 'ronin', 'sabretooth', 'sandman', 'scorpion', 'sentinel', 'shadowcat', 'shocker', 'silvermane', 'silver-surfer', 'spider-man', 'spider-woman', 'spiral', 'storm', 'stryfe', 'sub-zero', 'sunder', 'super-skrull', 'swarm', 'tarantula', 'thanos', 'thor', 'tinkerer', 'toad', 'unus', 'valkyrie', 'vanisher', 'venom', 'vision', 'vulture', 'wasp', 'whiz-kid', 'wildpack', 'wolfsbane', 'wolverine', 'wraith', 'yellowjacket', 'zero'];