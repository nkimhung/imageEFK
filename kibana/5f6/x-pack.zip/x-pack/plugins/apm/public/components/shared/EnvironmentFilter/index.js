function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiSelect } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React from 'react';
import { useLocation } from '../../../hooks/useLocation';
import { useUrlParams } from '../../../hooks/useUrlParams';
import { history } from '../../../utils/history';
import { fromQuery, toQuery } from '../Links/url_helpers';
import { ENVIRONMENT_ALL, ENVIRONMENT_NOT_DEFINED } from '../../../../common/environment_filter_values';
import { useEnvironments, ALL_OPTION } from '../../../hooks/useEnvironments';

function updateEnvironmentUrl(location, environment) {
  var nextEnvironmentQueryParam = environment !== ENVIRONMENT_ALL ? environment : undefined;
  history.push(_objectSpread(_objectSpread({}, location), {}, {
    search: fromQuery(_objectSpread(_objectSpread({}, toQuery(location.search)), {}, {
      environment: nextEnvironmentQueryParam
    }))
  }));
}

var NOT_DEFINED_OPTION = {
  value: ENVIRONMENT_NOT_DEFINED,
  text: i18n.translate('xpack.apm.filter.environment.notDefinedLabel', {
    defaultMessage: 'Not defined'
  })
};
var SEPARATOR_OPTION = {
  text: "- ".concat(i18n.translate('xpack.apm.filter.environment.selectEnvironmentLabel', {
    defaultMessage: 'Select environment'
  }), " -"),
  disabled: true
};

function getOptions(environments) {
  var environmentOptions = environments.filter(function (env) {
    return env !== ENVIRONMENT_NOT_DEFINED;
  }).map(function (environment) {
    return {
      value: environment,
      text: environment
    };
  });
  return [ALL_OPTION].concat(_toConsumableArray(environments.includes(ENVIRONMENT_NOT_DEFINED) ? [NOT_DEFINED_OPTION] : []), _toConsumableArray(environmentOptions.length > 0 ? [SEPARATOR_OPTION] : []), _toConsumableArray(environmentOptions));
}

export var EnvironmentFilter = function EnvironmentFilter() {
  var location = useLocation();

  var _useUrlParams = useUrlParams(),
      uiFilters = _useUrlParams.uiFilters,
      urlParams = _useUrlParams.urlParams;

  var environment = uiFilters.environment;
  var serviceName = urlParams.serviceName,
      start = urlParams.start,
      end = urlParams.end;

  var _useEnvironments = useEnvironments({
    serviceName: serviceName,
    start: start,
    end: end
  }),
      environments = _useEnvironments.environments,
      _useEnvironments$stat = _useEnvironments.status,
      status = _useEnvironments$stat === void 0 ? 'loading' : _useEnvironments$stat;

  return /*#__PURE__*/React.createElement(EuiSelect, {
    prepend: i18n.translate('xpack.apm.filter.environment.label', {
      defaultMessage: 'environment'
    }),
    options: getOptions(environments),
    value: environment || ENVIRONMENT_ALL,
    onChange: function onChange(event) {
      updateEnvironmentUrl(location, event.target.value);
    },
    isLoading: status === 'loading'
  });
};