/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { storiesOf } from '@storybook/react'; // eslint-disable-next-line @kbn/eslint/no-restricted-paths

import { WaterfallContainer } from './index';
import { location, urlParams, simpleTrace, traceWithErrors, traceChildStartBeforeParent, inferredSpans } from './waterfallContainer.stories.data';
import { getWaterfall } from './Waterfall/waterfall_helpers/waterfall_helpers';
storiesOf('app/TransactionDetails/Waterfall', module).add('simple', function () {
  var waterfall = getWaterfall(simpleTrace, '975c8d5bfd1dd20b');
  return /*#__PURE__*/React.createElement(WaterfallContainer, {
    location: location,
    urlParams: urlParams,
    waterfall: waterfall,
    exceedsMax: false
  });
}, {
  info: {
    source: false
  }
});
storiesOf('app/TransactionDetails/Waterfall', module).add('with errors', function () {
  var waterfall = getWaterfall(traceWithErrors, '975c8d5bfd1dd20b');
  return /*#__PURE__*/React.createElement(WaterfallContainer, {
    location: location,
    urlParams: urlParams,
    waterfall: waterfall,
    exceedsMax: false
  });
}, {
  info: {
    source: false
  }
});
storiesOf('app/TransactionDetails/Waterfall', module).add('child starts before parent', function () {
  var waterfall = getWaterfall(traceChildStartBeforeParent, '975c8d5bfd1dd20b');
  return /*#__PURE__*/React.createElement(WaterfallContainer, {
    location: location,
    urlParams: urlParams,
    waterfall: waterfall,
    exceedsMax: false
  });
}, {
  info: {
    source: false
  }
});
storiesOf('app/TransactionDetails/Waterfall', module).add('inferred spans', function () {
  var waterfall = getWaterfall(inferredSpans, 'f2387d37260d00bd');
  return /*#__PURE__*/React.createElement(WaterfallContainer, {
    location: location,
    urlParams: urlParams,
    waterfall: waterfall,
    exceedsMax: false
  });
}, {
  info: {
    source: false
  }
});