/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { isBoolean, isNumber, isObject } from 'lodash';
import React from 'react';
import styled from 'styled-components';
import { NOT_AVAILABLE_LABEL } from '../../../../common/i18n';
var EmptyValue = styled.span.withConfig({
  displayName: "EmptyValue",
  componentId: "sc-136ppy3-0"
})(["color:", ";text-align:left;"], function (_ref) {
  var theme = _ref.theme;
  return theme.eui.euiColorMediumShade;
});
export function FormattedKey(_ref2) {
  var k = _ref2.k,
      value = _ref2.value;

  if (value == null) {
    return /*#__PURE__*/React.createElement(EmptyValue, null, k);
  }

  return /*#__PURE__*/React.createElement(React.Fragment, null, k);
}
export function FormattedValue(_ref3) {
  var value = _ref3.value;

  if (isObject(value)) {
    return /*#__PURE__*/React.createElement("pre", null, JSON.stringify(value, null, 4));
  } else if (isBoolean(value) || isNumber(value)) {
    return /*#__PURE__*/React.createElement(React.Fragment, null, String(value));
  } else if (!value) {
    return /*#__PURE__*/React.createElement(EmptyValue, null, NOT_AVAILABLE_LABEL);
  }

  return /*#__PURE__*/React.createElement(React.Fragment, null, value);
}