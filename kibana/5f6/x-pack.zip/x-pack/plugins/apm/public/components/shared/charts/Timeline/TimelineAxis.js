function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { inRange } from 'lodash';
import { Sticky } from 'react-sticky';
import { XAxis, XYPlot } from 'react-vis';
import { useTheme } from '../../../../hooks/useTheme';
import { px } from '../../../../style/variables';
import { getDurationFormatter } from '../../../../utils/formatters';
import { LastTickValue } from './LastTickValue';
import { Marker } from './Marker';

// Remove any tick that is too close to topTraceDuration
var getXAxisTickValues = function getXAxisTickValues(tickValues, topTraceDuration) {
  if (topTraceDuration == null) {
    return tickValues;
  }

  var padding = (tickValues[1] - tickValues[0]) / 2;
  var lowerBound = topTraceDuration - padding;
  var upperBound = topTraceDuration + padding;
  return tickValues.filter(function (value) {
    var isInRange = inRange(value, lowerBound, upperBound);
    return !isInRange && value !== topTraceDuration;
  });
};

export var TimelineAxis = function TimelineAxis(_ref) {
  var plotValues = _ref.plotValues,
      _ref$marks = _ref.marks,
      marks = _ref$marks === void 0 ? [] : _ref$marks,
      topTraceDuration = _ref.topTraceDuration;
  var theme = useTheme();
  var margins = plotValues.margins,
      tickValues = plotValues.tickValues,
      width = plotValues.width,
      xDomain = plotValues.xDomain,
      xMax = plotValues.xMax,
      xScale = plotValues.xScale;
  var tickFormatter = getDurationFormatter(xMax);
  var xAxisTickValues = getXAxisTickValues(tickValues, topTraceDuration);
  var topTraceDurationFormatted = tickFormatter(topTraceDuration).formatted;
  return /*#__PURE__*/React.createElement(Sticky, {
    disableCompensation: true
  }, function (_ref2) {
    var style = _ref2.style;
    return /*#__PURE__*/React.createElement("div", {
      style: _objectSpread({
        position: 'absolute',
        borderBottom: "1px solid ".concat(theme.eui.euiColorMediumShade),
        height: px(margins.top),
        zIndex: 2,
        width: '100%'
      }, style)
    }, /*#__PURE__*/React.createElement(XYPlot, {
      dontCheckIfEmpty: true,
      width: width,
      height: margins.top,
      margin: {
        top: margins.top,
        left: margins.left,
        right: margins.right
      },
      xDomain: xDomain
    }, /*#__PURE__*/React.createElement(XAxis, {
      hideLine: true,
      orientation: "top",
      tickSize: 0,
      tickValues: xAxisTickValues,
      tickFormat: function tickFormat(time) {
        return tickFormatter(time).formatted;
      },
      tickPadding: 20,
      style: {
        text: {
          fill: theme.eui.euiColorDarkShade
        }
      }
    }), topTraceDuration > 0 && /*#__PURE__*/React.createElement(LastTickValue, {
      x: xScale(topTraceDuration),
      value: topTraceDurationFormatted,
      marginTop: 28
    }), marks.map(function (mark) {
      return /*#__PURE__*/React.createElement(Marker, {
        key: mark.id,
        mark: mark,
        x: xScale(mark.offset)
      });
    })));
  });
};