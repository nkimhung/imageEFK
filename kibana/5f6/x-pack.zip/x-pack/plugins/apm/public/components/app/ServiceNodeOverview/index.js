/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React, { useMemo } from 'react';
import { EuiFlexGroup, EuiFlexItem, EuiPanel, EuiToolTip, EuiSpacer } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import styled from 'styled-components';
import { UNIDENTIFIED_SERVICE_NODES_LABEL } from '../../../../common/i18n';
import { SERVICE_NODE_NAME_MISSING } from '../../../../common/service_nodes';
import { PROJECTION } from '../../../../common/projections/typings';
import { LocalUIFilters } from '../../shared/LocalUIFilters';
import { useUrlParams } from '../../../hooks/useUrlParams';
import { ManagedTable } from '../../shared/ManagedTable';
import { useFetcher } from '../../../hooks/useFetcher';
import { asDynamicBytes, asInteger, asPercent } from '../../../utils/formatters';
import { ServiceNodeMetricOverviewLink } from '../../shared/Links/apm/ServiceNodeMetricOverviewLink';
import { truncate, px, unit } from '../../../style/variables';
var INITIAL_PAGE_SIZE = 25;
var INITIAL_SORT_FIELD = 'cpu';
var INITIAL_SORT_DIRECTION = 'desc';
var ServiceNodeName = styled.div.withConfig({
  displayName: "ServiceNodeName",
  componentId: "sc-1a4flo0-0"
})(["", ""], truncate(px(8 * unit)));

var ServiceNodeOverview = function ServiceNodeOverview() {
  var _useUrlParams = useUrlParams(),
      uiFilters = _useUrlParams.uiFilters,
      urlParams = _useUrlParams.urlParams;

  var serviceName = urlParams.serviceName,
      start = urlParams.start,
      end = urlParams.end;
  var localFiltersConfig = useMemo(function () {
    return {
      filterNames: ['host', 'containerId', 'podName'],
      params: {
        serviceName: serviceName
      },
      projection: PROJECTION.SERVICE_NODES
    };
  }, [serviceName]);

  var _useFetcher = useFetcher(function (callApmApi) {
    if (!serviceName || !start || !end) {
      return undefined;
    }

    return callApmApi({
      pathname: '/api/apm/services/{serviceName}/serviceNodes',
      params: {
        path: {
          serviceName: serviceName
        },
        query: {
          start: start,
          end: end,
          uiFilters: JSON.stringify(uiFilters)
        }
      }
    });
  }, [serviceName, start, end, uiFilters]),
      _useFetcher$data = _useFetcher.data,
      items = _useFetcher$data === void 0 ? [] : _useFetcher$data;

  if (!serviceName) {
    return null;
  }

  var columns = [{
    name: /*#__PURE__*/React.createElement(EuiToolTip, {
      content: i18n.translate('xpack.apm.jvmsTable.nameExplanation', {
        defaultMessage: "By default, the JVM name is the container ID (where applicable) or the hostname, but it can be manually configured through the agent's 'service_node_name' configuration."
      })
    }, /*#__PURE__*/React.createElement(React.Fragment, null, i18n.translate('xpack.apm.jvmsTable.nameColumnLabel', {
      defaultMessage: 'Name'
    }))),
    field: 'name',
    sortable: true,
    render: function render(name) {
      var _ref = name === SERVICE_NODE_NAME_MISSING ? {
        displayedName: UNIDENTIFIED_SERVICE_NODES_LABEL,
        tooltip: i18n.translate('xpack.apm.jvmsTable.explainServiceNodeNameMissing', {
          defaultMessage: 'We could not identify which JVMs these metrics belong to. This is likely caused by running a version of APM Server that is older than 7.5. Upgrading to APM Server 7.5 or higher should resolve this issue.'
        })
      } : {
        displayedName: name,
        tooltip: name
      },
          displayedName = _ref.displayedName,
          tooltip = _ref.tooltip;

      return /*#__PURE__*/React.createElement(EuiToolTip, {
        content: tooltip
      }, /*#__PURE__*/React.createElement(ServiceNodeMetricOverviewLink, {
        serviceName: serviceName,
        serviceNodeName: name
      }, /*#__PURE__*/React.createElement(ServiceNodeName, null, displayedName)));
    }
  }, {
    name: i18n.translate('xpack.apm.jvmsTable.cpuColumnLabel', {
      defaultMessage: 'CPU avg'
    }),
    field: 'cpu',
    sortable: true,
    render: function render(value) {
      return asPercent(value || 0, 1);
    }
  }, {
    name: i18n.translate('xpack.apm.jvmsTable.heapMemoryColumnLabel', {
      defaultMessage: 'Heap memory avg'
    }),
    field: 'heapMemory',
    sortable: true,
    render: asDynamicBytes
  }, {
    name: i18n.translate('xpack.apm.jvmsTable.nonHeapMemoryColumnLabel', {
      defaultMessage: 'Non-heap memory avg'
    }),
    field: 'nonHeapMemory',
    sortable: true,
    render: asDynamicBytes
  }, {
    name: i18n.translate('xpack.apm.jvmsTable.threadCountColumnLabel', {
      defaultMessage: 'Thread count max'
    }),
    field: 'threadCount',
    sortable: true,
    render: asInteger
  }];
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiSpacer, null), /*#__PURE__*/React.createElement(EuiFlexGroup, null, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: 1
  }, /*#__PURE__*/React.createElement(LocalUIFilters, localFiltersConfig)), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: 7
  }, /*#__PURE__*/React.createElement(EuiPanel, null, /*#__PURE__*/React.createElement(ManagedTable, {
    noItemsMessage: i18n.translate('xpack.apm.jvmsTable.noJvmsLabel', {
      defaultMessage: 'No JVMs were found'
    }),
    items: items,
    columns: columns,
    initialPageSize: INITIAL_PAGE_SIZE,
    initialSortField: INITIAL_SORT_FIELD,
    initialSortDirection: INITIAL_SORT_DIRECTION
  })))));
};

export { ServiceNodeOverview };