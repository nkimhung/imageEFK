function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { EuiFieldNumber } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import { isFinite } from 'lodash';
import { EuiSelect } from '@elastic/eui';
import { ForLastExpression } from '../../../../../triggers_actions_ui/public';
import { ALERT_TYPES_CONFIG } from '../../../../common/alert_types';
import { ServiceAlertTrigger } from '../ServiceAlertTrigger';
import { PopoverExpression } from '../ServiceAlertTrigger/PopoverExpression';
import { useEnvironments, ALL_OPTION } from '../../../hooks/useEnvironments';
import { useUrlParams } from '../../../hooks/useUrlParams';
export function ErrorRateAlertTrigger(props) {
  var setAlertParams = props.setAlertParams,
      setAlertProperty = props.setAlertProperty,
      alertParams = props.alertParams;

  var _useUrlParams = useUrlParams(),
      urlParams = _useUrlParams.urlParams;

  var serviceName = urlParams.serviceName,
      start = urlParams.start,
      end = urlParams.end;

  var _useEnvironments = useEnvironments({
    serviceName: serviceName,
    start: start,
    end: end
  }),
      environmentOptions = _useEnvironments.environmentOptions;

  var defaults = {
    threshold: 25,
    windowSize: 1,
    windowUnit: 'm',
    environment: ALL_OPTION.value
  };

  var params = _objectSpread(_objectSpread({}, defaults), alertParams);

  var threshold = isFinite(params.threshold) ? params.threshold : '';
  var fields = [/*#__PURE__*/React.createElement(PopoverExpression, {
    value: params.environment === ALL_OPTION.value ? ALL_OPTION.text : params.environment,
    title: i18n.translate('xpack.apm.errorRateAlertTrigger.environment', {
      defaultMessage: 'Environment'
    })
  }, /*#__PURE__*/React.createElement(EuiSelect, {
    value: params.environment,
    options: environmentOptions,
    onChange: function onChange(e) {
      return setAlertParams('environment', e.target.value);
    },
    compressed: true
  })), /*#__PURE__*/React.createElement(PopoverExpression, {
    title: i18n.translate('xpack.apm.errorRateAlertTrigger.isAbove', {
      defaultMessage: 'is above'
    }),
    value: threshold.toString()
  }, /*#__PURE__*/React.createElement(EuiFieldNumber, {
    value: threshold,
    step: 0,
    onChange: function onChange(e) {
      return setAlertParams('threshold', parseInt(e.target.value, 10));
    },
    compressed: true,
    append: i18n.translate('xpack.apm.errorRateAlertTrigger.errors', {
      defaultMessage: 'errors'
    })
  })), /*#__PURE__*/React.createElement(ForLastExpression, {
    onChangeWindowSize: function onChangeWindowSize(windowSize) {
      return setAlertParams('windowSize', windowSize || '');
    },
    onChangeWindowUnit: function onChangeWindowUnit(windowUnit) {
      return setAlertParams('windowUnit', windowUnit);
    },
    timeWindowSize: params.windowSize,
    timeWindowUnit: params.windowUnit,
    errors: {
      timeWindowSize: [],
      timeWindowUnit: []
    }
  })];
  return /*#__PURE__*/React.createElement(ServiceAlertTrigger, {
    alertTypeName: ALERT_TYPES_CONFIG['apm.error_rate'].name,
    defaults: defaults,
    fields: fields,
    setAlertParams: setAlertParams,
    setAlertProperty: setAlertProperty
  });
} // Default export is required for React.lazy loading
//
// eslint-disable-next-line import/no-default-export

export default ErrorRateAlertTrigger;