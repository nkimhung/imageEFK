/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { ServiceLegends } from './ServiceLegends';
import { Waterfall } from './Waterfall';
export function WaterfallContainer(_ref) {
  var location = _ref.location,
      urlParams = _ref.urlParams,
      waterfall = _ref.waterfall,
      exceedsMax = _ref.exceedsMax;

  if (!waterfall) {
    return null;
  }

  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(ServiceLegends, {
    serviceColors: waterfall.serviceColors
  }), /*#__PURE__*/React.createElement(Waterfall, {
    location: location,
    waterfallItemId: urlParams.waterfallItemId,
    waterfall: waterfall,
    exceedsMax: exceedsMax
  }));
}