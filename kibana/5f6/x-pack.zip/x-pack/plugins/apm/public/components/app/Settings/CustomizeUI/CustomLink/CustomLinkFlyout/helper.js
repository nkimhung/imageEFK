function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { i18n } from '@kbn/i18n';
import Mustache from 'mustache';
import { isEmpty, get } from 'lodash';
import { FILTER_OPTIONS } from '../../../../../../../common/custom_link/custom_link_filter_options';
export var DEFAULT_OPTION = {
  value: 'DEFAULT',
  text: i18n.translate('xpack.apm.settings.customizeUI.customLink.flyOut.filters.defaultOption', {
    defaultMessage: 'Select field...'
  })
};
export var FILTER_SELECT_OPTIONS = [DEFAULT_OPTION].concat(_toConsumableArray(FILTER_OPTIONS.map(function (filter) {
  return {
    value: filter,
    text: filter
  };
})));
/**
 * Returns the options available, removing filters already added, but keeping the selected filter.
 *
 * @param filters
 * @param selectedKey
 */

export var getSelectOptions = function getSelectOptions(filters, selectedKey) {
  return FILTER_SELECT_OPTIONS.filter(function (_ref) {
    var value = _ref.value;
    return !filters.some(function (_ref2) {
      var key = _ref2.key;
      return key === value && key !== selectedKey;
    });
  });
};

var getInvalidTemplateVariables = function getInvalidTemplateVariables(template, transaction) {
  return Mustache.parse(template).filter(function (_ref3) {
    var _ref4 = _slicedToArray(_ref3, 1),
        type = _ref4[0];

    return type === 'name';
  }).map(function (_ref5) {
    var _ref6 = _slicedToArray(_ref5, 2),
        value = _ref6[1];

    return value;
  }).filter(function (templateVar) {
    return get(transaction, templateVar) == null;
  });
};

var validateUrl = function validateUrl(url, transaction) {
  if (!transaction || isEmpty(transaction)) {
    return i18n.translate('xpack.apm.settings.customizeUI.customLink.preview.transaction.notFound', {
      defaultMessage: "We couldn't find a matching transaction document based on the defined filters."
    });
  }

  try {
    var invalidVariables = getInvalidTemplateVariables(url, transaction);

    if (!isEmpty(invalidVariables)) {
      return i18n.translate('xpack.apm.settings.customizeUI.customLink.preview.contextVariable.noMatch', {
        defaultMessage: "We couldn't find a value match for {variables} in the example transaction document.",
        values: {
          variables: invalidVariables.map(function (variable) {
            return "{{".concat(variable, "}}");
          }).join(', ')
        }
      });
    }
  } catch (e) {
    return i18n.translate('xpack.apm.settings.customizeUI.customLink.preview.contextVariable.invalid', {
      defaultMessage: "We couldn't find an example transaction document due to invalid variable(s) defined."
    });
  }
};

export var replaceTemplateVariables = function replaceTemplateVariables(url, transaction) {
  var error = validateUrl(url, transaction);

  try {
    return {
      formattedUrl: Mustache.render(url, transaction),
      error: error
    };
  } catch (e) {
    // errors will be caught on validateUrl function
    return {
      formattedUrl: url,
      error: error
    };
  }
};
export var convertFiltersToQuery = function convertFiltersToQuery(filters) {
  return filters.reduce(function (acc, _ref7) {
    var key = _ref7.key,
        value = _ref7.value;

    if (key && value) {
      acc[key] = value;
    }

    return acc;
  }, {});
};