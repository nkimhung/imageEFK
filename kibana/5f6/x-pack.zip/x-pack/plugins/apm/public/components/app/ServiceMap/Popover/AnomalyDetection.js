/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { i18n } from '@kbn/i18n';
import React from 'react';
import styled from 'styled-components';
import { EuiFlexGroup, EuiFlexItem, EuiTitle, EuiIconTip, EuiHealth } from '@elastic/eui';
import { useTheme } from '../../../../hooks/useTheme';
import { fontSize, px } from '../../../../style/variables';
import { asInteger, asDuration } from '../../../../utils/formatters';
import { MLJobLink } from '../../../shared/Links/MachineLearningLinks/MLJobLink';
import { getSeverityColor, popoverWidth } from '../cytoscapeOptions';
import { TRANSACTION_REQUEST } from '../../../../../common/transaction_types';
import { getSeverity } from './getSeverity';
var HealthStatusTitle = styled(EuiTitle).withConfig({
  displayName: "HealthStatusTitle",
  componentId: "sc-1xk4uqd-0"
})(["display:inline;text-transform:uppercase;"]);
var VerticallyCentered = styled.div.withConfig({
  displayName: "VerticallyCentered",
  componentId: "sc-1xk4uqd-1"
})(["display:flex;align-items:center;"]);
var SubduedText = styled.span.withConfig({
  displayName: "SubduedText",
  componentId: "sc-1xk4uqd-2"
})(["color:", ";"], function (_ref) {
  var theme = _ref.theme;
  return theme.eui.euiTextSubduedColor;
});
var EnableText = styled.section.withConfig({
  displayName: "EnableText",
  componentId: "sc-1xk4uqd-3"
})(["color:", ";line-height:1.4;font-size:", ";width:", ";"], function (_ref2) {
  var theme = _ref2.theme;
  return theme.eui.euiTextSubduedColor;
}, fontSize, px(popoverWidth));
export var ContentLine = styled.section.withConfig({
  displayName: "ContentLine",
  componentId: "sc-1xk4uqd-4"
})(["line-height:2;"]);
export function AnomalyDetection(_ref3) {
  var _serviceAnomalyStats$;

  var serviceName = _ref3.serviceName,
      serviceAnomalyStats = _ref3.serviceAnomalyStats;
  var theme = useTheme();
  var anomalyScore = serviceAnomalyStats === null || serviceAnomalyStats === void 0 ? void 0 : serviceAnomalyStats.anomalyScore;
  var anomalySeverity = getSeverity(anomalyScore);
  var actualValue = serviceAnomalyStats === null || serviceAnomalyStats === void 0 ? void 0 : serviceAnomalyStats.actualValue;
  var mlJobId = serviceAnomalyStats === null || serviceAnomalyStats === void 0 ? void 0 : serviceAnomalyStats.jobId;
  var transactionType = (_serviceAnomalyStats$ = serviceAnomalyStats === null || serviceAnomalyStats === void 0 ? void 0 : serviceAnomalyStats.transactionType) !== null && _serviceAnomalyStats$ !== void 0 ? _serviceAnomalyStats$ : TRANSACTION_REQUEST;
  var hasAnomalyDetectionScore = anomalyScore !== undefined;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement(HealthStatusTitle, {
    size: "xxs"
  }, /*#__PURE__*/React.createElement("h3", null, ANOMALY_DETECTION_TITLE)), "\xA0", /*#__PURE__*/React.createElement(EuiIconTip, {
    type: "iInCircle",
    content: ANOMALY_DETECTION_TOOLTIP
  }), !mlJobId && /*#__PURE__*/React.createElement(EnableText, null, ANOMALY_DETECTION_DISABLED_TEXT)), hasAnomalyDetectionScore && /*#__PURE__*/React.createElement(ContentLine, null, /*#__PURE__*/React.createElement(EuiFlexGroup, null, /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(VerticallyCentered, null, /*#__PURE__*/React.createElement(EuiHealth, {
    color: getSeverityColor(theme, anomalySeverity)
  }), /*#__PURE__*/React.createElement(SubduedText, null, ANOMALY_DETECTION_SCORE_METRIC))), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement("div", null, getDisplayedAnomalyScore(anomalyScore), actualValue && /*#__PURE__*/React.createElement(SubduedText, null, "\xA0(", asDuration(actualValue), ")"))))), mlJobId && !hasAnomalyDetectionScore && /*#__PURE__*/React.createElement(EnableText, null, ANOMALY_DETECTION_NO_DATA_TEXT), mlJobId && /*#__PURE__*/React.createElement(ContentLine, null, /*#__PURE__*/React.createElement(MLJobLink, {
    external: true,
    jobId: mlJobId,
    serviceName: serviceName,
    transactionType: transactionType
  }, ANOMALY_DETECTION_LINK)));
}

function getDisplayedAnomalyScore(score) {
  if (score > 0 && score < 1) {
    return '< 1';
  }

  return asInteger(score);
}

var ANOMALY_DETECTION_TITLE = i18n.translate('xpack.apm.serviceMap.anomalyDetectionPopoverTitle', {
  defaultMessage: 'Anomaly Detection'
});
var ANOMALY_DETECTION_TOOLTIP = i18n.translate('xpack.apm.serviceMap.anomalyDetectionPopoverTooltip', {
  defaultMessage: 'Service health indicators are powered by the anomaly detection feature in machine learning'
});
var ANOMALY_DETECTION_SCORE_METRIC = i18n.translate('xpack.apm.serviceMap.anomalyDetectionPopoverScoreMetric', {
  defaultMessage: 'Score (max.)'
});
var ANOMALY_DETECTION_LINK = i18n.translate('xpack.apm.serviceMap.anomalyDetectionPopoverLink', {
  defaultMessage: 'View anomalies'
});
var ANOMALY_DETECTION_DISABLED_TEXT = i18n.translate('xpack.apm.serviceMap.anomalyDetectionPopoverDisabled', {
  defaultMessage: 'Display service health indicators by enabling anomaly detection in APM settings.'
});
var ANOMALY_DETECTION_NO_DATA_TEXT = i18n.translate('xpack.apm.serviceMap.anomalyDetectionPopoverNoData', {
  defaultMessage: "We couldn't find an anomaly score within the selected time range. See details in the anomaly explorer."
});