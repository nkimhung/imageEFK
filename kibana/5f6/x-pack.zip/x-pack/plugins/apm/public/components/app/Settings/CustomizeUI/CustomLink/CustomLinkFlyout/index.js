function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiFlyout, EuiFlyoutBody, EuiFlyoutHeader, EuiPortal, EuiSpacer, EuiText, EuiTitle } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React, { useState } from 'react';
import { useApmPluginContext } from '../../../../../../hooks/useApmPluginContext';
import { FiltersSection } from './FiltersSection';
import { FlyoutFooter } from './FlyoutFooter';
import { LinkSection } from './LinkSection';
import { saveCustomLink } from './saveCustomLink';
import { LinkPreview } from './LinkPreview';
import { Documentation } from './Documentation';
var filtersEmptyState = [{
  key: '',
  value: ''
}];
export var CustomLinkFlyout = function CustomLinkFlyout(_ref) {
  var _defaults$filters;

  var onClose = _ref.onClose,
      onSave = _ref.onSave,
      onDelete = _ref.onDelete,
      defaults = _ref.defaults,
      customLinkId = _ref.customLinkId;
  var toasts = useApmPluginContext().core.notifications.toasts;

  var _useState = useState(false),
      _useState2 = _slicedToArray(_useState, 2),
      isSaving = _useState2[0],
      setIsSaving = _useState2[1];

  var _useState3 = useState((defaults === null || defaults === void 0 ? void 0 : defaults.label) || ''),
      _useState4 = _slicedToArray(_useState3, 2),
      label = _useState4[0],
      setLabel = _useState4[1];

  var _useState5 = useState((defaults === null || defaults === void 0 ? void 0 : defaults.url) || ''),
      _useState6 = _slicedToArray(_useState5, 2),
      url = _useState6[0],
      setUrl = _useState6[1];

  var _useState7 = useState((defaults === null || defaults === void 0 ? void 0 : (_defaults$filters = defaults.filters) === null || _defaults$filters === void 0 ? void 0 : _defaults$filters.length) ? defaults.filters : filtersEmptyState),
      _useState8 = _slicedToArray(_useState7, 2),
      filters = _useState8[0],
      setFilters = _useState8[1];

  var isFormValid = !!label && !!url;

  var onSubmit = /*#__PURE__*/function () {
    var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(event) {
      return regeneratorRuntime.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              event.preventDefault();
              setIsSaving(true);
              _context.next = 4;
              return saveCustomLink({
                id: customLinkId,
                label: label,
                url: url,
                filters: filters,
                toasts: toasts
              });

            case 4:
              setIsSaving(false);
              onSave();

            case 6:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function onSubmit(_x) {
      return _ref2.apply(this, arguments);
    };
  }();

  return /*#__PURE__*/React.createElement(EuiPortal, null, /*#__PURE__*/React.createElement("form", {
    onSubmit: onSubmit
  }, /*#__PURE__*/React.createElement(EuiFlyout, {
    ownFocus: true,
    onClose: onClose,
    size: "m"
  }, /*#__PURE__*/React.createElement(EuiFlyoutHeader, {
    hasBorder: true
  }, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "s"
  }, /*#__PURE__*/React.createElement("h2", null, i18n.translate('xpack.apm.settings.customizeUI.customLink.flyout.title', {
    defaultMessage: 'Create link'
  })))), /*#__PURE__*/React.createElement(EuiFlyoutBody, null, /*#__PURE__*/React.createElement(EuiText, null, /*#__PURE__*/React.createElement("p", null, i18n.translate('xpack.apm.settings.customizeUI.customLink.flyout.label', {
    defaultMessage: 'Links will be available in the context of transaction details throughout the APM app. You can create an unlimited number of links. You can refer to dynamic variables by using any of the transaction metadata to fill in your URLs. More information, including examples, are available in the'
  }), ' ', /*#__PURE__*/React.createElement(Documentation, {
    label: i18n.translate('xpack.apm.settings.customizeUI.customLink.flyout.label.doc', {
      defaultMessage: 'documentation.'
    })
  }))), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "l"
  }), /*#__PURE__*/React.createElement(LinkSection, {
    label: label,
    onChangeLabel: setLabel,
    url: url,
    onChangeUrl: setUrl
  }), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "l"
  }), /*#__PURE__*/React.createElement(FiltersSection, {
    filters: filters,
    onChangeFilters: setFilters
  }), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "l"
  }), /*#__PURE__*/React.createElement(LinkPreview, {
    label: label,
    url: url,
    filters: filters
  })), /*#__PURE__*/React.createElement(FlyoutFooter, {
    isSaveButtonEnabled: isFormValid,
    onClose: onClose,
    isSaving: isSaving,
    onDelete: onDelete,
    customLinkId: customLinkId
  }))));
};