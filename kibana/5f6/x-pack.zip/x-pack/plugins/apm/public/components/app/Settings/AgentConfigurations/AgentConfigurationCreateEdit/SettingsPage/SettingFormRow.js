/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { EuiFormRow, EuiFieldText, EuiFieldNumber, EuiDescribedFormGroup, EuiFlexGroup, EuiFlexItem, EuiCode, EuiSpacer, EuiIconTip } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import { validateSetting } from '../../../../../../../common/agent_configuration/setting_definitions';
import { amountAndUnitToString, amountAndUnitToObject } from '../../../../../../../common/agent_configuration/amount_and_unit';
import { SelectWithPlaceholder } from '../../../../../shared/SelectWithPlaceholder';

function FormRow(_ref) {
  var setting = _ref.setting,
      value = _ref.value,
      _onChange = _ref.onChange;

  switch (setting.type) {
    case 'float':
    case 'text':
      {
        return /*#__PURE__*/React.createElement(EuiFieldText, {
          placeholder: setting.placeholder,
          value: value || '',
          onChange: function onChange(e) {
            return _onChange(setting.key, e.target.value);
          }
        });
      }

    case 'integer':
      {
        return /*#__PURE__*/React.createElement(EuiFieldNumber, {
          placeholder: setting.placeholder,
          value: value || '',
          min: setting.min,
          max: setting.max,
          onChange: function onChange(e) {
            return _onChange(setting.key, e.target.value);
          }
        });
      }

    case 'select':
      {
        return /*#__PURE__*/React.createElement(SelectWithPlaceholder, {
          placeholder: setting.placeholder,
          options: setting.options,
          value: value,
          onChange: function onChange(e) {
            return _onChange(setting.key, e.target.value);
          }
        });
      }

    case 'boolean':
      {
        return /*#__PURE__*/React.createElement(SelectWithPlaceholder, {
          placeholder: setting.placeholder,
          options: [{
            text: 'true',
            value: 'true'
          }, {
            text: 'false',
            value: 'false'
          }],
          value: value,
          onChange: function onChange(e) {
            return _onChange(setting.key, e.target.value);
          }
        });
      }

    case 'bytes':
    case 'duration':
      {
        var _setting$units;

        var _amountAndUnitToObjec = amountAndUnitToObject(value !== null && value !== void 0 ? value : ''),
            amount = _amountAndUnitToObjec.amount,
            unit = _amountAndUnitToObjec.unit;

        return /*#__PURE__*/React.createElement(EuiFlexGroup, {
          gutterSize: "s"
        }, /*#__PURE__*/React.createElement(EuiFlexItem, {
          grow: false
        }, /*#__PURE__*/React.createElement(EuiFieldNumber, {
          placeholder: setting.placeholder,
          value: amount,
          onChange: function onChange(e) {
            return _onChange(setting.key, amountAndUnitToString({
              amount: e.target.value,
              unit: unit
            }));
          }
        })), /*#__PURE__*/React.createElement(EuiFlexItem, {
          grow: false
        }, /*#__PURE__*/React.createElement(SelectWithPlaceholder, {
          placeholder: i18n.translate('xpack.apm.unitLabel', {
            defaultMessage: 'Select unit'
          }),
          value: unit,
          options: (_setting$units = setting.units) === null || _setting$units === void 0 ? void 0 : _setting$units.map(function (text) {
            return {
              text: text,
              value: text
            };
          }),
          onChange: function onChange(e) {
            return _onChange(setting.key, amountAndUnitToString({
              amount: amount,
              unit: e.target.value
            }));
          }
        })));
      }

    default:
      throw new Error("Unknown type \"".concat(setting.type, "\""));
  }
}

export function SettingFormRow(_ref2) {
  var isUnsaved = _ref2.isUnsaved,
      setting = _ref2.setting,
      value = _ref2.value,
      onChange = _ref2.onChange;

  var _validateSetting = validateSetting(setting, value),
      isValid = _validateSetting.isValid,
      message = _validateSetting.message;

  var isInvalid = value != null && value !== '' && !isValid;
  return /*#__PURE__*/React.createElement(EuiDescribedFormGroup, {
    fullWidth: true,
    title: /*#__PURE__*/React.createElement("h3", null, setting.label, ' ', isUnsaved && /*#__PURE__*/React.createElement(EuiIconTip, {
      type: 'dot',
      color: 'warning',
      content: i18n.translate('xpack.apm.agentConfig.unsavedSetting.tooltip', {
        defaultMessage: 'Unsaved'
      })
    })),
    description: /*#__PURE__*/React.createElement(React.Fragment, null, setting.description, setting.defaultValue && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiSpacer, null), /*#__PURE__*/React.createElement(EuiCode, null, "Default: ", setting.defaultValue)))
  }, /*#__PURE__*/React.createElement(EuiFormRow, {
    label: setting.key,
    error: message,
    isInvalid: isInvalid
  }, /*#__PURE__*/React.createElement(FormRow, {
    onChange: onChange,
    setting: setting,
    value: value
  })));
}