/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiToolTip } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React from 'react';
import styled from 'styled-components'; // eslint-disable-next-line @kbn/eslint/no-restricted-paths

import { NOT_AVAILABLE_LABEL } from '../../../../../common/i18n';
import { fontSizes, truncate } from '../../../../style/variables';
import { asDecimal, asMillisecondDuration } from '../../../../utils/formatters';
import { ManagedTable } from '../../../shared/ManagedTable';
import { EnvironmentBadge } from '../../../shared/EnvironmentBadge';
import { TransactionOverviewLink } from '../../../shared/Links/apm/TransactionOverviewLink';

function formatNumber(value) {
  if (value === 0) {
    return '0';
  } else if (value <= 0.1) {
    return '< 0.1';
  } else {
    return asDecimal(value);
  }
}

function formatString(value) {
  return value || NOT_AVAILABLE_LABEL;
}

var AppLink = styled(TransactionOverviewLink).withConfig({
  displayName: "AppLink",
  componentId: "sc-1ds02iy-0"
})(["font-size:", ";", ";"], fontSizes.large, truncate('100%'));
export var SERVICE_COLUMNS = [{
  field: 'serviceName',
  name: i18n.translate('xpack.apm.servicesTable.nameColumnLabel', {
    defaultMessage: 'Name'
  }),
  width: '40%',
  sortable: true,
  render: function render(serviceName) {
    return /*#__PURE__*/React.createElement(EuiToolTip, {
      content: formatString(serviceName),
      id: "service-name-tooltip"
    }, /*#__PURE__*/React.createElement(AppLink, {
      serviceName: serviceName
    }, formatString(serviceName)));
  }
}, {
  field: 'environments',
  name: i18n.translate('xpack.apm.servicesTable.environmentColumnLabel', {
    defaultMessage: 'Environment'
  }),
  width: '20%',
  sortable: true,
  render: function render(environments) {
    return /*#__PURE__*/React.createElement(EnvironmentBadge, {
      environments: environments
    });
  }
}, {
  field: 'agentName',
  name: i18n.translate('xpack.apm.servicesTable.agentColumnLabel', {
    defaultMessage: 'Agent'
  }),
  sortable: true,
  render: function render(agentName) {
    return formatString(agentName);
  }
}, {
  field: 'avgResponseTime',
  name: i18n.translate('xpack.apm.servicesTable.avgResponseTimeColumnLabel', {
    defaultMessage: 'Avg. response time'
  }),
  sortable: true,
  dataType: 'number',
  render: function render(time) {
    return asMillisecondDuration(time);
  }
}, {
  field: 'transactionsPerMinute',
  name: i18n.translate('xpack.apm.servicesTable.transactionsPerMinuteColumnLabel', {
    defaultMessage: 'Trans. per minute'
  }),
  sortable: true,
  dataType: 'number',
  render: function render(value) {
    return "".concat(formatNumber(value), " ").concat(i18n.translate('xpack.apm.servicesTable.transactionsPerMinuteUnitLabel', {
      defaultMessage: 'tpm'
    }));
  }
}, {
  field: 'errorsPerMinute',
  name: i18n.translate('xpack.apm.servicesTable.errorsPerMinuteColumnLabel', {
    defaultMessage: 'Errors per minute'
  }),
  sortable: true,
  dataType: 'number',
  render: function render(value) {
    return "".concat(formatNumber(value), " ").concat(i18n.translate('xpack.apm.servicesTable.errorsPerMinuteUnitLabel', {
      defaultMessage: 'err.'
    }));
  }
}];
export function ServiceList(_ref) {
  var items = _ref.items,
      noItemsMessage = _ref.noItemsMessage;
  return /*#__PURE__*/React.createElement(ManagedTable, {
    columns: SERVICE_COLUMNS,
    items: items,
    noItemsMessage: noItemsMessage,
    initialSortField: "serviceName",
    initialPageSize: 50
  });
}