function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiIconTip, EuiTitle } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import d3 from 'd3';
import React, { useCallback } from 'react';
import { isEmpty } from 'lodash'; // eslint-disable-next-line @kbn/eslint/no-restricted-paths

import { getDurationFormatter } from '../../../../utils/formatters'; // @ts-ignore

import Histogram from '../../../shared/charts/Histogram';
import { EmptyMessage } from '../../../shared/EmptyMessage';
import { fromQuery, toQuery } from '../../../shared/Links/url_helpers';
import { history } from '../../../../utils/history';
import { LoadingStatePrompt } from '../../../shared/LoadingStatePrompt';
export function getFormattedBuckets(buckets, bucketSize) {
  if (!buckets) {
    return [];
  }

  return buckets.map(function (_ref) {
    var samples = _ref.samples,
        count = _ref.count,
        key = _ref.key;
    return {
      samples: samples,
      x0: key,
      x: key + bucketSize,
      y: count,
      style: {
        cursor: isEmpty(samples) ? 'default' : 'pointer'
      }
    };
  });
}

var getFormatYShort = function getFormatYShort(transactionType) {
  return function (t) {
    return i18n.translate('xpack.apm.transactionDetails.transactionsDurationDistributionChart.unitShortLabel', {
      defaultMessage: '{transCount} {transType, select, request {req.} other {trans.}}',
      values: {
        transCount: t,
        transType: transactionType
      }
    });
  };
};

var getFormatYLong = function getFormatYLong(transactionType) {
  return function (t) {
    return transactionType === 'request' ? i18n.translate('xpack.apm.transactionDetails.transactionsDurationDistributionChart.requestTypeUnitLongLabel', {
      defaultMessage: '{transCount, plural, =0 {# request} one {# request} other {# requests}}',
      values: {
        transCount: t
      }
    }) : i18n.translate('xpack.apm.transactionDetails.transactionsDurationDistributionChart.transactionTypeUnitLongLabel', {
      defaultMessage: '{transCount, plural, =0 {# transaction} one {# transaction} other {# transactions}}',
      values: {
        transCount: t
      }
    });
  };
};

export var TransactionDistribution = function TransactionDistribution(props) {
  var distribution = props.distribution,
      transactionType = props.urlParams.transactionType,
      isLoading = props.isLoading,
      bucketIndex = props.bucketIndex;
  /* eslint-disable-next-line react-hooks/exhaustive-deps */

  var formatYShort = useCallback(getFormatYShort(transactionType), [transactionType]);
  /* eslint-disable-next-line react-hooks/exhaustive-deps */

  var formatYLong = useCallback(getFormatYLong(transactionType), [transactionType]); // no data in response

  if (!distribution || distribution.noHits) {
    // only show loading state if there is no data - else show stale data until new data has loaded
    if (isLoading) {
      return /*#__PURE__*/React.createElement(LoadingStatePrompt, null);
    }

    return /*#__PURE__*/React.createElement(EmptyMessage, {
      heading: i18n.translate('xpack.apm.transactionDetails.notFoundLabel', {
        defaultMessage: 'No transactions were found.'
      })
    });
  }

  var buckets = getFormattedBuckets(distribution.buckets, distribution.bucketSize);
  var xMax = d3.max(buckets, function (d) {
    return d.x;
  }) || 0;
  var timeFormatter = getDurationFormatter(xMax);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xs"
  }, /*#__PURE__*/React.createElement("h5", null, i18n.translate('xpack.apm.transactionDetails.transactionsDurationDistributionChartTitle', {
    defaultMessage: 'Transactions duration distribution'
  }), ' ', /*#__PURE__*/React.createElement(EuiIconTip, {
    title: i18n.translate('xpack.apm.transactionDetails.transactionsDurationDistributionChartTooltip.samplingLabel', {
      defaultMessage: 'Sampling'
    }),
    content: i18n.translate('xpack.apm.transactionDetails.transactionsDurationDistributionChartTooltip.samplingDescription', {
      defaultMessage: "Each bucket will show a sample transaction. If there's no sample available, it's most likely because of the sampling limit set in the agent configuration."
    }),
    position: "top"
  }))), /*#__PURE__*/React.createElement(Histogram, {
    buckets: buckets,
    bucketSize: distribution.bucketSize,
    bucketIndex: bucketIndex,
    onClick: function onClick(bucket) {
      if (!isEmpty(bucket.samples)) {
        var sample = bucket.samples[0];
        history.push(_objectSpread(_objectSpread({}, history.location), {}, {
          search: fromQuery(_objectSpread(_objectSpread({}, toQuery(history.location.search)), {}, {
            transactionId: sample.transactionId,
            traceId: sample.traceId
          }))
        }));
      }
    },
    formatX: function formatX(time) {
      return timeFormatter(time).formatted;
    },
    formatYShort: formatYShort,
    formatYLong: formatYLong,
    verticalLineHover: function verticalLineHover(bucket) {
      return isEmpty(bucket.samples);
    },
    backgroundHover: function backgroundHover(bucket) {
      return !isEmpty(bucket.samples);
    },
    tooltipHeader: function tooltipHeader(bucket) {
      var xFormatted = timeFormatter(bucket.x);
      var x0Formatted = timeFormatter(bucket.x0);
      return "".concat(x0Formatted.value, " - ").concat(xFormatted.value, " ").concat(xFormatted.unit);
    },
    tooltipFooter: function tooltipFooter(bucket) {
      return isEmpty(bucket.samples) && i18n.translate('xpack.apm.transactionDetails.transactionsDurationDistributionChart.noSampleTooltip', {
        defaultMessage: 'No sample available for this bucket'
      });
    }
  }));
};