function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiButtonEmpty, EuiFieldText, EuiFlexGroup, EuiFlexItem, EuiSelect, EuiSpacer, EuiText, EuiTitle } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import { isEmpty } from 'lodash';
import React from 'react';
import { DEFAULT_OPTION, FILTER_SELECT_OPTIONS, getSelectOptions } from './helper';
export var FiltersSection = function FiltersSection(_ref) {
  var filters = _ref.filters,
      onChangeFilters = _ref.onChangeFilters;

  var onChangeFilter = function onChangeFilter(key, value, idx) {
    var newFilters = _toConsumableArray(filters);

    newFilters[idx] = {
      key: key,
      value: value
    };
    onChangeFilters(newFilters);
  };

  var onRemoveFilter = function onRemoveFilter(idx) {
    // remove without mutating original array
    var newFilters = _toConsumableArray(filters);

    newFilters.splice(idx, 1); // if there is only one item left it should not be removed
    // but reset to empty

    if (isEmpty(newFilters)) {
      onChangeFilters([{
        key: '',
        value: ''
      }]);
    } else {
      onChangeFilters(newFilters);
    }
  };

  var handleAddFilter = function handleAddFilter() {
    onChangeFilters([].concat(_toConsumableArray(filters), [{
      key: '',
      value: ''
    }]));
  };

  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xs"
  }, /*#__PURE__*/React.createElement("h3", null, i18n.translate('xpack.apm.settings.customizeUI.customLink.flyout.filters.title', {
    defaultMessage: 'Filters'
  }))), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "s"
  }), /*#__PURE__*/React.createElement(EuiText, {
    size: "s"
  }, i18n.translate('xpack.apm.settings.customizeUI.customLink.flyout.filters.subtitle', {
    defaultMessage: 'Use the filter options to scope them to only appear for specific services.'
  })), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "s"
  }), filters.map(function (filter, idx) {
    var key = filter.key,
        value = filter.value;
    var filterId = "filter-".concat(idx);
    var selectOptions = getSelectOptions(filters, key);
    return /*#__PURE__*/React.createElement(EuiFlexGroup, {
      key: filterId,
      gutterSize: "s",
      alignItems: "center"
    }, /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(EuiSelect, {
      "data-test-subj": filterId,
      id: filterId,
      fullWidth: true,
      options: selectOptions,
      value: key,
      prepend: i18n.translate('xpack.apm.settings.customizeUI.customLink.flyout.filters.prepend', {
        defaultMessage: 'Field'
      }),
      onChange: function onChange(e) {
        return onChangeFilter(e.target.value, value, idx);
      },
      isInvalid: !isEmpty(value) && (isEmpty(key) || key === DEFAULT_OPTION.value)
    })), /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(EuiFieldText, {
      "data-test-subj": "".concat(key, ".value"),
      fullWidth: true,
      placeholder: i18n.translate('xpack.apm.settings.customizeUI.customLink.flyOut.filters.defaultOption.value', {
        defaultMessage: 'Value'
      }),
      onChange: function onChange(e) {
        return onChangeFilter(key, e.target.value, idx);
      },
      value: value,
      isInvalid: !isEmpty(key) && isEmpty(value)
    })), /*#__PURE__*/React.createElement(EuiFlexItem, {
      grow: false
    }, /*#__PURE__*/React.createElement(EuiButtonEmpty, {
      iconType: "trash",
      onClick: function onClick() {
        return onRemoveFilter(idx);
      },
      disabled: !value && !key && filters.length === 1
    })));
  }), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "xs"
  }), /*#__PURE__*/React.createElement(AddFilterButton, {
    onClick: handleAddFilter // Disable button when user has already added all items available
    ,
    isDisabled: filters.length === FILTER_SELECT_OPTIONS.length - 1
  }));
};

var AddFilterButton = function AddFilterButton(_ref2) {
  var onClick = _ref2.onClick,
      isDisabled = _ref2.isDisabled;
  return /*#__PURE__*/React.createElement(EuiButtonEmpty, {
    iconType: "plusInCircle",
    onClick: onClick,
    disabled: isDisabled
  }, i18n.translate('xpack.apm.settings.customizeUI.customLink.flyout.filters.addAnotherFilter', {
    defaultMessage: 'Add another filter'
  }));
};