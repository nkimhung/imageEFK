/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiBadge, EuiFlexGroup, EuiFlexItem, EuiPanel, EuiSpacer, EuiText, EuiTitle } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React, { Fragment } from 'react';
import styled from 'styled-components';
import { useTrackPageview } from '../../../../../observability/public';
import { NOT_AVAILABLE_LABEL } from '../../../../common/i18n';
import { useFetcher } from '../../../hooks/useFetcher';
import { useLocation } from '../../../hooks/useLocation';
import { useUrlParams } from '../../../hooks/useUrlParams';
import { callApmApi } from '../../../services/rest/createCallApmApi';
import { fontFamilyCode, fontSizes, px, units } from '../../../style/variables';
import { ApmHeader } from '../../shared/ApmHeader';
import { DetailView } from './DetailView';
import { ErrorDistribution } from './Distribution';
var Titles = styled.div.withConfig({
  displayName: "Titles",
  componentId: "sc-1sso7ll-0"
})(["margin-bottom:", ";"], px(units.plus));
var Label = styled.div.withConfig({
  displayName: "Label",
  componentId: "sc-1sso7ll-1"
})(["margin-bottom:", ";font-size:", ";color:", ";"], px(units.quarter), fontSizes.small, function (_ref) {
  var theme = _ref.theme;
  return theme.eui.euiColorMediumShade;
});
var Message = styled.div.withConfig({
  displayName: "Message",
  componentId: "sc-1sso7ll-2"
})(["font-family:", ";font-weight:bold;font-size:", ";margin-bottom:", ";"], fontFamilyCode, fontSizes.large, px(units.half));
var Culprit = styled.div.withConfig({
  displayName: "Culprit",
  componentId: "sc-1sso7ll-3"
})(["font-family:", ";"], fontFamilyCode);

function getShortGroupId(errorGroupId) {
  if (!errorGroupId) {
    return NOT_AVAILABLE_LABEL;
  }

  return errorGroupId.slice(0, 5);
}

export function ErrorGroupDetails() {
  var _errorGroupData$error, _errorGroupData$error2, _errorGroupData$error3, _errorGroupData$error4, _errorGroupData$error5, _errorGroupData$error6, _errorGroupData$error7;

  var location = useLocation();

  var _useUrlParams = useUrlParams(),
      urlParams = _useUrlParams.urlParams,
      uiFilters = _useUrlParams.uiFilters;

  var serviceName = urlParams.serviceName,
      start = urlParams.start,
      end = urlParams.end,
      errorGroupId = urlParams.errorGroupId;

  var _useFetcher = useFetcher(function () {
    if (serviceName && start && end && errorGroupId) {
      return callApmApi({
        pathname: '/api/apm/services/{serviceName}/errors/{groupId}',
        params: {
          path: {
            serviceName: serviceName,
            groupId: errorGroupId
          },
          query: {
            start: start,
            end: end,
            uiFilters: JSON.stringify(uiFilters)
          }
        }
      });
    }
  }, [serviceName, start, end, errorGroupId, uiFilters]),
      errorGroupData = _useFetcher.data;

  var _useFetcher2 = useFetcher(function () {
    if (serviceName && start && end && errorGroupId) {
      return callApmApi({
        pathname: '/api/apm/services/{serviceName}/errors/distribution',
        params: {
          path: {
            serviceName: serviceName
          },
          query: {
            start: start,
            end: end,
            groupId: errorGroupId,
            uiFilters: JSON.stringify(uiFilters)
          }
        }
      });
    }
  }, [serviceName, start, end, errorGroupId, uiFilters]),
      errorDistributionData = _useFetcher2.data;

  useTrackPageview({
    app: 'apm',
    path: 'error_group_details'
  });
  useTrackPageview({
    app: 'apm',
    path: 'error_group_details',
    delay: 15000
  });

  if (!errorGroupData || !errorDistributionData) {
    return null;
  } // If there are 0 occurrences, show only distribution chart w. empty message


  var showDetails = errorGroupData.occurrencesCount !== 0;
  var logMessage = (_errorGroupData$error = errorGroupData.error) === null || _errorGroupData$error === void 0 ? void 0 : (_errorGroupData$error2 = _errorGroupData$error.error.log) === null || _errorGroupData$error2 === void 0 ? void 0 : _errorGroupData$error2.message;
  var excMessage = (_errorGroupData$error3 = errorGroupData.error) === null || _errorGroupData$error3 === void 0 ? void 0 : (_errorGroupData$error4 = _errorGroupData$error3.error.exception) === null || _errorGroupData$error4 === void 0 ? void 0 : _errorGroupData$error4[0].message;
  var culprit = (_errorGroupData$error5 = errorGroupData.error) === null || _errorGroupData$error5 === void 0 ? void 0 : _errorGroupData$error5.error.culprit;
  var isUnhandled = ((_errorGroupData$error6 = errorGroupData.error) === null || _errorGroupData$error6 === void 0 ? void 0 : (_errorGroupData$error7 = _errorGroupData$error6.error.exception) === null || _errorGroupData$error7 === void 0 ? void 0 : _errorGroupData$error7[0].handled) === false;
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(ApmHeader, null, /*#__PURE__*/React.createElement(EuiFlexGroup, {
    alignItems: "center"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiTitle, null, /*#__PURE__*/React.createElement("h1", null, i18n.translate('xpack.apm.errorGroupDetails.errorGroupTitle', {
    defaultMessage: 'Error group {errorGroupId}',
    values: {
      errorGroupId: getShortGroupId(urlParams.errorGroupId)
    }
  })))), isUnhandled && /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiBadge, {
    color: "warning"
  }, i18n.translate('xpack.apm.errorGroupDetails.unhandledLabel', {
    defaultMessage: 'Unhandled'
  }))))), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "s"
  }), /*#__PURE__*/React.createElement(EuiPanel, null, showDetails && /*#__PURE__*/React.createElement(Titles, null, /*#__PURE__*/React.createElement(EuiText, null, logMessage && /*#__PURE__*/React.createElement(Fragment, null, /*#__PURE__*/React.createElement(Label, null, i18n.translate('xpack.apm.errorGroupDetails.logMessageLabel', {
    defaultMessage: 'Log message'
  })), /*#__PURE__*/React.createElement(Message, null, logMessage)), /*#__PURE__*/React.createElement(Label, null, i18n.translate('xpack.apm.errorGroupDetails.exceptionMessageLabel', {
    defaultMessage: 'Exception message'
  })), /*#__PURE__*/React.createElement(Message, null, excMessage || NOT_AVAILABLE_LABEL), /*#__PURE__*/React.createElement(Label, null, i18n.translate('xpack.apm.errorGroupDetails.culpritLabel', {
    defaultMessage: 'Culprit'
  })), /*#__PURE__*/React.createElement(Culprit, null, culprit || NOT_AVAILABLE_LABEL))), /*#__PURE__*/React.createElement(ErrorDistribution, {
    distribution: errorDistributionData,
    title: i18n.translate('xpack.apm.errorGroupDetails.occurrencesChartLabel', {
      defaultMessage: 'Occurrences'
    })
  })), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "s"
  }), showDetails && /*#__PURE__*/React.createElement(DetailView, {
    errorGroup: errorGroupData,
    urlParams: urlParams,
    location: location
  }));
}