function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React, { useState, useEffect } from 'react';
import { i18n } from '@kbn/i18n';
import { EuiTitle, EuiFlexGroup, EuiFlexItem, EuiPanel, EuiSpacer, EuiText, EuiForm, EuiFormRow, EuiFieldText, EuiButton, EuiButtonEmpty } from '@elastic/eui';
import { useFetcher } from '../../../../hooks/useFetcher';
import { callApmApi } from '../../../../services/rest/createCallApmApi';
import { clearCache } from '../../../../services/rest/callApi';
import { useApmPluginContext } from '../../../../hooks/useApmPluginContext';
var APM_INDEX_LABELS = [{
  configurationName: 'apm_oss.sourcemapIndices',
  label: i18n.translate('xpack.apm.settings.apmIndices.sourcemapIndicesLabel', {
    defaultMessage: 'Sourcemap Indices'
  })
}, {
  configurationName: 'apm_oss.errorIndices',
  label: i18n.translate('xpack.apm.settings.apmIndices.errorIndicesLabel', {
    defaultMessage: 'Error Indices'
  })
}, {
  configurationName: 'apm_oss.onboardingIndices',
  label: i18n.translate('xpack.apm.settings.apmIndices.onboardingIndicesLabel', {
    defaultMessage: 'Onboarding Indices'
  })
}, {
  configurationName: 'apm_oss.spanIndices',
  label: i18n.translate('xpack.apm.settings.apmIndices.spanIndicesLabel', {
    defaultMessage: 'Span Indices'
  })
}, {
  configurationName: 'apm_oss.transactionIndices',
  label: i18n.translate('xpack.apm.settings.apmIndices.transactionIndicesLabel', {
    defaultMessage: 'Transaction Indices'
  })
}, {
  configurationName: 'apm_oss.metricsIndices',
  label: i18n.translate('xpack.apm.settings.apmIndices.metricsIndicesLabel', {
    defaultMessage: 'Metrics Indices'
  })
}];

function saveApmIndices(_x) {
  return _saveApmIndices.apply(this, arguments);
} // avoid infinite loop by initializing the state outside the component


function _saveApmIndices() {
  _saveApmIndices = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(_ref) {
    var apmIndices;
    return regeneratorRuntime.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            apmIndices = _ref.apmIndices;
            _context3.next = 3;
            return callApmApi({
              method: 'POST',
              pathname: '/api/apm/settings/apm-indices/save',
              params: {
                body: apmIndices
              }
            });

          case 3:
            clearCache();

          case 4:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));
  return _saveApmIndices.apply(this, arguments);
}

var INITIAL_STATE = [];
export function ApmIndices() {
  var toasts = useApmPluginContext().core.notifications.toasts;

  var _useState = useState({}),
      _useState2 = _slicedToArray(_useState, 2),
      apmIndices = _useState2[0],
      setApmIndices = _useState2[1];

  var _useState3 = useState(false),
      _useState4 = _slicedToArray(_useState3, 2),
      isSaving = _useState4[0],
      setIsSaving = _useState4[1];

  var _useFetcher = useFetcher(function (_callApmApi) {
    return _callApmApi({
      pathname: "/api/apm/settings/apm-index-settings"
    });
  }, []),
      _useFetcher$data = _useFetcher.data,
      data = _useFetcher$data === void 0 ? INITIAL_STATE : _useFetcher$data,
      status = _useFetcher.status,
      refetch = _useFetcher.refetch;

  useEffect(function () {
    setApmIndices(data.reduce(function (acc, _ref2) {
      var configurationName = _ref2.configurationName,
          savedValue = _ref2.savedValue;
      return _objectSpread(_objectSpread({}, acc), {}, _defineProperty({}, configurationName, savedValue));
    }, {}));
  }, [data]);

  var handleApplyChangesEvent = /*#__PURE__*/function () {
    var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(event) {
      return regeneratorRuntime.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              event.preventDefault();
              setIsSaving(true);
              _context.prev = 2;
              _context.next = 5;
              return saveApmIndices({
                apmIndices: apmIndices
              });

            case 5:
              toasts.addSuccess({
                title: i18n.translate('xpack.apm.settings.apmIndices.applyChanges.succeeded.title', {
                  defaultMessage: 'Indices applied'
                }),
                text: i18n.translate('xpack.apm.settings.apmIndices.applyChanges.succeeded.text', {
                  defaultMessage: 'The indices changes were successfully applied. These changes are reflected immediately in the APM UI'
                })
              });
              _context.next = 11;
              break;

            case 8:
              _context.prev = 8;
              _context.t0 = _context["catch"](2);
              toasts.addDanger({
                title: i18n.translate('xpack.apm.settings.apmIndices.applyChanges.failed.title', {
                  defaultMessage: 'Indices could not be applied.'
                }),
                text: i18n.translate('xpack.apm.settings.apmIndices.applyChanges.failed.text', {
                  defaultMessage: 'Something went wrong when applying indices. Error: {errorMessage}',
                  values: {
                    errorMessage: _context.t0.message
                  }
                })
              });

            case 11:
              setIsSaving(false);

            case 12:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, null, [[2, 8]]);
    }));

    return function handleApplyChangesEvent(_x2) {
      return _ref3.apply(this, arguments);
    };
  }();

  var handleChangeIndexConfigurationEvent = /*#__PURE__*/function () {
    var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(event) {
      var _event$target, name, value;

      return regeneratorRuntime.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _event$target = event.target, name = _event$target.name, value = _event$target.value;
              setApmIndices(_objectSpread(_objectSpread({}, apmIndices), {}, _defineProperty({}, name, value)));

            case 2:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));

    return function handleChangeIndexConfigurationEvent(_x3) {
      return _ref4.apply(this, arguments);
    };
  }();

  return /*#__PURE__*/React.createElement(EuiPanel, null, /*#__PURE__*/React.createElement(EuiFlexGroup, {
    alignItems: "center"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiTitle, null, /*#__PURE__*/React.createElement("h2", null, i18n.translate('xpack.apm.settings.apmIndices.title', {
    defaultMessage: 'Indices'
  }))), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "m"
  }), /*#__PURE__*/React.createElement(EuiText, {
    size: "s",
    grow: false
  }, /*#__PURE__*/React.createElement("p", null, i18n.translate('xpack.apm.settings.apmIndices.description', {
    defaultMessage: "The APM UI uses index patterns to query your APM indices. If you've customized the index names that APM Server writes events to, you may need to update these patterns for the APM UI to work. Settings here take precedence over those set in kibana.yml."
  })), /*#__PURE__*/React.createElement(EuiForm, null, APM_INDEX_LABELS.map(function (_ref5) {
    var configurationName = _ref5.configurationName,
        label = _ref5.label;
    var matchedConfiguration = data.find(function (_ref6) {
      var configName = _ref6.configurationName;
      return configName === configurationName;
    });
    var defaultValue = matchedConfiguration ? matchedConfiguration.defaultValue : '';
    var savedUiIndexValue = apmIndices[configurationName] || '';
    return /*#__PURE__*/React.createElement(EuiFormRow, {
      key: configurationName,
      label: label,
      helpText: i18n.translate('xpack.apm.settings.apmIndices.helpText', {
        defaultMessage: 'Overrides {configurationName}: {defaultValue}',
        values: {
          configurationName: configurationName,
          defaultValue: defaultValue
        }
      }),
      fullWidth: true
    }, /*#__PURE__*/React.createElement(EuiFieldText, {
      fullWidth: true,
      name: configurationName,
      placeholder: defaultValue,
      value: savedUiIndexValue,
      onChange: handleChangeIndexConfigurationEvent
    }));
  }), /*#__PURE__*/React.createElement(EuiSpacer, null), /*#__PURE__*/React.createElement(EuiFlexGroup, {
    justifyContent: "flexEnd"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiButtonEmpty, {
    onClick: refetch
  }, i18n.translate('xpack.apm.settings.apmIndices.cancelButton', {
    defaultMessage: 'Cancel'
  }))), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiButton, {
    fill: true,
    onClick: handleApplyChangesEvent,
    isLoading: isSaving,
    disabled: status !== 'success'
  }, i18n.translate('xpack.apm.settings.apmIndices.applyButton', {
    defaultMessage: 'Apply changes'
  })))))))), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "m"
  }));
}