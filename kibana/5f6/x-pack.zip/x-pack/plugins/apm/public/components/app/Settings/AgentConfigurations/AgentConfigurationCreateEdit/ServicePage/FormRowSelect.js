/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { EuiDescribedFormGroup, EuiFormRow } from '@elastic/eui';
import { SelectWithPlaceholder } from '../../../../../shared/SelectWithPlaceholder';
export function FormRowSelect(_ref) {
  var title = _ref.title,
      description = _ref.description,
      fieldLabel = _ref.fieldLabel,
      isLoading = _ref.isLoading,
      options = _ref.options,
      value = _ref.value,
      disabled = _ref.disabled,
      onChange = _ref.onChange;
  return /*#__PURE__*/React.createElement(EuiDescribedFormGroup, {
    fullWidth: true,
    title: /*#__PURE__*/React.createElement("h3", null, title),
    description: description
  }, /*#__PURE__*/React.createElement(EuiFormRow, {
    label: fieldLabel
  }, /*#__PURE__*/React.createElement(SelectWithPlaceholder, {
    isLoading: isLoading,
    options: options,
    value: value,
    disabled: disabled,
    onChange: onChange
  })));
}