/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiFlexGroup, EuiFlexItem, EuiTitle } from '@elastic/eui';
import React from 'react';
import { RumOverview } from '../RumDashboard';
import { RumHeader } from './RumHeader';
export function RumHome() {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(RumHeader, null, /*#__PURE__*/React.createElement(EuiFlexGroup, {
    alignItems: "center"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "l"
  }, /*#__PURE__*/React.createElement("h1", null, "End User Experience"))))), /*#__PURE__*/React.createElement(RumOverview, null));
}