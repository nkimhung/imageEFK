/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiSpacer, EuiTitle } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import { tint } from 'polished';
import React, { Fragment } from 'react'; // @ts-ignore

import sql from 'react-syntax-highlighter/dist/languages/sql';
import SyntaxHighlighter, { registerLanguage // @ts-ignore
} from 'react-syntax-highlighter/dist/light'; // @ts-ignore

import { xcode } from 'react-syntax-highlighter/dist/styles';
import styled from 'styled-components';
import { borderRadius, fontFamilyCode, fontSize, px, unit, units } from '../../../../../../../style/variables';
import { TruncateHeightSection } from './TruncateHeightSection';
registerLanguage('sql', sql);
var DatabaseStatement = styled.div.withConfig({
  displayName: "DatabaseStatement",
  componentId: "sc-1gx74b3-0"
})(["padding:", " ", ";background:", ";border-radius:", ";border:1px solid ", ";font-family:", ";font-size:", ";"], px(units.half), px(unit), function (_ref) {
  var theme = _ref.theme;
  return tint(0.1, theme.eui.euiColorWarning);
}, borderRadius, function (_ref2) {
  var theme = _ref2.theme;
  return theme.eui.euiColorLightShade;
}, fontFamilyCode, fontSize);
var dbSyntaxLineHeight = unit * 1.5;
export function DatabaseContext(_ref3) {
  var dbContext = _ref3.dbContext;

  if (!dbContext || !dbContext.statement) {
    return null;
  }

  if (dbContext.type !== 'sql') {
    return /*#__PURE__*/React.createElement(DatabaseStatement, null, dbContext.statement);
  }

  return /*#__PURE__*/React.createElement(Fragment, null, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xs"
  }, /*#__PURE__*/React.createElement("h3", null, i18n.translate('xpack.apm.transactionDetails.spanFlyout.databaseStatementTitle', {
    defaultMessage: 'Database statement'
  }))), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "m"
  }), /*#__PURE__*/React.createElement(DatabaseStatement, null, /*#__PURE__*/React.createElement(TruncateHeightSection, {
    previewHeight: 10 * dbSyntaxLineHeight
  }, /*#__PURE__*/React.createElement(SyntaxHighlighter, {
    language: 'sql',
    style: xcode,
    customStyle: {
      color: null,
      background: null,
      padding: null,
      lineHeight: px(dbSyntaxLineHeight),
      whiteSpace: 'pre-wrap',
      overflowX: 'scroll'
    }
  }, dbContext.statement))), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "l"
  }));
}