/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiFlexGroup, EuiFlexItem, EuiPanel, EuiSpacer, EuiTitle } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React, { useMemo } from 'react';
import { useTrackPageview } from '../../../../../observability/public';
import { PROJECTION } from '../../../../common/projections/typings';
import { useFetcher } from '../../../hooks/useFetcher';
import { useUrlParams } from '../../../hooks/useUrlParams';
import { callApmApi } from '../../../services/rest/createCallApmApi';
import { LocalUIFilters } from '../../shared/LocalUIFilters';
import { ErrorDistribution } from '../ErrorGroupDetails/Distribution';
import { ErrorGroupList } from './List';

var ErrorGroupOverview = function ErrorGroupOverview() {
  var _useUrlParams = useUrlParams(),
      urlParams = _useUrlParams.urlParams,
      uiFilters = _useUrlParams.uiFilters;

  var serviceName = urlParams.serviceName,
      start = urlParams.start,
      end = urlParams.end,
      sortField = urlParams.sortField,
      sortDirection = urlParams.sortDirection;

  var _useFetcher = useFetcher(function () {
    if (serviceName && start && end) {
      return callApmApi({
        pathname: '/api/apm/services/{serviceName}/errors/distribution',
        params: {
          path: {
            serviceName: serviceName
          },
          query: {
            start: start,
            end: end,
            uiFilters: JSON.stringify(uiFilters)
          }
        }
      });
    }
  }, [serviceName, start, end, uiFilters]),
      errorDistributionData = _useFetcher.data;

  var _useFetcher2 = useFetcher(function () {
    var normalizedSortDirection = sortDirection === 'asc' ? 'asc' : 'desc';

    if (serviceName && start && end) {
      return callApmApi({
        pathname: '/api/apm/services/{serviceName}/errors',
        params: {
          path: {
            serviceName: serviceName
          },
          query: {
            start: start,
            end: end,
            sortField: sortField,
            sortDirection: normalizedSortDirection,
            uiFilters: JSON.stringify(uiFilters)
          }
        }
      });
    }
  }, [serviceName, start, end, sortField, sortDirection, uiFilters]),
      errorGroupListData = _useFetcher2.data;

  useTrackPageview({
    app: 'apm',
    path: 'error_group_overview'
  });
  useTrackPageview({
    app: 'apm',
    path: 'error_group_overview',
    delay: 15000
  });
  var localUIFiltersConfig = useMemo(function () {
    var config = {
      filterNames: ['host', 'containerId', 'podName', 'serviceVersion'],
      params: {
        serviceName: serviceName
      },
      projection: PROJECTION.ERROR_GROUPS
    };
    return config;
  }, [serviceName]);

  if (!errorDistributionData || !errorGroupListData) {
    return null;
  }

  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiSpacer, null), /*#__PURE__*/React.createElement(EuiFlexGroup, null, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: 1
  }, /*#__PURE__*/React.createElement(LocalUIFilters, localUIFiltersConfig)), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: 7
  }, /*#__PURE__*/React.createElement(EuiPanel, null, /*#__PURE__*/React.createElement(ErrorDistribution, {
    distribution: errorDistributionData,
    title: i18n.translate('xpack.apm.serviceDetails.metrics.errorOccurrencesChartTitle', {
      defaultMessage: 'Error occurrences'
    })
  })), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "s"
  }), /*#__PURE__*/React.createElement(EuiPanel, null, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xs"
  }, /*#__PURE__*/React.createElement("h3", null, "Errors")), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "s"
  }), /*#__PURE__*/React.createElement(ErrorGroupList, {
    items: errorGroupListData
  })))));
};

export { ErrorGroupOverview };