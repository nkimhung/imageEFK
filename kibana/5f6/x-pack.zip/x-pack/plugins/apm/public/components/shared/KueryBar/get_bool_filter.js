function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { TRANSACTION_TYPE, ERROR_GROUP_ID, PROCESSOR_EVENT, TRANSACTION_NAME, SERVICE_NAME } from '../../../../common/elasticsearch_fieldnames';
export function getBoolFilter(urlParams) {
  var start = urlParams.start,
      end = urlParams.end,
      serviceName = urlParams.serviceName,
      processorEvent = urlParams.processorEvent;

  if (!start || !end) {
    throw new Error('Date range was not defined');
  }

  var boolFilter = [{
    range: {
      '@timestamp': {
        gte: new Date(start).getTime(),
        lte: new Date(end).getTime(),
        format: 'epoch_millis'
      }
    }
  }];

  if (serviceName) {
    boolFilter.push({
      term: _defineProperty({}, SERVICE_NAME, serviceName)
    });
  }

  switch (processorEvent) {
    case 'transaction':
      boolFilter.push({
        term: _defineProperty({}, PROCESSOR_EVENT, 'transaction')
      });

      if (urlParams.transactionName) {
        boolFilter.push({
          term: _defineProperty({}, TRANSACTION_NAME, urlParams.transactionName)
        });
      }

      if (urlParams.transactionType) {
        boolFilter.push({
          term: _defineProperty({}, TRANSACTION_TYPE, urlParams.transactionType)
        });
      }

      break;

    case 'error':
      boolFilter.push({
        term: _defineProperty({}, PROCESSOR_EVENT, 'error')
      });

      if (urlParams.errorGroupId) {
        boolFilter.push({
          term: _defineProperty({}, ERROR_GROUP_ID, urlParams.errorGroupId)
        });
      }

      break;

    case 'metric':
      boolFilter.push({
        term: _defineProperty({}, PROCESSOR_EVENT, 'metric')
      });
      break;

    default:
      boolFilter.push({
        bool: {
          should: [{
            term: _defineProperty({}, PROCESSOR_EVENT, 'error')
          }, {
            term: _defineProperty({}, PROCESSOR_EVENT, 'transaction')
          }, {
            term: _defineProperty({}, PROCESSOR_EVENT, 'metric')
          }]
        }
      });
  }

  return boolFilter;
}