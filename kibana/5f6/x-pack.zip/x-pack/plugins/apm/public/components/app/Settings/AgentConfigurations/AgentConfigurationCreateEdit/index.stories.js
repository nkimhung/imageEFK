/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { storiesOf } from '@storybook/react';
import React from 'react';
import { FETCH_STATUS } from '../../../../../hooks/useFetcher';
import { createCallApmApi } from '../../../../../services/rest/createCallApmApi';
import { AgentConfigurationCreateEdit } from './index';
import { ApmPluginContext } from '../../../../../context/ApmPluginContext';
import { EuiThemeProvider } from '../../../../../../../observability/public';
storiesOf('app/Settings/AgentConfigurations/AgentConfigurationCreateEdit', module).addDecorator(function (storyFn) {
  var httpMock = {}; // mock

  createCallApmApi(httpMock);
  var contextMock = {
    core: {
      notifications: {
        toasts: {
          addWarning: function addWarning() {},
          addDanger: function addDanger() {}
        }
      }
    }
  };
  return /*#__PURE__*/React.createElement(EuiThemeProvider, null, /*#__PURE__*/React.createElement(ApmPluginContext.Provider, {
    value: contextMock
  }, storyFn()));
}).add('with config', function () {
  return /*#__PURE__*/React.createElement(AgentConfigurationCreateEdit, {
    pageStep: "choose-settings-step",
    existingConfigResult: {
      status: FETCH_STATUS.SUCCESS,
      data: {
        service: {
          name: 'opbeans-node',
          environment: 'production'
        },
        settings: {}
      }
    }
  });
}, {
  info: {
    source: false
  }
});