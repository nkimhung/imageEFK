function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiSuperDatePicker } from '@elastic/eui';
import React from 'react';
import { isEmpty, isEqual, pickBy } from 'lodash';
import { fromQuery, toQuery } from '../Links/url_helpers';
import { history } from '../../../utils/history';
import { useLocation } from '../../../hooks/useLocation';
import { useUrlParams } from '../../../hooks/useUrlParams';
import { clearCache } from '../../../services/rest/callApi';
import { useApmPluginContext } from '../../../hooks/useApmPluginContext';
import { UI_SETTINGS } from '../../../../../../../src/plugins/data/common';

function removeUndefinedAndEmptyProps(obj) {
  return pickBy(obj, function (value) {
    return value !== undefined && !isEmpty(String(value));
  });
}

export function DatePicker() {
  var location = useLocation();

  var _useApmPluginContext = useApmPluginContext(),
      core = _useApmPluginContext.core;

  var timePickerQuickRanges = core.uiSettings.get(UI_SETTINGS.TIMEPICKER_QUICK_RANGES);
  var timePickerTimeDefaults = core.uiSettings.get(UI_SETTINGS.TIMEPICKER_TIME_DEFAULTS);
  var DEFAULT_VALUES = {
    rangeFrom: timePickerTimeDefaults.from,
    rangeTo: timePickerTimeDefaults.to
  };
  var commonlyUsedRanges = timePickerQuickRanges.map(function (_ref) {
    var from = _ref.from,
        to = _ref.to,
        display = _ref.display;
    return {
      start: from,
      end: to,
      label: display
    };
  });

  var _useUrlParams = useUrlParams(),
      urlParams = _useUrlParams.urlParams,
      refreshTimeRange = _useUrlParams.refreshTimeRange;

  function updateUrl(nextQuery) {
    history.push(_objectSpread(_objectSpread({}, location), {}, {
      search: fromQuery(_objectSpread(_objectSpread({}, toQuery(location.search)), nextQuery))
    }));
  }

  function onRefreshChange(_ref2) {
    var isPaused = _ref2.isPaused,
        refreshInterval = _ref2.refreshInterval;
    updateUrl({
      refreshPaused: isPaused,
      refreshInterval: refreshInterval
    });
  }

  function onTimeChange(_ref3) {
    var start = _ref3.start,
        end = _ref3.end;
    updateUrl({
      rangeFrom: start,
      rangeTo: end
    });
  }

  var rangeFrom = urlParams.rangeFrom,
      rangeTo = urlParams.rangeTo,
      refreshPaused = urlParams.refreshPaused,
      refreshInterval = urlParams.refreshInterval;
  var timePickerURLParams = removeUndefinedAndEmptyProps({
    rangeFrom: rangeFrom,
    rangeTo: rangeTo,
    refreshPaused: refreshPaused,
    refreshInterval: refreshInterval
  });

  var nextParams = _objectSpread(_objectSpread({}, DEFAULT_VALUES), timePickerURLParams);

  if (!isEqual(nextParams, timePickerURLParams)) {
    // When the default parameters are not availbale in the url, replace it adding the necessary parameters.
    history.replace(_objectSpread(_objectSpread({}, location), {}, {
      search: fromQuery(_objectSpread(_objectSpread({}, toQuery(location.search)), nextParams))
    }));
  }

  return /*#__PURE__*/React.createElement(EuiSuperDatePicker, {
    start: rangeFrom,
    end: rangeTo,
    isPaused: refreshPaused,
    refreshInterval: refreshInterval,
    onTimeChange: onTimeChange,
    onRefresh: function onRefresh(_ref4) {
      var start = _ref4.start,
          end = _ref4.end;
      clearCache();
      refreshTimeRange({
        rangeFrom: start,
        rangeTo: end
      });
    },
    onRefreshChange: onRefreshChange,
    showUpdateButton: true,
    commonlyUsedRanges: commonlyUsedRanges
  });
}