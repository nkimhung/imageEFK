/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiFlexGrid, EuiFlexItem, EuiPanel, EuiSpacer, EuiFlexGroup } from '@elastic/eui';
import React, { useMemo } from 'react';
import { useServiceMetricCharts } from '../../../hooks/useServiceMetricCharts';
import { MetricsChart } from '../../shared/charts/MetricsChart';
import { useUrlParams } from '../../../hooks/useUrlParams';
import { ChartsSyncContextProvider } from '../../../context/ChartsSyncContext';
import { PROJECTION } from '../../../../common/projections/typings';
import { LocalUIFilters } from '../../shared/LocalUIFilters';
export function ServiceMetrics(_ref) {
  var agentName = _ref.agentName;

  var _useUrlParams = useUrlParams(),
      urlParams = _useUrlParams.urlParams;

  var serviceName = urlParams.serviceName,
      serviceNodeName = urlParams.serviceNodeName;

  var _useServiceMetricChar = useServiceMetricCharts(urlParams, agentName),
      data = _useServiceMetricChar.data;

  var start = urlParams.start,
      end = urlParams.end;
  var localFiltersConfig = useMemo(function () {
    return {
      filterNames: ['host', 'containerId', 'podName', 'serviceVersion'],
      params: {
        serviceName: serviceName,
        serviceNodeName: serviceNodeName
      },
      projection: PROJECTION.METRICS,
      showCount: false
    };
  }, [serviceName, serviceNodeName]);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiSpacer, null), /*#__PURE__*/React.createElement(EuiFlexGroup, null, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: 1
  }, /*#__PURE__*/React.createElement(LocalUIFilters, localFiltersConfig)), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: 7
  }, /*#__PURE__*/React.createElement(ChartsSyncContextProvider, null, /*#__PURE__*/React.createElement(EuiFlexGrid, {
    columns: 2,
    gutterSize: "s"
  }, data.charts.map(function (chart) {
    return /*#__PURE__*/React.createElement(EuiFlexItem, {
      key: chart.key
    }, /*#__PURE__*/React.createElement(EuiPanel, null, /*#__PURE__*/React.createElement(MetricsChart, {
      start: start,
      end: end,
      chart: chart
    })));
  })), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "xxl"
  })))));
}