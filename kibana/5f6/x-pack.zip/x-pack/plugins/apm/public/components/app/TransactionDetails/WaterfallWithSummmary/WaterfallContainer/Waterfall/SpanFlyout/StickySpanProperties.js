/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { i18n } from '@kbn/i18n';
import React from 'react';
import { SPAN_NAME, TRANSACTION_NAME, SERVICE_NAME } from '../../../../../../../../common/elasticsearch_fieldnames';
import { NOT_AVAILABLE_LABEL } from '../../../../../../../../common/i18n';
import { StickyProperties } from '../../../../../../shared/StickyProperties';
import { TransactionOverviewLink } from '../../../../../../shared/Links/apm/TransactionOverviewLink';
import { TransactionDetailLink } from '../../../../../../shared/Links/apm/TransactionDetailLink';
export function StickySpanProperties(_ref) {
  var span = _ref.span,
      transaction = _ref.transaction;
  var spanName = span.span.name;
  var transactionStickyProperties = transaction ? [{
    label: i18n.translate('xpack.apm.transactionDetails.serviceLabel', {
      defaultMessage: 'Service'
    }),
    fieldName: SERVICE_NAME,
    val: /*#__PURE__*/React.createElement(TransactionOverviewLink, {
      serviceName: transaction.service.name
    }, transaction.service.name),
    width: '25%'
  }, {
    label: i18n.translate('xpack.apm.transactionDetails.transactionLabel', {
      defaultMessage: 'Transaction'
    }),
    fieldName: TRANSACTION_NAME,
    val: /*#__PURE__*/React.createElement(TransactionDetailLink, {
      serviceName: transaction.service.name,
      transactionId: transaction.transaction.id,
      traceId: transaction.trace.id,
      transactionName: transaction.transaction.name,
      transactionType: transaction.transaction.type
    }, transaction.transaction.name),
    width: '25%'
  }] : [];
  var stickyProperties = [{
    label: i18n.translate('xpack.apm.transactionDetails.spanFlyout.nameLabel', {
      defaultMessage: 'Name'
    }),
    fieldName: SPAN_NAME,
    val: spanName || NOT_AVAILABLE_LABEL,
    truncated: true,
    width: '25%'
  }].concat(transactionStickyProperties);
  return /*#__PURE__*/React.createElement(StickyProperties, {
    stickyProperties: stickyProperties
  });
}