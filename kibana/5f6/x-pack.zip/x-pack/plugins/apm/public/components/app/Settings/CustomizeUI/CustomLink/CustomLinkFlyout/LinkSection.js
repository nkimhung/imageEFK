/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiFieldText, EuiFormRow, EuiSpacer, EuiText, EuiTitle } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React from 'react';
import { Documentation } from './Documentation';
export var LinkSection = function LinkSection(_ref) {
  var label = _ref.label,
      onChangeLabel = _ref.onChangeLabel,
      url = _ref.url,
      onChangeUrl = _ref.onChangeUrl;
  var inputFields = [{
    name: 'label',
    label: i18n.translate('xpack.apm.settings.customizeUI.customLink.flyout.link.label', {
      defaultMessage: 'Label'
    }),
    helpText: i18n.translate('xpack.apm.settings.customizeUI.customLink.flyout.link.label.helpText', {
      defaultMessage: 'This is the label shown in the actions context menu. Keep it as short as possible.'
    }),
    placeholder: i18n.translate('xpack.apm.settings.customizeUI.customLink.flyout.link.label.placeholder', {
      defaultMessage: 'e.g. Support tickets'
    }),
    value: label,
    onChange: onChangeLabel
  }, {
    name: 'url',
    label: i18n.translate('xpack.apm.settings.customizeUI.customLink.flyout.link.url', {
      defaultMessage: 'URL'
    }),
    helpText: /*#__PURE__*/React.createElement(React.Fragment, null, i18n.translate('xpack.apm.settings.customizeUI.customLink.flyout.link.url.helpText', {
      defaultMessage: 'Add field name variables to your URL to apply values e.g. {sample}.',
      values: {
        sample: '{{trace.id}}'
      }
    }), ' ', /*#__PURE__*/React.createElement(Documentation, {
      label: i18n.translate('xpack.apm.settings.customizeUI.customLink.flyout.link.url.doc', {
        defaultMessage: 'Learn more in the docs.'
      })
    })),
    placeholder: i18n.translate('xpack.apm.settings.customizeUI.customLink.flyout.link.url.placeholder', {
      defaultMessage: 'e.g. https://www.elastic.co/'
    }),
    value: url,
    onChange: onChangeUrl
  }];
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xs"
  }, /*#__PURE__*/React.createElement("h3", null, i18n.translate('xpack.apm.settings.customizeUI.customLink.flyout.action.title', {
    defaultMessage: 'Link'
  }))), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "l"
  }), inputFields.map(function (field) {
    return /*#__PURE__*/React.createElement(EuiFormRow, {
      fullWidth: true,
      key: field.name,
      label: field.label,
      helpText: field.helpText,
      labelAppend: /*#__PURE__*/React.createElement(EuiText, {
        size: "xs"
      }, i18n.translate('xpack.apm.settings.customizeUI.customLink.flyout.required', {
        defaultMessage: 'Required'
      }))
    }, /*#__PURE__*/React.createElement(EuiFieldText, {
      placeholder: field.placeholder,
      name: field.name,
      fullWidth: true,
      value: field.value,
      onChange: function onChange(e) {
        return field.onChange(e.target.value);
      },
      "data-test-subj": field.name
    }));
  }));
};