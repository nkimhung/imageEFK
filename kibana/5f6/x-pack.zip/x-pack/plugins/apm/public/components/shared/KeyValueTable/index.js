function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { EuiTable, EuiTableBody, EuiTableRow, EuiTableRowCell } from '@elastic/eui';
import { FormattedValue } from './FormattedValue';
export function KeyValueTable(_ref) {
  var keyValuePairs = _ref.keyValuePairs,
      _ref$tableProps = _ref.tableProps,
      tableProps = _ref$tableProps === void 0 ? {} : _ref$tableProps;
  return /*#__PURE__*/React.createElement(EuiTable, _extends({
    compressed: true
  }, tableProps), /*#__PURE__*/React.createElement(EuiTableBody, null, keyValuePairs.map(function (_ref2) {
    var key = _ref2.key,
        value = _ref2.value;
    return /*#__PURE__*/React.createElement(EuiTableRow, {
      key: key
    }, /*#__PURE__*/React.createElement(EuiTableRowCell, null, /*#__PURE__*/React.createElement("strong", {
      "data-test-subj": "dot-key"
    }, key)), /*#__PURE__*/React.createElement(EuiTableRowCell, {
      "data-test-subj": "value"
    }, /*#__PURE__*/React.createElement(FormattedValue, {
      value: value
    })));
  })));
}