/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiFlexGroup, EuiFlexItem, EuiTitle, EuiSpacer, EuiPanel } from '@elastic/eui';
import React from 'react';
import { ClientMetrics } from './ClientMetrics';
import { PageViewsTrend } from './PageViewsTrend';
import { PageLoadDistribution } from './PageLoadDistribution';
import { I18LABELS } from './translations';
import { VisitorBreakdown } from './VisitorBreakdown';
export var RumDashboard = function RumDashboard() {
  return /*#__PURE__*/React.createElement(EuiFlexGroup, {
    direction: "column",
    gutterSize: "s"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(EuiPanel, null, /*#__PURE__*/React.createElement(EuiFlexGroup, {
    justifyContent: "spaceBetween"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: 1,
    "data-cy": "client-metrics"
  }, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xs"
  }, /*#__PURE__*/React.createElement("h3", null, I18LABELS.pageLoadTimes)), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "s"
  }), /*#__PURE__*/React.createElement(ClientMetrics, null))))), /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(EuiPanel, null, /*#__PURE__*/React.createElement(EuiFlexGroup, {
    justifyContent: "spaceBetween"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: 3
  }, /*#__PURE__*/React.createElement(PageLoadDistribution, null), /*#__PURE__*/React.createElement(PageViewsTrend, null)))), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "s"
  }), /*#__PURE__*/React.createElement(EuiPanel, null, /*#__PURE__*/React.createElement(EuiFlexGroup, {
    justifyContent: "spaceBetween"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: 3
  }, /*#__PURE__*/React.createElement(VisitorBreakdown, null))))));
};