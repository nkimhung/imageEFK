/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { i18n } from '@kbn/i18n';
import React from 'react';
import { SERVICE_NAME, TRANSACTION_NAME } from '../../../../../../../common/elasticsearch_fieldnames';
import { TransactionDetailLink } from '../../../../../shared/Links/apm/TransactionDetailLink';
import { StickyProperties } from '../../../../../shared/StickyProperties';
import { TransactionOverviewLink } from '../../../../../shared/Links/apm/TransactionOverviewLink';
export function FlyoutTopLevelProperties(_ref) {
  var transaction = _ref.transaction;

  if (!transaction) {
    return null;
  }

  var stickyProperties = [{
    label: i18n.translate('xpack.apm.transactionDetails.serviceLabel', {
      defaultMessage: 'Service'
    }),
    fieldName: SERVICE_NAME,
    val: /*#__PURE__*/React.createElement(TransactionOverviewLink, {
      serviceName: transaction.service.name
    }, transaction.service.name),
    width: '25%'
  }, {
    label: i18n.translate('xpack.apm.transactionDetails.transactionLabel', {
      defaultMessage: 'Transaction'
    }),
    fieldName: TRANSACTION_NAME,
    val: /*#__PURE__*/React.createElement(TransactionDetailLink, {
      serviceName: transaction.service.name,
      transactionId: transaction.transaction.id,
      traceId: transaction.trace.id,
      transactionName: transaction.transaction.name,
      transactionType: transaction.transaction.type
    }, transaction.transaction.name),
    width: '25%'
  }];
  return /*#__PURE__*/React.createElement(StickyProperties, {
    stickyProperties: stickyProperties
  });
}