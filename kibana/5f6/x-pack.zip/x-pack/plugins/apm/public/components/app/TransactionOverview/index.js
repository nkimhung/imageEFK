function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiPanel, EuiSpacer, EuiTitle, EuiFlexGroup, EuiFlexItem, EuiHorizontalRule, EuiCallOut, EuiCode } from '@elastic/eui';
import { FormattedMessage } from '@kbn/i18n/react';
import { first } from 'lodash';
import React, { useMemo } from 'react';
import { i18n } from '@kbn/i18n';
import { EuiFlexGrid } from '@elastic/eui';
import { useTransactionList } from '../../../hooks/useTransactionList';
import { useTransactionCharts } from '../../../hooks/useTransactionCharts';
import { TransactionCharts } from '../../shared/charts/TransactionCharts';
import { ErroneousTransactionsRateChart } from '../../shared/charts/ErroneousTransactionsRateChart';
import { TransactionBreakdown } from '../../shared/TransactionBreakdown';
import { TransactionList } from './List';
import { ElasticDocsLink } from '../../shared/Links/ElasticDocsLink';
import { useRedirect } from './useRedirect';
import { history } from '../../../utils/history';
import { useLocation } from '../../../hooks/useLocation';
import { ChartsSyncContextProvider } from '../../../context/ChartsSyncContext';
import { useTrackPageview } from '../../../../../observability/public';
import { fromQuery, toQuery } from '../../shared/Links/url_helpers';
import { LocalUIFilters } from '../../shared/LocalUIFilters';
import { PROJECTION } from '../../../../common/projections/typings';
import { useUrlParams } from '../../../hooks/useUrlParams';
import { useServiceTransactionTypes } from '../../../hooks/useServiceTransactionTypes';
import { TransactionTypeFilter } from '../../shared/LocalUIFilters/TransactionTypeFilter';

function getRedirectLocation(_ref) {
  var urlParams = _ref.urlParams,
      location = _ref.location,
      serviceTransactionTypes = _ref.serviceTransactionTypes;
  var transactionType = urlParams.transactionType;
  var firstTransactionType = first(serviceTransactionTypes);

  if (!transactionType && firstTransactionType) {
    return _objectSpread(_objectSpread({}, location), {}, {
      search: fromQuery(_objectSpread(_objectSpread({}, toQuery(location.search)), {}, {
        transactionType: firstTransactionType
      }))
    });
  }
}

export function TransactionOverview() {
  var location = useLocation();

  var _useUrlParams = useUrlParams(),
      urlParams = _useUrlParams.urlParams;

  var serviceName = urlParams.serviceName,
      transactionType = urlParams.transactionType; // TODO: fetching of transaction types should perhaps be lifted since it is needed in several places. Context?

  var serviceTransactionTypes = useServiceTransactionTypes(urlParams); // redirect to first transaction type

  useRedirect(history, getRedirectLocation({
    urlParams: urlParams,
    location: location,
    serviceTransactionTypes: serviceTransactionTypes
  }));

  var _useTransactionCharts = useTransactionCharts(),
      transactionCharts = _useTransactionCharts.data;

  useTrackPageview({
    app: 'apm',
    path: 'transaction_overview'
  });
  useTrackPageview({
    app: 'apm',
    path: 'transaction_overview',
    delay: 15000
  });

  var _useTransactionList = useTransactionList(urlParams),
      transactionListData = _useTransactionList.data,
      transactionListStatus = _useTransactionList.status;

  var localFiltersConfig = useMemo(function () {
    return {
      filterNames: ['transactionResult', 'host', 'containerId', 'podName', 'serviceVersion'],
      params: {
        serviceName: serviceName,
        transactionType: transactionType
      },
      projection: PROJECTION.TRANSACTION_GROUPS
    };
  }, [serviceName, transactionType]); // TODO: improve urlParams typings.
  // `serviceName` or `transactionType` will never be undefined here, and this check should not be needed

  if (!serviceName || !transactionType) {
    return null;
  }

  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiSpacer, null), /*#__PURE__*/React.createElement(EuiFlexGroup, null, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: 1
  }, /*#__PURE__*/React.createElement(LocalUIFilters, localFiltersConfig, /*#__PURE__*/React.createElement(TransactionTypeFilter, {
    transactionTypes: serviceTransactionTypes
  }), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "xl"
  }), /*#__PURE__*/React.createElement(EuiHorizontalRule, {
    margin: "none"
  }))), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: 7
  }, /*#__PURE__*/React.createElement(ChartsSyncContextProvider, null, /*#__PURE__*/React.createElement(EuiFlexGrid, {
    columns: 2,
    gutterSize: "s"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(TransactionBreakdown, null)), /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(ErroneousTransactionsRateChart, null))), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "s"
  }), /*#__PURE__*/React.createElement(TransactionCharts, {
    charts: transactionCharts,
    location: location,
    urlParams: urlParams
  })), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "s"
  }), /*#__PURE__*/React.createElement(EuiPanel, null, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xs"
  }, /*#__PURE__*/React.createElement("h3", null, "Transactions")), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "s"
  }), !transactionListData.isAggregationAccurate && /*#__PURE__*/React.createElement(EuiCallOut, {
    title: i18n.translate('xpack.apm.transactionCardinalityWarning.title', {
      defaultMessage: 'This view shows a subset of reported transactions.'
    }),
    color: "danger",
    iconType: "alert"
  }, /*#__PURE__*/React.createElement("p", null, /*#__PURE__*/React.createElement(FormattedMessage, {
    id: "xpack.apm.transactionCardinalityWarning.body",
    defaultMessage: "The number of unique transaction names exceeds the configured value of {bucketSize}. Try reconfiguring your agents to group similar transactions or increase the value of {codeBlock}",
    values: {
      bucketSize: transactionListData.bucketSize,
      codeBlock: /*#__PURE__*/React.createElement(EuiCode, null, "xpack.apm.ui.transactionGroupBucketSize")
    }
  }), /*#__PURE__*/React.createElement(ElasticDocsLink, {
    section: "/kibana",
    path: "/troubleshooting.html#troubleshooting-too-many-transactions"
  }, i18n.translate('xpack.apm.transactionCardinalityWarning.docsLink', {
    defaultMessage: 'Learn more in the docs'
  })))), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "s"
  }), /*#__PURE__*/React.createElement(TransactionList, {
    isLoading: transactionListStatus === 'loading',
    items: transactionListData.items
  })))));
}