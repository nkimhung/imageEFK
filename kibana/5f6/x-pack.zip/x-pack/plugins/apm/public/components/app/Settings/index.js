function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { i18n } from '@kbn/i18n';
import { EuiButtonEmpty, EuiPage, EuiSideNav, EuiPageSideBar, EuiPageBody } from '@elastic/eui';
import { HomeLink } from '../../shared/Links/apm/HomeLink';
import { useLocation } from '../../../hooks/useLocation';
import { getAPMHref } from '../../shared/Links/apm/APMLink';
import { useApmPluginContext } from '../../../hooks/useApmPluginContext';
export var Settings = function Settings(props) {
  var _plugin$core$applicat;

  var plugin = useApmPluginContext();
  var canAccessML = !!((_plugin$core$applicat = plugin.core.application.capabilities.ml) === null || _plugin$core$applicat === void 0 ? void 0 : _plugin$core$applicat.canAccessML);

  var _useLocation = useLocation(),
      search = _useLocation.search,
      pathname = _useLocation.pathname;

  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(HomeLink, null, /*#__PURE__*/React.createElement(EuiButtonEmpty, {
    size: "s",
    color: "primary",
    iconType: "arrowLeft"
  }, i18n.translate('xpack.apm.settings.returnToOverviewLinkLabel', {
    defaultMessage: 'Return to overview'
  }))), /*#__PURE__*/React.createElement(EuiPage, null, /*#__PURE__*/React.createElement(EuiPageSideBar, null, /*#__PURE__*/React.createElement(EuiSideNav, {
    items: [{
      name: i18n.translate('xpack.apm.settings.pageTitle', {
        defaultMessage: 'Settings'
      }),
      id: 0,
      items: [{
        name: i18n.translate('xpack.apm.settings.agentConfig', {
          defaultMessage: 'Agent Configuration'
        }),
        id: '1',
        href: getAPMHref('/settings/agent-configuration', search),
        isSelected: pathname.startsWith('/settings/agent-configuration')
      }].concat(_toConsumableArray(canAccessML ? [{
        name: i18n.translate('xpack.apm.settings.anomalyDetection', {
          defaultMessage: 'Anomaly detection'
        }),
        id: '4',
        href: getAPMHref('/settings/anomaly-detection', search),
        isSelected: pathname === '/settings/anomaly-detection'
      }] : []), [{
        name: i18n.translate('xpack.apm.settings.customizeApp', {
          defaultMessage: 'Customize app'
        }),
        id: '3',
        href: getAPMHref('/settings/customize-ui', search),
        isSelected: pathname === '/settings/customize-ui'
      }, {
        name: i18n.translate('xpack.apm.settings.indices', {
          defaultMessage: 'Indices'
        }),
        id: '2',
        href: getAPMHref('/settings/apm-indices', search),
        isSelected: pathname === '/settings/apm-indices'
      }])
    }]
  })), /*#__PURE__*/React.createElement(EuiPageBody, null, props.children)));
};