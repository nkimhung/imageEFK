function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { isEmpty } from 'lodash';
import { EuiTitle, EuiText, EuiSpacer } from '@elastic/eui';
import React, { useState, useEffect, useCallback } from 'react';
import { i18n } from '@kbn/i18n';
import { history } from '../../../../../utils/history';
import { ServicePage } from './ServicePage/ServicePage';
import { SettingsPage } from './SettingsPage/SettingsPage';
import { fromQuery, toQuery } from '../../../../shared/Links/url_helpers';

function getInitialNewConfig(existingConfig) {
  return {
    agent_name: existingConfig === null || existingConfig === void 0 ? void 0 : existingConfig.agent_name,
    service: (existingConfig === null || existingConfig === void 0 ? void 0 : existingConfig.service) || {},
    settings: (existingConfig === null || existingConfig === void 0 ? void 0 : existingConfig.settings) || {}
  };
}

function setPage(pageStep) {
  history.push(_objectSpread(_objectSpread({}, history.location), {}, {
    search: fromQuery(_objectSpread(_objectSpread({}, toQuery(history.location.search)), {}, {
      pageStep: pageStep
    }))
  }));
}

function getUnsavedChanges(_ref) {
  var newConfig = _ref.newConfig,
      existingConfig = _ref.existingConfig;
  return Object.fromEntries(Object.entries(newConfig.settings).filter(function (_ref2) {
    var _existingConfig$setti;

    var _ref3 = _slicedToArray(_ref2, 2),
        key = _ref3[0],
        value = _ref3[1];

    var existingValue = existingConfig === null || existingConfig === void 0 ? void 0 : (_existingConfig$setti = existingConfig.settings) === null || _existingConfig$setti === void 0 ? void 0 : _existingConfig$setti[key]; // don't highlight changes that were added and removed

    if (value === '' && existingValue == null) {
      return false;
    }

    return existingValue !== value;
  }));
}

export function AgentConfigurationCreateEdit(_ref4) {
  var pageStep = _ref4.pageStep,
      existingConfigResult = _ref4.existingConfigResult;
  var existingConfig = existingConfigResult === null || existingConfigResult === void 0 ? void 0 : existingConfigResult.data;
  var isEditMode = Boolean(existingConfigResult);

  var _useState = useState(getInitialNewConfig(existingConfig)),
      _useState2 = _slicedToArray(_useState, 2),
      newConfig = _useState2[0],
      setNewConfig = _useState2[1];

  var resetSettings = useCallback(function () {
    setNewConfig(function (_newConfig) {
      return _objectSpread(_objectSpread({}, _newConfig), {}, {
        settings: (existingConfig === null || existingConfig === void 0 ? void 0 : existingConfig.settings) || {}
      });
    });
    /* eslint-disable-next-line react-hooks/exhaustive-deps */
  }, [existingConfig]); // update newConfig when existingConfig has loaded

  useEffect(function () {
    setNewConfig(getInitialNewConfig(existingConfig));
  }, [existingConfig]);
  useEffect(function () {
    // the user tried to edit the service of an existing config
    if (pageStep === 'choose-service-step' && isEditMode) {
      setPage('choose-settings-step');
    } // the user skipped the first step (select service)


    if (pageStep === 'choose-settings-step' && !isEditMode && isEmpty(newConfig.service)) {
      setPage('choose-service-step');
    }
  }, [isEditMode, newConfig, pageStep]);
  var unsavedChanges = getUnsavedChanges({
    newConfig: newConfig,
    existingConfig: existingConfig
  });
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiTitle, null, /*#__PURE__*/React.createElement("h2", null, isEditMode ? i18n.translate('xpack.apm.agentConfig.editConfigTitle', {
    defaultMessage: 'Edit configuration'
  }) : i18n.translate('xpack.apm.agentConfig.createConfigTitle', {
    defaultMessage: 'Create configuration'
  }))), /*#__PURE__*/React.createElement(EuiText, {
    size: "s"
  }, i18n.translate('xpack.apm.agentConfig.newConfig.description', {
    defaultMessage: "This allows you to fine-tune your agent configuration directly in\n        Kibana. Best of all, changes are automatically propagated to your APM\n        agents so there\u2019s no need to redeploy."
  })), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "m"
  }), pageStep === 'choose-service-step' && /*#__PURE__*/React.createElement(ServicePage, {
    newConfig: newConfig,
    setNewConfig: setNewConfig,
    onClickNext: function onClickNext() {
      resetSettings();
      setPage('choose-settings-step');
    }
  }), pageStep === 'choose-settings-step' && /*#__PURE__*/React.createElement(SettingsPage, {
    status: existingConfigResult === null || existingConfigResult === void 0 ? void 0 : existingConfigResult.status,
    unsavedChanges: unsavedChanges,
    onClickEdit: function onClickEdit() {
      return setPage('choose-service-step');
    },
    newConfig: newConfig,
    setNewConfig: setNewConfig,
    resetSettings: resetSettings,
    isEditMode: isEditMode
  }));
}