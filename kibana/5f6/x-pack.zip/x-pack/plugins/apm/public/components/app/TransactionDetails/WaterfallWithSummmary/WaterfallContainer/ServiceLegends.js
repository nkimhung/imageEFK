function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiTitle } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React from 'react';
import styled from 'styled-components';
import { px, unit } from '../../../../../style/variables'; // @ts-ignore

import { Legend } from '../../../../shared/charts/Legend';
var Legends = styled.div.withConfig({
  displayName: "Legends",
  componentId: "sc-1oa4pwu-0"
})(["display:flex;> *{margin-right:", ";&:last-child{margin-right:0;}}"], px(unit));
export function ServiceLegends(_ref) {
  var serviceColors = _ref.serviceColors;
  return /*#__PURE__*/React.createElement(Legends, null, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xxxs"
  }, /*#__PURE__*/React.createElement("span", null, i18n.translate('xpack.apm.transactionDetails.servicesTitle', {
    defaultMessage: 'Services'
  }))), Object.entries(serviceColors).map(function (_ref2) {
    var _ref3 = _slicedToArray(_ref2, 2),
        label = _ref3[0],
        color = _ref3[1];

    return /*#__PURE__*/React.createElement(Legend, {
      key: color,
      color: color,
      text: label
    });
  }));
}