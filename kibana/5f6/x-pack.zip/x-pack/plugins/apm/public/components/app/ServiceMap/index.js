/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { EuiFlexGroup, EuiFlexItem } from '@elastic/eui';
import { useTheme } from '../../../hooks/useTheme';
import { invalidLicenseMessage, isValidPlatinumLicense } from '../../../../common/service_map';
import { useFetcher } from '../../../hooks/useFetcher';
import { useLicense } from '../../../hooks/useLicense';
import { useUrlParams } from '../../../hooks/useUrlParams';
import { callApmApi } from '../../../services/rest/createCallApmApi';
import { LicensePrompt } from '../../shared/LicensePrompt';
import { Controls } from './Controls';
import { Cytoscape } from './Cytoscape';
import { getCytoscapeDivStyle } from './cytoscapeOptions';
import { EmptyBanner } from './EmptyBanner';
import { Popover } from './Popover';
import { useRefDimensions } from './useRefDimensions';
import { BetaBadge } from './BetaBadge';
import { useTrackPageview } from '../../../../../observability/public';
export var ServiceMap = function ServiceMap(_ref) {
  var _data$elements;

  var serviceName = _ref.serviceName;
  var theme = useTheme();
  var license = useLicense();

  var _useUrlParams = useUrlParams(),
      urlParams = _useUrlParams.urlParams;

  var _useFetcher = useFetcher(function () {
    // When we don't have a license or a valid license, don't make the request.
    if (!license || !isValidPlatinumLicense(license)) {
      return;
    }

    var start = urlParams.start,
        end = urlParams.end,
        environment = urlParams.environment;

    if (start && end) {
      return callApmApi({
        isCachable: false,
        pathname: '/api/apm/service-map',
        params: {
          query: {
            start: start,
            end: end,
            environment: environment,
            serviceName: serviceName
          }
        }
      });
    }
  }, [license, serviceName, urlParams]),
      _useFetcher$data = _useFetcher.data,
      data = _useFetcher$data === void 0 ? {
    elements: []
  } : _useFetcher$data;

  var _useRefDimensions = useRefDimensions(),
      ref = _useRefDimensions.ref,
      height = _useRefDimensions.height,
      width = _useRefDimensions.width;

  useTrackPageview({
    app: 'apm',
    path: 'service_map'
  });
  useTrackPageview({
    app: 'apm',
    path: 'service_map',
    delay: 15000
  });

  if (!license) {
    return null;
  }

  return isValidPlatinumLicense(license) ? /*#__PURE__*/React.createElement("div", {
    style: {
      height: height - parseInt(theme.eui.gutterTypes.gutterLarge, 10)
    },
    ref: ref
  }, /*#__PURE__*/React.createElement(Cytoscape, {
    elements: (_data$elements = data === null || data === void 0 ? void 0 : data.elements) !== null && _data$elements !== void 0 ? _data$elements : [],
    height: height,
    serviceName: serviceName,
    style: getCytoscapeDivStyle(theme),
    width: width
  }, /*#__PURE__*/React.createElement(Controls, null), /*#__PURE__*/React.createElement(BetaBadge, null), serviceName && /*#__PURE__*/React.createElement(EmptyBanner, null), /*#__PURE__*/React.createElement(Popover, {
    focusedServiceName: serviceName
  }))) : /*#__PURE__*/React.createElement(EuiFlexGroup, {
    alignItems: "center",
    justifyContent: "spaceAround" // Set the height to give it some top margin
    ,
    style: {
      height: '60vh'
    }
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false,
    style: {
      width: 600,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement(LicensePrompt, {
    text: invalidLicenseMessage,
    showBetaBadge: true
  })));
};