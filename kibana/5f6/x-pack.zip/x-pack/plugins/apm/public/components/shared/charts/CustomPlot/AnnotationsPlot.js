/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { VerticalGridLines } from 'react-vis';
import { EuiIcon, EuiToolTip, EuiFlexGroup, EuiFlexItem, EuiText } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import { useTheme } from '../../../../hooks/useTheme';
import { SharedPlot } from './plotUtils';
import { asAbsoluteDateTime } from '../../../../utils/formatters';
export var AnnotationsPlot = function AnnotationsPlot(_ref) {
  var plotValues = _ref.plotValues,
      annotations = _ref.annotations;
  var theme = useTheme();
  var tickValues = annotations.map(function (annotation) {
    return annotation['@timestamp'];
  });
  var style = {
    stroke: theme.eui.euiColorSecondary,
    strokeDasharray: 'none'
  };
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(SharedPlot, {
    plotValues: plotValues
  }, /*#__PURE__*/React.createElement(VerticalGridLines, {
    tickValues: tickValues,
    style: style
  })), annotations.map(function (annotation) {
    return /*#__PURE__*/React.createElement("div", {
      key: annotation.id,
      style: {
        position: 'absolute',
        left: plotValues.x(annotation['@timestamp']) - 8,
        top: -2
      }
    }, /*#__PURE__*/React.createElement(EuiToolTip, {
      title: asAbsoluteDateTime(annotation['@timestamp'], 'seconds'),
      content: /*#__PURE__*/React.createElement(EuiFlexGroup, null, /*#__PURE__*/React.createElement(EuiFlexItem, {
        grow: true
      }, /*#__PURE__*/React.createElement(EuiText, null, i18n.translate('xpack.apm.version', {
        defaultMessage: 'Version'
      }))), /*#__PURE__*/React.createElement(EuiFlexItem, {
        grow: false
      }, annotation.text))
    }, /*#__PURE__*/React.createElement(EuiIcon, {
      type: "dot",
      color: theme.eui.euiColorSecondary
    })));
  }));
};