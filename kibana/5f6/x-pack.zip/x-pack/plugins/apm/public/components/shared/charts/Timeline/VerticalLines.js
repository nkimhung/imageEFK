/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { VerticalGridLines, XYPlot } from 'react-vis';
import { useTheme } from '../../../../hooks/useTheme';
export var VerticalLines = function VerticalLines(_ref) {
  var topTraceDuration = _ref.topTraceDuration,
      plotValues = _ref.plotValues,
      _ref$marks = _ref.marks,
      marks = _ref$marks === void 0 ? [] : _ref$marks;
  var width = plotValues.width,
      height = plotValues.height,
      margins = plotValues.margins,
      xDomain = plotValues.xDomain,
      tickValues = plotValues.tickValues;
  var markTimes = marks.filter(function (mark) {
    return mark.verticalLine;
  }).map(function (_ref2) {
    var offset = _ref2.offset;
    return offset;
  });
  var theme = useTheme();
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 0,
      left: 0
    }
  }, /*#__PURE__*/React.createElement(XYPlot, {
    dontCheckIfEmpty: true,
    width: width,
    height: height + margins.top,
    margin: margins,
    xDomain: xDomain
  }, /*#__PURE__*/React.createElement(VerticalGridLines, {
    tickValues: tickValues,
    style: {
      stroke: theme.eui.euiColorLightestShade
    }
  }), /*#__PURE__*/React.createElement(VerticalGridLines, {
    tickValues: markTimes,
    style: {
      stroke: theme.eui.euiColorMediumShade
    }
  }), topTraceDuration > 0 && /*#__PURE__*/React.createElement(VerticalGridLines, {
    tickValues: [topTraceDuration],
    style: {
      stroke: theme.eui.euiColorMediumShade
    }
  })));
};