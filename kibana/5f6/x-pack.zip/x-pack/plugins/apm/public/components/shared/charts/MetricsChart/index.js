function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiTitle } from '@elastic/eui';
import React from 'react'; // eslint-disable-next-line @kbn/eslint/no-restricted-paths

// @ts-ignore
import CustomPlot from '../CustomPlot';
import { asDecimal, asPercent, asInteger, asDynamicBytes, getFixedByteFormatter, asDuration } from '../../../../utils/formatters';
import { isValidCoordinateValue } from '../../../../utils/isValidCoordinateValue';
import { useChartsSync } from '../../../../hooks/useChartsSync';
export function MetricsChart(_ref) {
  var chart = _ref.chart;
  var formatYValue = getYTickFormatter(chart);
  var formatTooltip = getTooltipFormatter(chart);
  var transformedSeries = chart.series.map(function (series) {
    return _objectSpread(_objectSpread({}, series), {}, {
      legendValue: formatYValue(series.overallValue)
    });
  });
  var syncedChartProps = useChartsSync();
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xs"
  }, /*#__PURE__*/React.createElement("span", null, chart.title)), /*#__PURE__*/React.createElement(CustomPlot, _extends({}, syncedChartProps, {
    series: transformedSeries,
    tickFormatY: formatYValue,
    formatTooltipValue: formatTooltip,
    yMax: chart.yUnit === 'percent' ? 1 : 'max'
  })));
}

function getYTickFormatter(chart) {
  switch (chart.yUnit) {
    case 'bytes':
      {
        var max = Math.max.apply(Math, _toConsumableArray(chart.series.flatMap(function (series) {
          return series.data.map(function (coord) {
            return coord.y || 0;
          });
        })));
        return getFixedByteFormatter(max);
      }

    case 'percent':
      {
        return function (y) {
          return asPercent(y || 0, 1);
        };
      }

    case 'time':
      {
        return function (y) {
          return asDuration(y);
        };
      }

    case 'integer':
      {
        return function (y) {
          return isValidCoordinateValue(y) ? asInteger(y) : y;
        };
      }

    default:
      {
        return function (y) {
          return isValidCoordinateValue(y) ? asDecimal(y) : y;
        };
      }
  }
}

function getTooltipFormatter(_ref2) {
  var yUnit = _ref2.yUnit;

  switch (yUnit) {
    case 'bytes':
      {
        return function (c) {
          return asDynamicBytes(c.y);
        };
      }

    case 'percent':
      {
        return function (c) {
          return asPercent(c.y || 0, 1);
        };
      }

    case 'time':
      {
        return function (c) {
          return asDuration(c.y);
        };
      }

    case 'integer':
      {
        return function (c) {
          return isValidCoordinateValue(c.y) ? asInteger(c.y) : c.y;
        };
      }

    default:
      {
        return function (c) {
          return isValidCoordinateValue(c.y) ? asDecimal(c.y) : c.y;
        };
      }
  }
}