function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import styled from 'styled-components';
import { useTheme } from '../../../../hooks/useTheme';
import { fontSizes, px, units } from '../../../../style/variables';
export var Shape;

(function (Shape) {
  Shape["circle"] = "circle";
  Shape["square"] = "square";
})(Shape || (Shape = {}));

var Container = styled.div.withConfig({
  displayName: "Container",
  componentId: "udpfxr-0"
})(["display:flex;align-items:center;font-size:", ";color:", ";cursor:", ";opacity:", ";user-select:none;"], function (props) {
  return props.fontSize;
}, function (_ref) {
  var theme = _ref.theme;
  return theme.eui.euiColorDarkShade;
}, function (props) {
  return props.clickable ? 'pointer' : 'initial';
}, function (props) {
  return props.disabled ? 0.4 : 1;
});
export var Indicator = styled.span.withConfig({
  displayName: "Indicator",
  componentId: "udpfxr-1"
})(["width:", ";height:", ";margin-right:", ";background:", ";border-radius:", ";"], function (props) {
  return px(props.radius);
}, function (props) {
  return px(props.radius);
}, function (props) {
  return props.withMargin ? px(props.radius / 2) : 0;
}, function (props) {
  return props.color;
}, function (props) {
  return props.shape === Shape.circle ? '100%' : '0';
});
export var Legend = function Legend(_ref2) {
  var onClick = _ref2.onClick,
      text = _ref2.text,
      color = _ref2.color,
      _ref2$fontSize = _ref2.fontSize,
      fontSize = _ref2$fontSize === void 0 ? fontSizes.small : _ref2$fontSize,
      _ref2$radius = _ref2.radius,
      radius = _ref2$radius === void 0 ? units.minus - 1 : _ref2$radius,
      _ref2$disabled = _ref2.disabled,
      disabled = _ref2$disabled === void 0 ? false : _ref2$disabled,
      _ref2$clickable = _ref2.clickable,
      clickable = _ref2$clickable === void 0 ? false : _ref2$clickable,
      _ref2$shape = _ref2.shape,
      shape = _ref2$shape === void 0 ? Shape.circle : _ref2$shape,
      indicator = _ref2.indicator,
      rest = _objectWithoutProperties(_ref2, ["onClick", "text", "color", "fontSize", "radius", "disabled", "clickable", "shape", "indicator"]);

  var theme = useTheme();
  var indicatorColor = color || theme.eui.euiColorVis1;
  return /*#__PURE__*/React.createElement(Container, _extends({
    onClick: onClick,
    disabled: disabled,
    clickable: clickable || Boolean(onClick),
    fontSize: fontSize
  }, rest), indicator ? indicator() : /*#__PURE__*/React.createElement(Indicator, {
    color: indicatorColor,
    radius: radius,
    shape: shape,
    withMargin: !!text
  }), text);
};