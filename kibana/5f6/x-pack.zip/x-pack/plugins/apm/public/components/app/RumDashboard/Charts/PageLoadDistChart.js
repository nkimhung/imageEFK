function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React, { useState } from 'react';
import numeral from '@elastic/numeral';
import { Axis, Chart, CurveType, LineSeries, ScaleType, Settings, DARK_THEME, LIGHT_THEME } from '@elastic/charts';
import { EUI_CHARTS_THEME_DARK, EUI_CHARTS_THEME_LIGHT } from '@elastic/eui/dist/eui_charts_theme';
import { Position } from '@elastic/charts/dist/utils/commons';
import styled from 'styled-components';
import { PercentileAnnotations } from '../PageLoadDistribution/PercentileAnnotations';
import { I18LABELS } from '../translations';
import { ChartWrapper } from '../ChartWrapper';
import { useUiSetting$ } from '../../../../../../../../src/plugins/kibana_react/public';
import { BreakdownSeries } from '../PageLoadDistribution/BreakdownSeries';
var PageLoadChart = styled(Chart).withConfig({
  displayName: "PageLoadChart",
  componentId: "h0xeca-0"
})([".echAnnotation{pointer-events:initial;}"]);
export function PageLoadDistChart(_ref) {
  var _data$pageLoadDistrib;

  var onPercentileChange = _ref.onPercentileChange,
      data = _ref.data,
      breakdowns = _ref.breakdowns,
      loading = _ref.loading,
      percentileRange = _ref.percentileRange;

  var _useState = useState(false),
      _useState2 = _slicedToArray(_useState, 2),
      breakdownLoading = _useState2[0],
      setBreakdownLoading = _useState2[1];

  var onBrushEnd = function onBrushEnd(_ref2) {
    var x = _ref2.x;

    if (!x) {
      return;
    }

    var _x = _slicedToArray(x, 2),
        minX = _x[0],
        maxX = _x[1];

    onPercentileChange(minX, maxX);
  };

  var headerFormatter = function headerFormatter(tooltip) {
    return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", null, tooltip.value, " ", I18LABELS.seconds));
  };

  var tooltipProps = {
    headerFormatter: headerFormatter
  };

  var _useUiSetting$ = useUiSetting$('theme:darkMode'),
      _useUiSetting$2 = _slicedToArray(_useUiSetting$, 1),
      darkMode = _useUiSetting$2[0];

  return /*#__PURE__*/React.createElement(ChartWrapper, {
    loading: loading || breakdownLoading,
    height: "250px"
  }, (!loading || data) && /*#__PURE__*/React.createElement(PageLoadChart, null, /*#__PURE__*/React.createElement(Settings, {
    baseTheme: darkMode ? DARK_THEME : LIGHT_THEME,
    theme: darkMode ? EUI_CHARTS_THEME_DARK.theme : EUI_CHARTS_THEME_LIGHT.theme,
    onBrushEnd: onBrushEnd,
    tooltip: tooltipProps,
    showLegend: true
  }), /*#__PURE__*/React.createElement(PercentileAnnotations, {
    percentiles: data === null || data === void 0 ? void 0 : data.percentiles
  }), /*#__PURE__*/React.createElement(Axis, {
    id: "bottom",
    title: I18LABELS.pageLoadTime,
    position: Position.Bottom
  }), /*#__PURE__*/React.createElement(Axis, {
    id: "left",
    title: I18LABELS.percPageLoaded,
    position: Position.Left,
    tickFormat: function tickFormat(d) {
      return numeral(d).format('0.0') + '%';
    }
  }), /*#__PURE__*/React.createElement(LineSeries, {
    id: 'PagesPercentage',
    name: I18LABELS.overall,
    xScaleType: ScaleType.Linear,
    yScaleType: ScaleType.Linear,
    data: (_data$pageLoadDistrib = data === null || data === void 0 ? void 0 : data.pageLoadDistribution) !== null && _data$pageLoadDistrib !== void 0 ? _data$pageLoadDistrib : [],
    curve: CurveType.CURVE_CATMULL_ROM
  }), breakdowns.map(function (_ref3) {
    var name = _ref3.name,
        type = _ref3.type;
    return /*#__PURE__*/React.createElement(BreakdownSeries, {
      key: "".concat(type, "-").concat(name),
      field: type,
      value: name,
      percentileRange: percentileRange,
      onLoadingChange: function onLoadingChange(bLoading) {
        setBreakdownLoading(bLoading);
      }
    });
  })));
}