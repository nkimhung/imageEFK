function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React, { useState } from 'react';
import { EuiConfirmModal, EuiOverlayMask } from '@elastic/eui';
import { i18n } from '@kbn/i18n'; // eslint-disable-next-line @kbn/eslint/no-restricted-paths

import { getOptionLabel } from '../../../../../../common/agent_configuration/all_option';
import { callApmApi } from '../../../../../services/rest/createCallApmApi';
import { useApmPluginContext } from '../../../../../hooks/useApmPluginContext';
export function ConfirmDeleteModal(_ref) {
  var config = _ref.config,
      onCancel = _ref.onCancel,
      onConfirm = _ref.onConfirm;

  var _useState = useState(false),
      _useState2 = _slicedToArray(_useState, 2),
      isDeleting = _useState2[0],
      setIsDeleting = _useState2[1];

  var toasts = useApmPluginContext().core.notifications.toasts;
  return /*#__PURE__*/React.createElement(EuiOverlayMask, null, /*#__PURE__*/React.createElement(EuiConfirmModal, {
    title: i18n.translate('xpack.apm.agentConfig.deleteModal.title', {
      defaultMessage: "Delete configuration"
    }),
    onCancel: onCancel,
    onConfirm: /*#__PURE__*/_asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
      return regeneratorRuntime.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              setIsDeleting(true);
              _context.next = 3;
              return deleteConfig(config, toasts);

            case 3:
              setIsDeleting(false);
              onConfirm();

            case 5:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    })),
    cancelButtonText: i18n.translate('xpack.apm.agentConfig.deleteModal.cancel', {
      defaultMessage: "Cancel"
    }),
    confirmButtonText: i18n.translate('xpack.apm.agentConfig.deleteModal.confirm', {
      defaultMessage: "Delete"
    }),
    confirmButtonDisabled: isDeleting,
    buttonColor: "danger",
    defaultFocusedButton: "confirm"
  }, /*#__PURE__*/React.createElement("p", null, i18n.translate('xpack.apm.agentConfig.deleteModal.text', {
    defaultMessage: "You are about to delete the configuration for service \"{serviceName}\" and environment \"{environment}\".",
    values: {
      serviceName: getOptionLabel(config.service.name),
      environment: getOptionLabel(config.service.environment)
    }
  }))));
}

function deleteConfig(_x, _x2) {
  return _deleteConfig.apply(this, arguments);
}

function _deleteConfig() {
  _deleteConfig = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(config, toasts) {
    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            _context2.next = 3;
            return callApmApi({
              pathname: '/api/apm/settings/agent-configuration',
              method: 'DELETE',
              params: {
                body: {
                  service: {
                    name: config.service.name,
                    environment: config.service.environment
                  }
                }
              }
            });

          case 3:
            toasts.addSuccess({
              title: i18n.translate('xpack.apm.agentConfig.deleteSection.deleteConfigSucceededTitle', {
                defaultMessage: 'Configuration was deleted'
              }),
              text: i18n.translate('xpack.apm.agentConfig.deleteSection.deleteConfigSucceededText', {
                defaultMessage: 'You have successfully deleted a configuration for "{serviceName}". It will take some time to propagate to the agents.',
                values: {
                  serviceName: getOptionLabel(config.service.name)
                }
              })
            });
            _context2.next = 9;
            break;

          case 6:
            _context2.prev = 6;
            _context2.t0 = _context2["catch"](0);
            toasts.addDanger({
              title: i18n.translate('xpack.apm.agentConfig.deleteSection.deleteConfigFailedTitle', {
                defaultMessage: 'Configuration could not be deleted'
              }),
              text: i18n.translate('xpack.apm.agentConfig.deleteSection.deleteConfigFailedText', {
                defaultMessage: 'Something went wrong when deleting a configuration for "{serviceName}". Error: "{errorMessage}"',
                values: {
                  serviceName: getOptionLabel(config.service.name),
                  errorMessage: _context2.t0.message
                }
              })
            });

          case 9:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2, null, [[0, 6]]);
  }));
  return _deleteConfig.apply(this, arguments);
}