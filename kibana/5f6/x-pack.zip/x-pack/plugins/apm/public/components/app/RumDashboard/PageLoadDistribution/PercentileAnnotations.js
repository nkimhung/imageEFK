/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import * as React from 'react';
import { AnnotationDomainTypes, LineAnnotation } from '@elastic/charts';
import euiLightVars from '@elastic/eui/dist/eui_theme_light.json';
import styled from 'styled-components';
import { EuiToolTip } from '@elastic/eui';

function generateAnnotationData(values) {
  return Object.entries(values !== null && values !== void 0 ? values : {}).map(function (value) {
    return {
      dataValue: value[1],
      details: "".concat((+value[0]).toFixed(0))
    };
  });
}

var PercentileMarker = styled.span.withConfig({
  displayName: "PercentileMarker",
  componentId: "sc-16my31f-0"
})(["position:relative;bottom:205px;"]);
export var PercentileAnnotations = function PercentileAnnotations(_ref) {
  var _generateAnnotationDa;

  var percentiles = _ref.percentiles;
  var dataValues = (_generateAnnotationDa = generateAnnotationData(percentiles)) !== null && _generateAnnotationDa !== void 0 ? _generateAnnotationDa : [];
  var style = {
    line: {
      strokeWidth: 1,
      stroke: euiLightVars.euiColorSecondary,
      opacity: 1
    }
  };

  var PercentileTooltip = function PercentileTooltip(_ref2) {
    var annotation = _ref2.annotation;
    return /*#__PURE__*/React.createElement("span", {
      "data-cy": "percentileTooltipTitle"
    }, annotation.details, "th Percentile");
  };

  return /*#__PURE__*/React.createElement(React.Fragment, null, dataValues.map(function (annotation, index) {
    return /*#__PURE__*/React.createElement(LineAnnotation, {
      id: index + 'annotation_' + annotation.dataValue,
      key: index + 'percentile_' + annotation.dataValue,
      domainType: AnnotationDomainTypes.XDomain,
      dataValues: [annotation],
      style: style,
      hideTooltips: true,
      marker: /*#__PURE__*/React.createElement(PercentileMarker, {
        "data-cy": "percentile-markers"
      }, /*#__PURE__*/React.createElement(EuiToolTip, {
        title: /*#__PURE__*/React.createElement(PercentileTooltip, {
          annotation: annotation
        }),
        content: /*#__PURE__*/React.createElement("span", null, "Pages loaded: ", Math.round(annotation.dataValue))
      }, /*#__PURE__*/React.createElement(React.Fragment, null, annotation.details, "th")))
    });
  }));
};