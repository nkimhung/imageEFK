function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiButtonEmpty, EuiPanel, EuiSpacer, EuiTab, EuiTabs, EuiTitle, EuiIcon, EuiToolTip } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React from 'react';
import styled from 'styled-components';
import { first } from 'lodash'; // eslint-disable-next-line @kbn/eslint/no-restricted-paths

import { px, unit, units } from '../../../../style/variables';
import { DiscoverErrorLink } from '../../../shared/Links/DiscoverLinks/DiscoverErrorLink';
import { fromQuery, toQuery } from '../../../shared/Links/url_helpers';
import { history } from '../../../../utils/history';
import { ErrorMetadata } from '../../../shared/MetadataTable/ErrorMetadata';
import { Stacktrace } from '../../../shared/Stacktrace';
import { exceptionStacktraceTab, getTabs, logStacktraceTab } from './ErrorTabs';
import { Summary } from '../../../shared/Summary';
import { TimestampTooltip } from '../../../shared/TimestampTooltip';
import { HttpInfoSummaryItem } from '../../../shared/Summary/HttpInfoSummaryItem';
import { TransactionDetailLink } from '../../../shared/Links/apm/TransactionDetailLink';
import { UserAgentSummaryItem } from '../../../shared/Summary/UserAgentSummaryItem';
import { ExceptionStacktrace } from './ExceptionStacktrace';
var HeaderContainer = styled.div.withConfig({
  displayName: "HeaderContainer",
  componentId: "hqj9qf-0"
})(["display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:", ";"], px(unit));
var TransactionLinkName = styled.div.withConfig({
  displayName: "TransactionLinkName",
  componentId: "hqj9qf-1"
})(["margin-left:", ";display:inline-block;vertical-align:middle;"], px(units.half));

// TODO: Move query-string-based tabs into a re-usable component?
function getCurrentTab() {
  var tabs = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
  var currentTabKey = arguments.length > 1 ? arguments[1] : undefined;
  var selectedTab = tabs.find(function (_ref) {
    var key = _ref.key;
    return key === currentTabKey;
  });
  return selectedTab ? selectedTab : first(tabs) || {};
}

export function DetailView(_ref2) {
  var _error$error$page, _error$url, _error$http, _error$http$request, _error$http2, _error$http2$response;

  var errorGroup = _ref2.errorGroup,
      urlParams = _ref2.urlParams,
      location = _ref2.location;
  var transaction = errorGroup.transaction,
      error = errorGroup.error,
      occurrencesCount = errorGroup.occurrencesCount;

  if (!error) {
    return null;
  }

  var tabs = getTabs(error);
  var currentTab = getCurrentTab(tabs, urlParams.detailTab);
  var errorUrl = ((_error$error$page = error.error.page) === null || _error$error$page === void 0 ? void 0 : _error$error$page.url) || ((_error$url = error.url) === null || _error$url === void 0 ? void 0 : _error$url.full);
  var method = (_error$http = error.http) === null || _error$http === void 0 ? void 0 : (_error$http$request = _error$http.request) === null || _error$http$request === void 0 ? void 0 : _error$http$request.method;
  var status = (_error$http2 = error.http) === null || _error$http2 === void 0 ? void 0 : (_error$http2$response = _error$http2.response) === null || _error$http2$response === void 0 ? void 0 : _error$http2$response.status_code;
  return /*#__PURE__*/React.createElement(EuiPanel, null, /*#__PURE__*/React.createElement(HeaderContainer, null, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "s"
  }, /*#__PURE__*/React.createElement("h3", null, i18n.translate('xpack.apm.errorGroupDetails.errorOccurrenceTitle', {
    defaultMessage: 'Error occurrence'
  }))), /*#__PURE__*/React.createElement(DiscoverErrorLink, {
    error: error,
    kuery: urlParams.kuery
  }, /*#__PURE__*/React.createElement(EuiButtonEmpty, {
    iconType: "discoverApp"
  }, i18n.translate('xpack.apm.errorGroupDetails.viewOccurrencesInDiscoverButtonLabel', {
    defaultMessage: 'View {occurrencesCount} {occurrencesCount, plural, one {occurrence} other {occurrences}} in Discover.',
    values: {
      occurrencesCount: occurrencesCount
    }
  })))), /*#__PURE__*/React.createElement(Summary, {
    items: [/*#__PURE__*/React.createElement(TimestampTooltip, {
      time: error.timestamp.us / 1000
    }), errorUrl && method ? /*#__PURE__*/React.createElement(HttpInfoSummaryItem, {
      url: errorUrl,
      method: method,
      status: status
    }) : null, transaction && transaction.user_agent ? /*#__PURE__*/React.createElement(UserAgentSummaryItem, transaction.user_agent) : null, transaction && /*#__PURE__*/React.createElement(EuiToolTip, {
      content: i18n.translate('xpack.apm.errorGroupDetails.relatedTransactionSample', {
        defaultMessage: 'Related transaction sample'
      })
    }, /*#__PURE__*/React.createElement(TransactionDetailLink, {
      traceId: transaction.trace.id,
      transactionId: transaction.transaction.id,
      transactionName: transaction.transaction.name,
      transactionType: transaction.transaction.type,
      serviceName: transaction.service.name
    }, /*#__PURE__*/React.createElement(EuiIcon, {
      type: "merge"
    }), /*#__PURE__*/React.createElement(TransactionLinkName, null, transaction.transaction.name)))]
  }), /*#__PURE__*/React.createElement(EuiSpacer, null), /*#__PURE__*/React.createElement(EuiTabs, null, tabs.map(function (_ref3) {
    var key = _ref3.key,
        label = _ref3.label;
    return /*#__PURE__*/React.createElement(EuiTab, {
      onClick: function onClick() {
        history.replace(_objectSpread(_objectSpread({}, location), {}, {
          search: fromQuery(_objectSpread(_objectSpread({}, toQuery(location.search)), {}, {
            detailTab: key
          }))
        }));
      },
      isSelected: currentTab.key === key,
      key: key
    }, label);
  })), /*#__PURE__*/React.createElement(EuiSpacer, null), /*#__PURE__*/React.createElement(TabContent, {
    error: error,
    currentTab: currentTab
  }));
}

function TabContent(_ref4) {
  var _error$service$langua, _error$error$log;

  var error = _ref4.error,
      currentTab = _ref4.currentTab;
  var codeLanguage = (_error$service$langua = error.service.language) === null || _error$service$langua === void 0 ? void 0 : _error$service$langua.name;
  var exceptions = error.error.exception || [];
  var logStackframes = (_error$error$log = error.error.log) === null || _error$error$log === void 0 ? void 0 : _error$error$log.stacktrace;

  switch (currentTab.key) {
    case logStacktraceTab.key:
      return /*#__PURE__*/React.createElement(Stacktrace, {
        stackframes: logStackframes,
        codeLanguage: codeLanguage
      });

    case exceptionStacktraceTab.key:
      return /*#__PURE__*/React.createElement(ExceptionStacktrace, {
        codeLanguage: codeLanguage,
        exceptions: exceptions
      });

    default:
      return /*#__PURE__*/React.createElement(ErrorMetadata, {
        error: error
      });
  }
}