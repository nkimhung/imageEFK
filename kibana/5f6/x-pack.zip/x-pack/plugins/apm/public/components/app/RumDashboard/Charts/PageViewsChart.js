function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import numeral from '@elastic/numeral';
import { Axis, BarSeries, Chart, niceTimeFormatByDay, ScaleType, Settings, timeFormatter } from '@elastic/charts';
import { DARK_THEME, LIGHT_THEME } from '@elastic/charts';
import { EUI_CHARTS_THEME_DARK, EUI_CHARTS_THEME_LIGHT } from '@elastic/eui/dist/eui_charts_theme';
import moment from 'moment';
import { Position } from '@elastic/charts/dist/utils/commons';
import { I18LABELS } from '../translations';
import { history } from '../../../../utils/history';
import { fromQuery, toQuery } from '../../../shared/Links/url_helpers';
import { ChartWrapper } from '../ChartWrapper';
import { useUiSetting$ } from '../../../../../../../../src/plugins/kibana_react/public';
export function PageViewsChart(_ref) {
  var data = _ref.data,
      loading = _ref.loading;
  var formatter = timeFormatter(niceTimeFormatByDay(2));

  var onBrushEnd = function onBrushEnd(_ref2) {
    var x = _ref2.x;

    if (!x) {
      return;
    }

    var _x = _slicedToArray(x, 2),
        minX = _x[0],
        maxX = _x[1];

    var rangeFrom = moment(minX).toISOString();
    var rangeTo = moment(maxX).toISOString();
    history.push(_objectSpread(_objectSpread({}, history.location), {}, {
      search: fromQuery(_objectSpread(_objectSpread({}, toQuery(history.location.search)), {}, {
        rangeFrom: rangeFrom,
        rangeTo: rangeTo
      }))
    }));
  };

  var breakdownAccessors = new Set();

  if (data && data.length > 0) {
    data.forEach(function (item) {
      breakdownAccessors = new Set([].concat(_toConsumableArray(Array.from(breakdownAccessors)), _toConsumableArray(Object.keys(item).filter(function (key) {
        return key !== 'x';
      }))));
    });
  }

  var customSeriesNaming = function customSeriesNaming(_ref3) {
    var yAccessor = _ref3.yAccessor;

    if (yAccessor === 'y') {
      return I18LABELS.overall;
    }

    return yAccessor;
  };

  var _useUiSetting$ = useUiSetting$('theme:darkMode'),
      _useUiSetting$2 = _slicedToArray(_useUiSetting$, 1),
      darkMode = _useUiSetting$2[0];

  return /*#__PURE__*/React.createElement(ChartWrapper, {
    loading: loading,
    height: "250px"
  }, (!loading || data) && /*#__PURE__*/React.createElement(Chart, null, /*#__PURE__*/React.createElement(Settings, {
    baseTheme: darkMode ? DARK_THEME : LIGHT_THEME,
    theme: darkMode ? EUI_CHARTS_THEME_DARK.theme : EUI_CHARTS_THEME_LIGHT.theme,
    showLegend: true,
    onBrushEnd: onBrushEnd
  }), /*#__PURE__*/React.createElement(Axis, {
    id: "date_time",
    position: Position.Bottom,
    title: I18LABELS.dateTime,
    tickFormat: formatter
  }), /*#__PURE__*/React.createElement(Axis, {
    id: "page_views",
    title: I18LABELS.pageViews,
    position: Position.Left,
    tickFormat: function tickFormat(d) {
      return numeral(d).format('0.0 a');
    }
  }), /*#__PURE__*/React.createElement(BarSeries, {
    id: I18LABELS.pageViews,
    xScaleType: ScaleType.Time,
    yScaleType: ScaleType.Linear,
    xAccessor: "x",
    yAccessors: Array.from(breakdownAccessors),
    data: data !== null && data !== void 0 ? data : [],
    name: customSeriesNaming
  })));
}