/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { ElasticDocsLink } from '../../../../../shared/Links/ElasticDocsLink';
export var Documentation = function Documentation(_ref) {
  var label = _ref.label;
  return /*#__PURE__*/React.createElement(ElasticDocsLink, {
    section: "/kibana",
    path: "/custom-links.html",
    target: "_blank"
  }, label);
};