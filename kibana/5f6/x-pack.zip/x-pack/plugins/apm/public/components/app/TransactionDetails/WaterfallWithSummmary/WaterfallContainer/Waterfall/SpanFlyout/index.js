/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiButtonEmpty, EuiFlexGroup, EuiFlexItem, EuiFlyoutBody, EuiFlyoutHeader, EuiHorizontalRule, EuiPortal, EuiSpacer, EuiTabbedContent, EuiTitle, EuiBadge, EuiToolTip } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React, { Fragment } from 'react';
import styled from 'styled-components';
import { px, units } from '../../../../../../../style/variables';
import { Summary } from '../../../../../../shared/Summary';
import { TimestampTooltip } from '../../../../../../shared/TimestampTooltip';
import { DurationSummaryItem } from '../../../../../../shared/Summary/DurationSummaryItem';
import { DiscoverSpanLink } from '../../../../../../shared/Links/DiscoverLinks/DiscoverSpanLink';
import { Stacktrace } from '../../../../../../shared/Stacktrace';
import { ResponsiveFlyout } from '../ResponsiveFlyout';
import { DatabaseContext } from './DatabaseContext';
import { StickySpanProperties } from './StickySpanProperties';
import { HttpInfoSummaryItem } from '../../../../../../shared/Summary/HttpInfoSummaryItem';
import { SpanMetadata } from '../../../../../../shared/MetadataTable/SpanMetadata';
import { SyncBadge } from '../SyncBadge';

function formatType(type) {
  switch (type) {
    case 'db':
      return 'DB';

    case 'hard-navigation':
      return i18n.translate('xpack.apm.transactionDetails.spanFlyout.spanType.navigationTimingLabel', {
        defaultMessage: 'Navigation timing'
      });

    default:
      return type;
  }
}

function formatSubtype(subtype) {
  switch (subtype) {
    case 'mysql':
      return 'MySQL';

    default:
      return subtype;
  }
}

function getSpanTypes(span) {
  var _span$span = span.span,
      type = _span$span.type,
      subtype = _span$span.subtype,
      action = _span$span.action;
  return {
    spanType: formatType(type),
    spanSubtype: formatSubtype(subtype),
    spanAction: action
  };
}

var SpanBadge = styled(EuiBadge).withConfig({
  displayName: "SpanBadge",
  componentId: "sc-1ngh34m-0"
})(["display:inline-block;margin-right:", ";"], px(units.quarter));
var HttpInfoContainer = styled('div').withConfig({
  displayName: "HttpInfoContainer",
  componentId: "sc-1ngh34m-1"
})(["margin-right:", ";"], px(units.quarter));
export function SpanFlyout(_ref) {
  var _parentTransaction$se, _httpContext$response, _httpContext$url;

  var span = _ref.span,
      parentTransaction = _ref.parentTransaction,
      totalDuration = _ref.totalDuration,
      onClose = _ref.onClose;

  if (!span) {
    return null;
  }

  var stackframes = span.span.stacktrace;
  var codeLanguage = parentTransaction === null || parentTransaction === void 0 ? void 0 : (_parentTransaction$se = parentTransaction.service.language) === null || _parentTransaction$se === void 0 ? void 0 : _parentTransaction$se.name;
  var dbContext = span.span.db;
  var httpContext = span.span.http;
  var spanTypes = getSpanTypes(span);
  var spanHttpStatusCode = httpContext === null || httpContext === void 0 ? void 0 : (_httpContext$response = httpContext.response) === null || _httpContext$response === void 0 ? void 0 : _httpContext$response.status_code;
  var spanHttpUrl = httpContext === null || httpContext === void 0 ? void 0 : (_httpContext$url = httpContext.url) === null || _httpContext$url === void 0 ? void 0 : _httpContext$url.original;
  var spanHttpMethod = httpContext === null || httpContext === void 0 ? void 0 : httpContext.method;
  return /*#__PURE__*/React.createElement(EuiPortal, null, /*#__PURE__*/React.createElement(ResponsiveFlyout, {
    onClose: onClose,
    size: "m",
    ownFocus: true
  }, /*#__PURE__*/React.createElement(EuiFlyoutHeader, {
    hasBorder: true
  }, /*#__PURE__*/React.createElement(EuiFlexGroup, null, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiTitle, null, /*#__PURE__*/React.createElement("h2", null, i18n.translate('xpack.apm.transactionDetails.spanFlyout.spanDetailsTitle', {
    defaultMessage: 'Span details'
  })))), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(DiscoverSpanLink, {
    span: span
  }, /*#__PURE__*/React.createElement(EuiButtonEmpty, {
    iconType: "discoverApp"
  }, i18n.translate('xpack.apm.transactionDetails.spanFlyout.viewSpanInDiscoverButtonLabel', {
    defaultMessage: 'View span in Discover'
  })))))), /*#__PURE__*/React.createElement(EuiFlyoutBody, null, /*#__PURE__*/React.createElement(StickySpanProperties, {
    span: span,
    transaction: parentTransaction
  }), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "m"
  }), /*#__PURE__*/React.createElement(Summary, {
    items: [/*#__PURE__*/React.createElement(TimestampTooltip, {
      time: span.timestamp.us / 1000
    }), /*#__PURE__*/React.createElement(DurationSummaryItem, {
      duration: span.span.duration.us,
      totalDuration: totalDuration,
      parentType: "transaction"
    }), /*#__PURE__*/React.createElement(React.Fragment, null, spanHttpUrl && /*#__PURE__*/React.createElement(HttpInfoContainer, null, /*#__PURE__*/React.createElement(HttpInfoSummaryItem, {
      method: spanHttpMethod,
      url: spanHttpUrl,
      status: spanHttpStatusCode
    })), /*#__PURE__*/React.createElement(EuiToolTip, {
      content: i18n.translate('xpack.apm.transactionDetails.spanFlyout.spanType', {
        defaultMessage: 'Type'
      })
    }, /*#__PURE__*/React.createElement(SpanBadge, {
      color: "hollow"
    }, spanTypes.spanType)), spanTypes.spanSubtype && /*#__PURE__*/React.createElement(EuiToolTip, {
      content: i18n.translate('xpack.apm.transactionDetails.spanFlyout.spanSubtype', {
        defaultMessage: 'Subtype'
      })
    }, /*#__PURE__*/React.createElement(SpanBadge, {
      color: "hollow"
    }, spanTypes.spanSubtype)), spanTypes.spanAction && /*#__PURE__*/React.createElement(EuiToolTip, {
      content: i18n.translate('xpack.apm.transactionDetails.spanFlyout.spanAction', {
        defaultMessage: 'Action'
      })
    }, /*#__PURE__*/React.createElement(SpanBadge, {
      color: "hollow"
    }, spanTypes.spanAction)), /*#__PURE__*/React.createElement(SyncBadge, {
      sync: span.span.sync
    }))]
  }), /*#__PURE__*/React.createElement(EuiHorizontalRule, null), /*#__PURE__*/React.createElement(DatabaseContext, {
    dbContext: dbContext
  }), /*#__PURE__*/React.createElement(EuiTabbedContent, {
    tabs: [{
      id: 'stack-trace',
      name: i18n.translate('xpack.apm.transactionDetails.spanFlyout.stackTraceTabLabel', {
        defaultMessage: 'Stack Trace'
      }),
      content: /*#__PURE__*/React.createElement(Fragment, null, /*#__PURE__*/React.createElement(EuiSpacer, {
        size: "l"
      }), /*#__PURE__*/React.createElement(Stacktrace, {
        stackframes: stackframes,
        codeLanguage: codeLanguage
      }))
    }, {
      id: 'metadata',
      name: i18n.translate('xpack.apm.propertiesTable.tabs.metadataLabel', {
        defaultMessage: 'Metadata'
      }),
      content: /*#__PURE__*/React.createElement(Fragment, null, /*#__PURE__*/React.createElement(EuiSpacer, {
        size: "m"
      }), /*#__PURE__*/React.createElement(SpanMetadata, {
        span: span
      }))
    }]
  }))));
}