/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiButton, EuiEmptyPrompt, EuiPanel } from '@elastic/eui';
import React from 'react';
import { i18n } from '@kbn/i18n';
import { useKibanaUrl } from '../../../hooks/useKibanaUrl';
export var LicensePrompt = function LicensePrompt(_ref) {
  var text = _ref.text,
      _ref$showBetaBadge = _ref.showBetaBadge,
      showBetaBadge = _ref$showBetaBadge === void 0 ? false : _ref$showBetaBadge;
  var licensePageUrl = useKibanaUrl('/app/management/stack/license_management');
  var renderLicenseBody = /*#__PURE__*/React.createElement(EuiEmptyPrompt, {
    iconType: "iInCircle",
    iconColor: "subdued",
    title: /*#__PURE__*/React.createElement("h2", null, i18n.translate('xpack.apm.license.title', {
      defaultMessage: 'Start free 30-day trial'
    })),
    body: /*#__PURE__*/React.createElement("p", null, text),
    actions: /*#__PURE__*/React.createElement(EuiButton, {
      fill: true,
      href: licensePageUrl
    }, i18n.translate('xpack.apm.license.button', {
      defaultMessage: 'Start trial'
    }))
  });
  var renderWithBetaBadge = /*#__PURE__*/React.createElement(EuiPanel, {
    betaBadgeLabel: i18n.translate('xpack.apm.license.betaBadge', {
      defaultMessage: 'Beta'
    }),
    betaBadgeTooltipContent: i18n.translate('xpack.apm.license.betaTooltipMessage', {
      defaultMessage: 'This feature is currently in beta. If you encounter any bugs or have feedback, please open an issue or visit our discussion forum.'
    })
  }, renderLicenseBody);
  return /*#__PURE__*/React.createElement(React.Fragment, null, showBetaBadge ? renderWithBetaBadge : renderLicenseBody);
};