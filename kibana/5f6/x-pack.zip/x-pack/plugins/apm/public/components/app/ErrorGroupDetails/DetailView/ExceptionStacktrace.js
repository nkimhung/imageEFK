/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { EuiTitle } from '@elastic/eui';
import { Stacktrace } from '../../../shared/Stacktrace';
import { CauseStacktrace } from '../../../shared/Stacktrace/CauseStacktrace';
export function ExceptionStacktrace(_ref) {
  var _exceptions$;

  var codeLanguage = _ref.codeLanguage,
      exceptions = _ref.exceptions;
  var title = (_exceptions$ = exceptions[0]) === null || _exceptions$ === void 0 ? void 0 : _exceptions$.message;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xs"
  }, /*#__PURE__*/React.createElement("h4", null, title)), exceptions.map(function (ex, index) {
    return index === 0 ? /*#__PURE__*/React.createElement(Stacktrace, {
      key: index,
      stackframes: ex.stacktrace,
      codeLanguage: codeLanguage
    }) : /*#__PURE__*/React.createElement(CauseStacktrace, {
      codeLanguage: codeLanguage,
      key: index,
      id: index.toString(),
      message: ex.message,
      stackframes: ex.stacktrace
    });
  }));
}