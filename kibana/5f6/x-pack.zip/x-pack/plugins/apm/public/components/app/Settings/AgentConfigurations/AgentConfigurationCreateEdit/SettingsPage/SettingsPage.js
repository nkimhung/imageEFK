function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiButton, EuiForm, EuiTitle, EuiSpacer, EuiPanel, EuiFlexGroup, EuiFlexItem, EuiStat, EuiBottomBar, EuiText, EuiHealth, EuiLoadingSpinner } from '@elastic/eui';
import React, { useState, useMemo } from 'react';
import { i18n } from '@kbn/i18n';
import { EuiButtonEmpty } from '@elastic/eui';
import { EuiCallOut } from '@elastic/eui';
import { FETCH_STATUS } from '../../../../../../hooks/useFetcher';
import { history } from '../../../../../../utils/history';
import { filterByAgent, settingDefinitions, validateSetting } from '../../../../../../../common/agent_configuration/setting_definitions';
import { saveConfig } from './saveConfig';
import { useApmPluginContext } from '../../../../../../hooks/useApmPluginContext';
import { useUiTracker } from '../../../../../../../../observability/public';
import { SettingFormRow } from './SettingFormRow';
import { getOptionLabel } from '../../../../../../../common/agent_configuration/all_option';

function removeEmpty(obj) {
  return Object.fromEntries(Object.entries(obj).filter(function (_ref) {
    var _ref2 = _slicedToArray(_ref, 2),
        _ = _ref2[0],
        v = _ref2[1];

    return v != null && v !== '';
  }));
}

export function SettingsPage(_ref3) {
  var status = _ref3.status,
      unsavedChanges = _ref3.unsavedChanges,
      newConfig = _ref3.newConfig,
      setNewConfig = _ref3.setNewConfig,
      resetSettings = _ref3.resetSettings,
      isEditMode = _ref3.isEditMode,
      onClickEdit = _ref3.onClickEdit;
  // get a telemetry UI event tracker
  var trackApmEvent = useUiTracker({
    app: 'apm'
  });
  var toasts = useApmPluginContext().core.notifications.toasts;

  var _useState = useState(false),
      _useState2 = _slicedToArray(_useState, 2),
      isSaving = _useState2[0],
      setIsSaving = _useState2[1];

  var unsavedChangesCount = Object.keys(unsavedChanges).length;
  var isLoading = status === FETCH_STATUS.LOADING;
  var isFormValid = useMemo(function () {
    return settingDefinitions // only validate settings that are not empty
    .filter(function (_ref4) {
      var key = _ref4.key;
      var value = newConfig.settings[key];
      return value != null && value !== '';
    }) // every setting must be valid for the form to be valid
    .every(function (def) {
      var value = newConfig.settings[def.key];
      return validateSetting(def, value).isValid;
    });
  }, [newConfig.settings]);

  var handleSubmitEvent = /*#__PURE__*/function () {
    var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
      var config;
      return regeneratorRuntime.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              trackApmEvent({
                metric: 'save_agent_configuration'
              });
              config = _objectSpread(_objectSpread({}, newConfig), {}, {
                settings: removeEmpty(newConfig.settings)
              });
              setIsSaving(true);
              _context.next = 5;
              return saveConfig({
                config: config,
                isEditMode: isEditMode,
                toasts: toasts
              });

            case 5:
              setIsSaving(false); // go back to overview

              history.push({
                pathname: '/settings/agent-configuration',
                search: history.location.search
              });

            case 7:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function handleSubmitEvent() {
      return _ref5.apply(this, arguments);
    };
  }();

  if (status === FETCH_STATUS.FAILURE) {
    return /*#__PURE__*/React.createElement(EuiCallOut, {
      title: i18n.translate('xpack.apm.agentConfig.settingsPage.notFound.title', {
        defaultMessage: 'Sorry, there was an error'
      }),
      color: "danger",
      iconType: "alert"
    }, /*#__PURE__*/React.createElement("p", null, i18n.translate('xpack.apm.agentConfig.settingsPage.notFound.message', {
      defaultMessage: 'The requested configuration does not exist'
    })));
  }

  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiForm, null, /*#__PURE__*/React.createElement("form", {
    onKeyPress: function onKeyPress(e) {
      var didClickEnter = e.which === 13;

      if (didClickEnter && isFormValid) {
        e.preventDefault();
        handleSubmitEvent();
      }
    }
  }, /*#__PURE__*/React.createElement(EuiPanel, {
    paddingSize: "m"
  }, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "s"
  }, /*#__PURE__*/React.createElement("h3", null, i18n.translate('xpack.apm.agentConfig.chooseService.title', {
    defaultMessage: 'Choose service'
  }))), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "m"
  }), /*#__PURE__*/React.createElement(EuiFlexGroup, null, /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(EuiStat, {
    titleSize: "xs",
    title: isLoading ? '-' : getOptionLabel(newConfig.service.name),
    description: i18n.translate('xpack.apm.agentConfig.chooseService.service.name.label', {
      defaultMessage: 'Service name'
    })
  })), /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(EuiStat, {
    titleSize: "xs",
    title: isLoading ? '-' : getOptionLabel(newConfig.service.environment),
    description: i18n.translate('xpack.apm.agentConfig.chooseService.service.environment.label', {
      defaultMessage: 'Environment'
    })
  })), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, !isEditMode && /*#__PURE__*/React.createElement(EuiButton, {
    onClick: onClickEdit,
    iconType: "pencil"
  }, i18n.translate('xpack.apm.agentConfig.chooseService.editButton', {
    defaultMessage: 'Edit'
  }))))), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "m"
  }), /*#__PURE__*/React.createElement(EuiPanel, {
    paddingSize: "m"
  }, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "s"
  }, /*#__PURE__*/React.createElement("h3", null, i18n.translate('xpack.apm.agentConfig.settings.title', {
    defaultMessage: 'Configuration options'
  }))), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "m"
  }), isLoading ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement(EuiLoadingSpinner, {
    size: "m"
  })) : renderSettings({
    unsavedChanges: unsavedChanges,
    newConfig: newConfig,
    setNewConfig: setNewConfig
  })))), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "xxl"
  }), unsavedChangesCount > 0 && /*#__PURE__*/React.createElement(EuiBottomBar, {
    paddingSize: "s"
  }, /*#__PURE__*/React.createElement(EuiFlexGroup, {
    justifyContent: "spaceBetween",
    alignItems: "center"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false,
    style: {
      flexDirection: 'row',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(EuiHealth, {
    color: "warning"
  }), /*#__PURE__*/React.createElement(EuiText, {
    color: "ghost"
  }, i18n.translate('xpack.apm.unsavedChanges', {
    defaultMessage: '{unsavedChangesCount, plural, =0{0 unsaved changes} one {1 unsaved change} other {# unsaved changes}} ',
    values: {
      unsavedChangesCount: unsavedChangesCount
    }
  }))), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiFlexGroup, {
    justifyContent: "flexEnd"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiButtonEmpty, {
    color: "ghost",
    onClick: resetSettings
  }, i18n.translate('xpack.apm.agentConfig.settingsPage.discardChangesButton', {
    defaultMessage: 'Discard changes'
  }))), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiButton, {
    onClick: handleSubmitEvent,
    fill: true,
    isLoading: isSaving,
    isDisabled: !isFormValid,
    color: "secondary",
    iconType: "check"
  }, i18n.translate('xpack.apm.agentConfig.settingsPage.saveButton', {
    defaultMessage: 'Save configuration'
  }))))))));
}

function renderSettings(_ref6) {
  var newConfig = _ref6.newConfig,
      unsavedChanges = _ref6.unsavedChanges,
      setNewConfig = _ref6.setNewConfig;
  return settingDefinitions // filter out agent specific items that are not applicable
  // to the selected service
  .filter(filterByAgent(newConfig.agent_name)).map(function (setting) {
    return /*#__PURE__*/React.createElement(SettingFormRow, {
      isUnsaved: unsavedChanges.hasOwnProperty(setting.key),
      key: setting.key,
      setting: setting,
      value: newConfig.settings[setting.key],
      onChange: function onChange(key, value) {
        setNewConfig(function (prev) {
          return _objectSpread(_objectSpread({}, prev), {}, {
            settings: _objectSpread(_objectSpread({}, prev.settings), {}, _defineProperty({}, key, value))
          });
        });
      }
    });
  });
}