/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { i18n } from '@kbn/i18n';
import { EuiTitle } from '@elastic/eui';
import { TransactionLineChart } from './TransactionLineChart';
import { getMaxY, getResponseTimeTickFormatter, getResponseTimeTooltipFormatter } from '.';
import { getDurationFormatter } from '../../../../utils/formatters';
import { useAvgDurationByBrowser } from '../../../../hooks/useAvgDurationByBrowser';
export function BrowserLineChart() {
  var _useAvgDurationByBrow = useAvgDurationByBrowser(),
      data = _useAvgDurationByBrow.data;

  var maxY = getMaxY(data);
  var formatter = getDurationFormatter(maxY);
  var formatTooltipValue = getResponseTimeTooltipFormatter(formatter);
  var tickFormatY = getResponseTimeTickFormatter(formatter);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xs"
  }, /*#__PURE__*/React.createElement("span", null, i18n.translate('xpack.apm.metrics.pageLoadCharts.avgPageLoadByBrowser', {
    defaultMessage: 'Avg. page load duration distribution by browser'
  }))), /*#__PURE__*/React.createElement(TransactionLineChart, {
    formatTooltipValue: formatTooltipValue,
    series: data,
    tickFormatY: tickFormatY
  }));
}