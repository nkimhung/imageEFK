function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiBadge, EuiToolTip } from '@elastic/eui';
import numeral from '@elastic/numeral';
import { i18n } from '@kbn/i18n';
import React, { useMemo } from 'react';
import styled from 'styled-components';
import { EuiIconTip } from '@elastic/eui';
import { NOT_AVAILABLE_LABEL } from '../../../../../common/i18n'; // eslint-disable-next-line @kbn/eslint/no-restricted-paths

import { fontFamilyCode, fontSizes, px, truncate, unit } from '../../../../style/variables';
import { useUrlParams } from '../../../../hooks/useUrlParams';
import { ManagedTable } from '../../../shared/ManagedTable';
import { ErrorDetailLink } from '../../../shared/Links/apm/ErrorDetailLink';
import { TimestampTooltip } from '../../../shared/TimestampTooltip';
import { ErrorOverviewLink } from '../../../shared/Links/apm/ErrorOverviewLink';
var GroupIdLink = styled(ErrorDetailLink).withConfig({
  displayName: "GroupIdLink",
  componentId: "sc-17t4sk2-0"
})(["font-family:", ";"], fontFamilyCode);
var MessageAndCulpritCell = styled.div.withConfig({
  displayName: "MessageAndCulpritCell",
  componentId: "sc-17t4sk2-1"
})(["", ";"], truncate('100%'));
var ErrorLink = styled(ErrorOverviewLink).withConfig({
  displayName: "ErrorLink",
  componentId: "sc-17t4sk2-2"
})(["", ";"], truncate('100%'));
var MessageLink = styled(ErrorDetailLink).withConfig({
  displayName: "MessageLink",
  componentId: "sc-17t4sk2-3"
})(["font-family:", ";font-size:", ";", ";"], fontFamilyCode, fontSizes.large, truncate('100%'));
var Culprit = styled.div.withConfig({
  displayName: "Culprit",
  componentId: "sc-17t4sk2-4"
})(["font-family:", ";"], fontFamilyCode);

var ErrorGroupList = function ErrorGroupList(props) {
  var items = props.items;

  var _useUrlParams = useUrlParams(),
      urlParams = _useUrlParams.urlParams;

  var serviceName = urlParams.serviceName;

  if (!serviceName) {
    throw new Error('Service name is required');
  }

  var columns = useMemo(function () {
    return [{
      name: /*#__PURE__*/React.createElement(React.Fragment, null, i18n.translate('xpack.apm.errorsTable.groupIdColumnLabel', {
        defaultMessage: 'Group ID'
      }), ' ', /*#__PURE__*/React.createElement(EuiIconTip, {
        size: "s",
        type: "questionInCircle",
        color: "subdued",
        iconProps: {
          className: 'eui-alignTop'
        },
        content: i18n.translate('xpack.apm.errorsTable.groupIdColumnDescription', {
          defaultMessage: 'Hash of the stack trace. Groups similar errors together, even when the error message is different due to dynamic parameters.'
        })
      })),
      field: 'groupId',
      sortable: false,
      width: px(unit * 6),
      render: function render(groupId) {
        return /*#__PURE__*/React.createElement(GroupIdLink, {
          serviceName: serviceName,
          errorGroupId: groupId
        }, groupId.slice(0, 5) || NOT_AVAILABLE_LABEL);
      }
    }, {
      name: i18n.translate('xpack.apm.errorsTable.typeColumnLabel', {
        defaultMessage: 'Type'
      }),
      field: 'type',
      sortable: false,
      render: function render(type) {
        return /*#__PURE__*/React.createElement(ErrorLink, {
          title: type,
          serviceName: serviceName,
          query: _objectSpread(_objectSpread({}, urlParams), {}, {
            kuery: "error.exception.type:".concat(type)
          })
        }, type);
      }
    }, {
      name: i18n.translate('xpack.apm.errorsTable.errorMessageAndCulpritColumnLabel', {
        defaultMessage: 'Error message and culprit'
      }),
      field: 'message',
      sortable: false,
      width: '50%',
      render: function render(message, item) {
        return /*#__PURE__*/React.createElement(MessageAndCulpritCell, null, /*#__PURE__*/React.createElement(EuiToolTip, {
          id: "error-message-tooltip",
          content: message || NOT_AVAILABLE_LABEL
        }, /*#__PURE__*/React.createElement(MessageLink, {
          serviceName: serviceName,
          errorGroupId: item.groupId
        }, message || NOT_AVAILABLE_LABEL)), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement(EuiToolTip, {
          id: "error-culprit-tooltip",
          content: item.culprit || NOT_AVAILABLE_LABEL
        }, /*#__PURE__*/React.createElement(Culprit, null, item.culprit || NOT_AVAILABLE_LABEL)));
      }
    }, {
      name: '',
      field: 'handled',
      sortable: false,
      align: 'right',
      render: function render(isUnhandled) {
        return isUnhandled === false && /*#__PURE__*/React.createElement(EuiBadge, {
          color: "warning"
        }, i18n.translate('xpack.apm.errorsTable.unhandledLabel', {
          defaultMessage: 'Unhandled'
        }));
      }
    }, {
      name: i18n.translate('xpack.apm.errorsTable.occurrencesColumnLabel', {
        defaultMessage: 'Occurrences'
      }),
      field: 'occurrenceCount',
      sortable: true,
      dataType: 'number',
      render: function render(value) {
        return value ? numeral(value).format('0.[0]a') : NOT_AVAILABLE_LABEL;
      }
    }, {
      field: 'latestOccurrenceAt',
      sortable: true,
      name: i18n.translate('xpack.apm.errorsTable.latestOccurrenceColumnLabel', {
        defaultMessage: 'Latest occurrence'
      }),
      align: 'right',
      render: function render(value) {
        return value ? /*#__PURE__*/React.createElement(TimestampTooltip, {
          time: value,
          timeUnit: "minutes"
        }) : NOT_AVAILABLE_LABEL;
      }
    }];
  }, [serviceName, urlParams]);
  return /*#__PURE__*/React.createElement(ManagedTable, {
    noItemsMessage: i18n.translate('xpack.apm.errorsTable.noErrorsLabel', {
      defaultMessage: 'No errors were found'
    }),
    items: items,
    columns: columns,
    initialPageSize: 25,
    initialSortField: "occurrenceCount",
    initialSortDirection: "desc",
    sortItems: false
  });
};

export { ErrorGroupList };