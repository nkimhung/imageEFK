/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiBadge } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React from 'react';
import styled from 'styled-components';
import { px, units } from '../../../../../../style/variables';
var SpanBadge = styled(EuiBadge).withConfig({
  displayName: "SpanBadge",
  componentId: "sc-15k5kqb-0"
})(["display:inline-block;margin-right:", ";"], px(units.quarter));
export function SyncBadge(_ref) {
  var sync = _ref.sync;

  switch (sync) {
    case true:
      return /*#__PURE__*/React.createElement(SpanBadge, null, i18n.translate('xpack.apm.transactionDetails.syncBadgeBlocking', {
        defaultMessage: 'blocking'
      }));

    case false:
      return /*#__PURE__*/React.createElement(SpanBadge, null, i18n.translate('xpack.apm.transactionDetails.syncBadgeAsync', {
        defaultMessage: 'async'
      }));

    default:
      return null;
  }
}