/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiFlexGroup, EuiFlexItem, EuiFlyoutBody, EuiFlyoutHeader, EuiPortal, EuiSpacer, EuiTitle, EuiHorizontalRule } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React from 'react';
import { TransactionActionMenu } from '../../../../../../shared/TransactionActionMenu/TransactionActionMenu';
import { TransactionSummary } from '../../../../../../shared/Summary/TransactionSummary';
import { FlyoutTopLevelProperties } from '../FlyoutTopLevelProperties';
import { ResponsiveFlyout } from '../ResponsiveFlyout';
import { TransactionMetadata } from '../../../../../../shared/MetadataTable/TransactionMetadata';
import { DroppedSpansWarning } from './DroppedSpansWarning';

function TransactionPropertiesTable(_ref) {
  var transaction = _ref.transaction;
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "s"
  }, /*#__PURE__*/React.createElement("h4", null, "Metadata")), /*#__PURE__*/React.createElement(TransactionMetadata, {
    transaction: transaction
  }));
}

export function TransactionFlyout(_ref2) {
  var transactionDoc = _ref2.transaction,
      onClose = _ref2.onClose,
      _ref2$errorCount = _ref2.errorCount,
      errorCount = _ref2$errorCount === void 0 ? 0 : _ref2$errorCount,
      rootTransactionDuration = _ref2.rootTransactionDuration;

  if (!transactionDoc) {
    return null;
  }

  return /*#__PURE__*/React.createElement(EuiPortal, null, /*#__PURE__*/React.createElement(ResponsiveFlyout, {
    onClose: onClose,
    ownFocus: true,
    maxWidth: false
  }, /*#__PURE__*/React.createElement(EuiFlyoutHeader, {
    hasBorder: true
  }, /*#__PURE__*/React.createElement(EuiFlexGroup, null, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiTitle, null, /*#__PURE__*/React.createElement("h4", null, i18n.translate('xpack.apm.transactionDetails.transFlyout.transactionDetailsTitle', {
    defaultMessage: 'Transaction details'
  })))), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(TransactionActionMenu, {
    transaction: transactionDoc
  })))), /*#__PURE__*/React.createElement(EuiFlyoutBody, null, /*#__PURE__*/React.createElement(FlyoutTopLevelProperties, {
    transaction: transactionDoc
  }), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "m"
  }), /*#__PURE__*/React.createElement(TransactionSummary, {
    transaction: transactionDoc,
    totalDuration: rootTransactionDuration,
    errorCount: errorCount
  }), /*#__PURE__*/React.createElement(EuiHorizontalRule, {
    margin: "m"
  }), /*#__PURE__*/React.createElement(DroppedSpansWarning, {
    transactionDoc: transactionDoc
  }), /*#__PURE__*/React.createElement(TransactionPropertiesTable, {
    transaction: transactionDoc
  }))));
}