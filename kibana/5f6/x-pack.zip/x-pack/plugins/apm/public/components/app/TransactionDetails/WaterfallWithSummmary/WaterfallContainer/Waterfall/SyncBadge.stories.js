/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { storiesOf } from '@storybook/react';
import React from 'react';
import { SyncBadge } from './SyncBadge';
storiesOf('app/TransactionDetails/SyncBadge', module).add('sync=true', function () {
  return /*#__PURE__*/React.createElement(SyncBadge, {
    sync: true
  });
}, {
  info: {
    source: false
  }
}).add('sync=false', function () {
  return /*#__PURE__*/React.createElement(SyncBadge, {
    sync: false
  });
}, {
  info: {
    source: false
  }
}).add('sync=undefined', function () {
  return /*#__PURE__*/React.createElement(SyncBadge, null);
}, {
  info: {
    source: false
  }
});