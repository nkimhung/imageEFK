/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { SpanFlyout } from './SpanFlyout';
import { TransactionFlyout } from './TransactionFlyout';
export var WaterfallFlyout = function WaterfallFlyout(_ref) {
  var _currentItem$parent, _currentItem$parent2, _waterfall$rootTransa;

  var waterfallItemId = _ref.waterfallItemId,
      waterfall = _ref.waterfall,
      location = _ref.location,
      toggleFlyout = _ref.toggleFlyout;
  var currentItem = waterfall.items.find(function (item) {
    return item.id === waterfallItemId;
  });

  if (!currentItem) {
    return null;
  }

  switch (currentItem.docType) {
    case 'span':
      var parentTransaction = ((_currentItem$parent = currentItem.parent) === null || _currentItem$parent === void 0 ? void 0 : _currentItem$parent.docType) === 'transaction' ? (_currentItem$parent2 = currentItem.parent) === null || _currentItem$parent2 === void 0 ? void 0 : _currentItem$parent2.doc : undefined;
      return /*#__PURE__*/React.createElement(SpanFlyout, {
        totalDuration: waterfall.duration,
        span: currentItem.doc,
        parentTransaction: parentTransaction,
        onClose: function onClose() {
          return toggleFlyout({
            location: location
          });
        }
      });

    case 'transaction':
      return /*#__PURE__*/React.createElement(TransactionFlyout, {
        transaction: currentItem.doc,
        onClose: function onClose() {
          return toggleFlyout({
            location: location
          });
        },
        rootTransactionDuration: (_waterfall$rootTransa = waterfall.rootTransaction) === null || _waterfall$rootTransa === void 0 ? void 0 : _waterfall$rootTransa.transaction.duration.us,
        errorCount: waterfall.errorsPerTransaction[currentItem.id]
      });

    default:
      return null;
  }
};