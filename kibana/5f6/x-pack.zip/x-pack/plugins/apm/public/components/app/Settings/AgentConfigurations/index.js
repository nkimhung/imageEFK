/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { i18n } from '@kbn/i18n';
import { EuiTitle, EuiFlexGroup, EuiFlexItem, EuiPanel, EuiSpacer, EuiButton } from '@elastic/eui';
import { isEmpty } from 'lodash';
import { useFetcher } from '../../../../hooks/useFetcher';
import { AgentConfigurationList } from './List';
import { useTrackPageview } from '../../../../../../observability/public';
import { createAgentConfigurationHref } from '../../../shared/Links/apm/agentConfigurationLinks';
export function AgentConfigurations() {
  var _useFetcher = useFetcher(function (callApmApi) {
    return callApmApi({
      pathname: '/api/apm/settings/agent-configuration'
    });
  }, [], {
    preservePreviousData: false,
    showToastOnError: false
  }),
      refetch = _useFetcher.refetch,
      _useFetcher$data = _useFetcher.data,
      data = _useFetcher$data === void 0 ? [] : _useFetcher$data,
      status = _useFetcher.status;

  useTrackPageview({
    app: 'apm',
    path: 'agent_configuration'
  });
  useTrackPageview({
    app: 'apm',
    path: 'agent_configuration',
    delay: 15000
  });
  var hasConfigurations = !isEmpty(data);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiPanel, null, /*#__PURE__*/React.createElement(EuiFlexGroup, {
    alignItems: "center"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiTitle, null, /*#__PURE__*/React.createElement("h2", null, i18n.translate('xpack.apm.agentConfig.configurationsPanelTitle', {
    defaultMessage: 'Agent remote configuration'
  })))), hasConfigurations ? /*#__PURE__*/React.createElement(CreateConfigurationButton, null) : null), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "m"
  }), /*#__PURE__*/React.createElement(AgentConfigurationList, {
    status: status,
    data: data,
    refetch: refetch
  })));
}

function CreateConfigurationButton() {
  var href = createAgentConfigurationHref();
  return /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(EuiFlexGroup, {
    alignItems: "center",
    justifyContent: "flexEnd"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiButton, {
    color: "primary",
    fill: true,
    iconType: "plusInCircle",
    href: href
  }, i18n.translate('xpack.apm.agentConfig.createConfigButtonLabel', {
    defaultMessage: 'Create configuration'
  })))));
}