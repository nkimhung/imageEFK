/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiFlexGroup, EuiFlexItem, EuiIconTip, EuiTitle } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React from 'react';
export var Title = function Title() {
  return /*#__PURE__*/React.createElement(EuiFlexGroup, {
    alignItems: "center"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "s"
  }, /*#__PURE__*/React.createElement(EuiFlexGroup, {
    alignItems: "center",
    gutterSize: "s",
    responsive: false
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement("h1", null, i18n.translate('xpack.apm.settings.customizeUI.customLink', {
    defaultMessage: 'Custom Links'
  }))), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiIconTip, {
    type: "iInCircle",
    position: "top",
    content: i18n.translate('xpack.apm.settings.customizeUI.customLink.info', {
      defaultMessage: 'These links will be shown in the Actions context menu for transactions.'
    })
  }))))));
};