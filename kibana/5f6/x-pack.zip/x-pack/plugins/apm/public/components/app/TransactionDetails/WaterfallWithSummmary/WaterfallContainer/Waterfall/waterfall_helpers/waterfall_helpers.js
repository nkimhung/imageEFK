function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import theme from '@elastic/eui/dist/eui_theme_light.json';
import { first, flatten, groupBy, isEmpty, sortBy, sum, uniq, zipObject } from 'lodash'; // eslint-disable-next-line @kbn/eslint/no-restricted-paths

var ROOT_ID = 'root';

function getTransactionItem(transaction) {
  var _transaction$parent;

  return {
    docType: 'transaction',
    doc: transaction,
    id: transaction.transaction.id,
    parentId: (_transaction$parent = transaction.parent) === null || _transaction$parent === void 0 ? void 0 : _transaction$parent.id,
    duration: transaction.transaction.duration.us,
    offset: 0,
    skew: 0
  };
}

function getSpanItem(span) {
  var _span$parent;

  return {
    docType: 'span',
    doc: span,
    id: span.span.id,
    parentId: (_span$parent = span.parent) === null || _span$parent === void 0 ? void 0 : _span$parent.id,
    duration: span.span.duration.us,
    offset: 0,
    skew: 0
  };
}

function getErrorItem(error, items, entryWaterfallTransaction) {
  var _entryWaterfallTransa;

  var entryTimestamp = (_entryWaterfallTransa = entryWaterfallTransaction === null || entryWaterfallTransaction === void 0 ? void 0 : entryWaterfallTransaction.doc.timestamp.us) !== null && _entryWaterfallTransa !== void 0 ? _entryWaterfallTransa : 0;
  var parent = items.find(function (waterfallItem) {
    var _error$parent;

    return waterfallItem.id === ((_error$parent = error.parent) === null || _error$parent === void 0 ? void 0 : _error$parent.id);
  });
  var errorItem = {
    docType: 'error',
    doc: error,
    id: error.error.id,
    parent: parent,
    parentId: parent === null || parent === void 0 ? void 0 : parent.id,
    offset: error.timestamp.us - entryTimestamp,
    skew: 0,
    duration: 0
  };
  return _objectSpread(_objectSpread({}, errorItem), {}, {
    skew: getClockSkew(errorItem, parent)
  });
}

export function getClockSkew(item, parentItem) {
  if (!parentItem) {
    return 0;
  }

  switch (item.docType) {
    // don't calculate skew for spans and errors. Just use parent's skew
    case 'error':
    case 'span':
      return parentItem.skew;
    // transaction is the inital entry in a service. Calculate skew for this, and it will be propogated to all child spans

    case 'transaction':
      {
        var parentStart = parentItem.doc.timestamp.us + parentItem.skew; // determine if child starts before the parent

        var offsetStart = parentStart - item.doc.timestamp.us;

        if (offsetStart > 0) {
          var latency = Math.max(parentItem.duration - item.duration, 0) / 2;
          return offsetStart + latency;
        } // child transaction starts after parent thus no adjustment is needed


        return 0;
      }
  }
}
export function getOrderedWaterfallItems(childrenByParentId, entryWaterfallTransaction) {
  if (!entryWaterfallTransaction) {
    return [];
  }

  var entryTimestamp = entryWaterfallTransaction.doc.timestamp.us;
  var visitedWaterfallItemSet = new Set();

  function getSortedChildren(item, parentItem) {
    if (visitedWaterfallItemSet.has(item)) {
      return [];
    }

    visitedWaterfallItemSet.add(item);
    var children = sortBy(childrenByParentId[item.id] || [], 'doc.timestamp.us');
    item.parent = parentItem; // get offset from the beginning of trace

    item.offset = item.doc.timestamp.us - entryTimestamp; // move the item to the right if it starts before its parent

    item.skew = getClockSkew(item, parentItem);
    var deepChildren = flatten(children.map(function (child) {
      return getSortedChildren(child, item);
    }));
    return [item].concat(_toConsumableArray(deepChildren));
  }

  return getSortedChildren(entryWaterfallTransaction);
}

function getRootTransaction(childrenByParentId) {
  var item = first(childrenByParentId.root);

  if (item && item.docType === 'transaction') {
    return item.doc;
  }
}

function getServiceColors(waterfallItems) {
  var services = uniq(waterfallItems.map(function (item) {
    return item.doc.service.name;
  }));
  var assignedColors = [theme.euiColorVis1, theme.euiColorVis0, theme.euiColorVis3, theme.euiColorVis2, theme.euiColorVis6, theme.euiColorVis7, theme.euiColorVis5];
  return zipObject(services, assignedColors);
}

var getWaterfallDuration = function getWaterfallDuration(waterfallItems) {
  return Math.max.apply(Math, _toConsumableArray(waterfallItems.map(function (item) {
    return item.offset + item.skew + item.duration;
  })).concat([0]));
};

var getWaterfallItems = function getWaterfallItems(items) {
  return items.map(function (item) {
    var docType = item.processor.event;

    switch (docType) {
      case 'span':
        return getSpanItem(item);

      case 'transaction':
        return getTransactionItem(item);
    }
  });
};

function reparentSpans(waterfallItems) {
  // find children that needs to be re-parented and map them to their correct parent id
  var childIdToParentIdMapping = Object.fromEntries(flatten(waterfallItems.map(function (waterfallItem) {
    if (waterfallItem.docType === 'span') {
      var _waterfallItem$doc$ch, _waterfallItem$doc$ch2;

      var childIds = (_waterfallItem$doc$ch = (_waterfallItem$doc$ch2 = waterfallItem.doc.child) === null || _waterfallItem$doc$ch2 === void 0 ? void 0 : _waterfallItem$doc$ch2.id) !== null && _waterfallItem$doc$ch !== void 0 ? _waterfallItem$doc$ch : [];
      return childIds.map(function (id) {
        return [id, waterfallItem.id];
      });
    }

    return [];
  }))); // update parent id for children that needs it or return unchanged

  return waterfallItems.map(function (waterfallItem) {
    var newParentId = childIdToParentIdMapping[waterfallItem.id];

    if (newParentId) {
      return _objectSpread(_objectSpread({}, waterfallItem), {}, {
        parentId: newParentId
      });
    }

    return waterfallItem;
  });
}

var getChildrenGroupedByParentId = function getChildrenGroupedByParentId(waterfallItems) {
  return groupBy(waterfallItems, function (item) {
    return item.parentId ? item.parentId : ROOT_ID;
  });
};

var getEntryWaterfallTransaction = function getEntryWaterfallTransaction(entryTransactionId, waterfallItems) {
  return waterfallItems.find(function (item) {
    return item.docType === 'transaction' && item.id === entryTransactionId;
  });
};

function isInEntryTransaction(parentIdLookup, entryTransactionId, currentId) {
  if (currentId === entryTransactionId) {
    return true;
  }

  var parentId = parentIdLookup.get(currentId);

  if (parentId) {
    return isInEntryTransaction(parentIdLookup, entryTransactionId, parentId);
  }

  return false;
}

function getWaterfallErrors(errorDocs, items, entryWaterfallTransaction) {
  var errorItems = errorDocs.map(function (errorDoc) {
    return getErrorItem(errorDoc, items, entryWaterfallTransaction);
  });

  if (!entryWaterfallTransaction) {
    return errorItems;
  }

  var parentIdLookup = [].concat(_toConsumableArray(items), _toConsumableArray(errorItems)).reduce(function (map, _ref) {
    var id = _ref.id,
        parentId = _ref.parentId;
    map.set(id, parentId !== null && parentId !== void 0 ? parentId : ROOT_ID);
    return map;
  }, new Map());
  return errorItems.filter(function (errorItem) {
    return isInEntryTransaction(parentIdLookup, entryWaterfallTransaction === null || entryWaterfallTransaction === void 0 ? void 0 : entryWaterfallTransaction.id, errorItem.id);
  });
}

export function getWaterfall(_ref2, entryTransactionId) {
  var trace = _ref2.trace,
      errorsPerTransaction = _ref2.errorsPerTransaction;

  if (isEmpty(trace.items) || !entryTransactionId) {
    return {
      duration: 0,
      items: [],
      errorsPerTransaction: errorsPerTransaction,
      errorsCount: sum(Object.values(errorsPerTransaction)),
      serviceColors: {},
      errorItems: []
    };
  }

  var waterfallItems = getWaterfallItems(trace.items);
  var childrenByParentId = getChildrenGroupedByParentId(reparentSpans(waterfallItems));
  var entryWaterfallTransaction = getEntryWaterfallTransaction(entryTransactionId, waterfallItems);
  var items = getOrderedWaterfallItems(childrenByParentId, entryWaterfallTransaction);
  var errorItems = getWaterfallErrors(trace.errorDocs, items, entryWaterfallTransaction);
  var rootTransaction = getRootTransaction(childrenByParentId);
  var duration = getWaterfallDuration(items);
  var serviceColors = getServiceColors(items);
  var entryTransaction = entryWaterfallTransaction === null || entryWaterfallTransaction === void 0 ? void 0 : entryWaterfallTransaction.doc;
  return {
    entryTransaction: entryTransaction,
    rootTransaction: rootTransaction,
    duration: duration,
    items: items,
    errorsPerTransaction: errorsPerTransaction,
    errorsCount: errorItems.length,
    serviceColors: serviceColors,
    errorItems: errorItems
  };
}