function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { i18n } from '@kbn/i18n';
import React from 'react';
import { Redirect } from 'react-router-dom';
import { SERVICE_NODE_NAME_MISSING } from '../../../../../common/service_nodes';
import { ErrorGroupDetails } from '../../ErrorGroupDetails';
import { ServiceDetails } from '../../ServiceDetails';
import { TransactionDetails } from '../../TransactionDetails';
import { Home } from '../../Home';
import { RouteName } from './route_names';
import { Settings } from '../../Settings';
import { AgentConfigurations } from '../../Settings/AgentConfigurations';
import { ApmIndices } from '../../Settings/ApmIndices';
import { toQuery } from '../../../shared/Links/url_helpers';
import { ServiceNodeMetrics } from '../../ServiceNodeMetrics';
import { resolveUrlParams } from '../../../../context/UrlParamsContext/resolveUrlParams';
import { UNIDENTIFIED_SERVICE_NODES_LABEL } from '../../../../../common/i18n';
import { TraceLink } from '../../TraceLink';
import { CustomizeUI } from '../../Settings/CustomizeUI';
import { AnomalyDetection } from '../../Settings/anomaly_detection';
import { EditAgentConfigurationRouteHandler, CreateAgentConfigurationRouteHandler } from './route_handlers/agent_configuration';
import { RumHome } from '../../RumDashboard/RumHome';
var metricsBreadcrumb = i18n.translate('xpack.apm.breadcrumb.metricsTitle', {
  defaultMessage: 'Metrics'
});

var renderAsRedirectTo = function renderAsRedirectTo(to) {
  return function (_ref) {
    var location = _ref.location;
    return /*#__PURE__*/React.createElement(Redirect, {
      to: _objectSpread(_objectSpread({}, location), {}, {
        pathname: to
      })
    });
  };
};

export var routes = [{
  exact: true,
  path: '/',
  render: renderAsRedirectTo('/services'),
  breadcrumb: 'APM',
  name: RouteName.HOME
}, {
  exact: true,
  path: '/services',
  component: function component() {
    return /*#__PURE__*/React.createElement(Home, {
      tab: "services"
    });
  },
  breadcrumb: i18n.translate('xpack.apm.breadcrumb.servicesTitle', {
    defaultMessage: 'Services'
  }),
  name: RouteName.SERVICES
}, {
  exact: true,
  path: '/traces',
  component: function component() {
    return /*#__PURE__*/React.createElement(Home, {
      tab: "traces"
    });
  },
  breadcrumb: i18n.translate('xpack.apm.breadcrumb.tracesTitle', {
    defaultMessage: 'Traces'
  }),
  name: RouteName.TRACES
}, {
  exact: true,
  path: '/settings',
  render: renderAsRedirectTo('/settings/agent-configuration'),
  breadcrumb: i18n.translate('xpack.apm.breadcrumb.listSettingsTitle', {
    defaultMessage: 'Settings'
  }),
  name: RouteName.SETTINGS
}, {
  exact: true,
  path: '/settings/apm-indices',
  component: function component() {
    return /*#__PURE__*/React.createElement(Settings, null, /*#__PURE__*/React.createElement(ApmIndices, null));
  },
  breadcrumb: i18n.translate('xpack.apm.breadcrumb.settings.indicesTitle', {
    defaultMessage: 'Indices'
  }),
  name: RouteName.INDICES
}, {
  exact: true,
  path: '/settings/agent-configuration',
  component: function component() {
    return /*#__PURE__*/React.createElement(Settings, null, /*#__PURE__*/React.createElement(AgentConfigurations, null));
  },
  breadcrumb: i18n.translate('xpack.apm.breadcrumb.settings.agentConfigurationTitle', {
    defaultMessage: 'Agent Configuration'
  }),
  name: RouteName.AGENT_CONFIGURATION
}, {
  exact: true,
  path: '/settings/agent-configuration/create',
  breadcrumb: i18n.translate('xpack.apm.breadcrumb.settings.createAgentConfigurationTitle', {
    defaultMessage: 'Create Agent Configuration'
  }),
  name: RouteName.AGENT_CONFIGURATION_CREATE,
  component: function component() {
    return /*#__PURE__*/React.createElement(CreateAgentConfigurationRouteHandler, null);
  }
}, {
  exact: true,
  path: '/settings/agent-configuration/edit',
  breadcrumb: i18n.translate('xpack.apm.breadcrumb.settings.editAgentConfigurationTitle', {
    defaultMessage: 'Edit Agent Configuration'
  }),
  name: RouteName.AGENT_CONFIGURATION_EDIT,
  component: function component() {
    return /*#__PURE__*/React.createElement(EditAgentConfigurationRouteHandler, null);
  }
}, {
  exact: true,
  path: '/services/:serviceName',
  breadcrumb: function breadcrumb(_ref2) {
    var match = _ref2.match;
    return match.params.serviceName;
  },
  render: function render(props) {
    return renderAsRedirectTo("/services/".concat(props.match.params.serviceName, "/transactions"))(props);
  },
  name: RouteName.SERVICE
}, // errors
{
  exact: true,
  path: '/services/:serviceName/errors/:groupId',
  component: ErrorGroupDetails,
  breadcrumb: function breadcrumb(_ref3) {
    var match = _ref3.match;
    return match.params.groupId;
  },
  name: RouteName.ERROR
}, {
  exact: true,
  path: '/services/:serviceName/errors',
  component: function component() {
    return /*#__PURE__*/React.createElement(ServiceDetails, {
      tab: "errors"
    });
  },
  breadcrumb: i18n.translate('xpack.apm.breadcrumb.errorsTitle', {
    defaultMessage: 'Errors'
  }),
  name: RouteName.ERRORS
}, // transactions
{
  exact: true,
  path: '/services/:serviceName/transactions',
  component: function component() {
    return /*#__PURE__*/React.createElement(ServiceDetails, {
      tab: "transactions"
    });
  },
  breadcrumb: i18n.translate('xpack.apm.breadcrumb.transactionsTitle', {
    defaultMessage: 'Transactions'
  }),
  name: RouteName.TRANSACTIONS
}, // metrics
{
  exact: true,
  path: '/services/:serviceName/metrics',
  component: function component() {
    return /*#__PURE__*/React.createElement(ServiceDetails, {
      tab: "metrics"
    });
  },
  breadcrumb: metricsBreadcrumb,
  name: RouteName.METRICS
}, // service nodes, only enabled for java agents for now
{
  exact: true,
  path: '/services/:serviceName/nodes',
  component: function component() {
    return /*#__PURE__*/React.createElement(ServiceDetails, {
      tab: "nodes"
    });
  },
  breadcrumb: i18n.translate('xpack.apm.breadcrumb.nodesTitle', {
    defaultMessage: 'JVMs'
  }),
  name: RouteName.SERVICE_NODES
}, // node metrics
{
  exact: true,
  path: '/services/:serviceName/nodes/:serviceNodeName/metrics',
  component: function component() {
    return /*#__PURE__*/React.createElement(ServiceNodeMetrics, null);
  },
  breadcrumb: function breadcrumb(_ref4) {
    var location = _ref4.location;

    var _resolveUrlParams = resolveUrlParams(location, {}),
        serviceNodeName = _resolveUrlParams.serviceNodeName;

    if (serviceNodeName === SERVICE_NODE_NAME_MISSING) {
      return UNIDENTIFIED_SERVICE_NODES_LABEL;
    }

    return serviceNodeName || '';
  },
  name: RouteName.SERVICE_NODE_METRICS
}, {
  exact: true,
  path: '/services/:serviceName/transactions/view',
  component: TransactionDetails,
  breadcrumb: function breadcrumb(_ref5) {
    var location = _ref5.location;
    var query = toQuery(location.search);
    return query.transactionName;
  },
  name: RouteName.TRANSACTION_NAME
}, {
  exact: true,
  path: '/link-to/trace/:traceId',
  component: TraceLink,
  breadcrumb: null,
  name: RouteName.LINK_TO_TRACE
}, {
  exact: true,
  path: '/service-map',
  component: function component() {
    return /*#__PURE__*/React.createElement(Home, {
      tab: "service-map"
    });
  },
  breadcrumb: i18n.translate('xpack.apm.breadcrumb.serviceMapTitle', {
    defaultMessage: 'Service Map'
  }),
  name: RouteName.SERVICE_MAP
}, {
  exact: true,
  path: '/services/:serviceName/service-map',
  component: function component() {
    return /*#__PURE__*/React.createElement(ServiceDetails, {
      tab: "service-map"
    });
  },
  breadcrumb: i18n.translate('xpack.apm.breadcrumb.serviceMapTitle', {
    defaultMessage: 'Service Map'
  }),
  name: RouteName.SINGLE_SERVICE_MAP
}, {
  exact: true,
  path: '/settings/customize-ui',
  component: function component() {
    return /*#__PURE__*/React.createElement(Settings, null, /*#__PURE__*/React.createElement(CustomizeUI, null));
  },
  breadcrumb: i18n.translate('xpack.apm.breadcrumb.settings.customizeUI', {
    defaultMessage: 'Customize UI'
  }),
  name: RouteName.CUSTOMIZE_UI
}, {
  exact: true,
  path: '/rum-preview',
  component: function component() {
    return /*#__PURE__*/React.createElement(RumHome, null);
  },
  breadcrumb: i18n.translate('xpack.apm.home.rumOverview.title', {
    defaultMessage: 'Real User Monitoring'
  }),
  name: RouteName.RUM_OVERVIEW
}, {
  exact: true,
  path: '/settings/anomaly-detection',
  component: function component() {
    return /*#__PURE__*/React.createElement(Settings, null, /*#__PURE__*/React.createElement(AnomalyDetection, null));
  },
  breadcrumb: i18n.translate('xpack.apm.breadcrumb.settings.anomalyDetection', {
    defaultMessage: 'Anomaly detection'
  }),
  name: RouteName.ANOMALY_DETECTION
}];