function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiSpacer, EuiTab, EuiTabs } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React from 'react';
import { fromQuery, toQuery } from '../../../shared/Links/url_helpers';
import { history } from '../../../../utils/history';
import { TransactionMetadata } from '../../../shared/MetadataTable/TransactionMetadata';
import { WaterfallContainer } from './WaterfallContainer';
var timelineTab = {
  key: 'timeline',
  label: i18n.translate('xpack.apm.propertiesTable.tabs.timelineLabel', {
    defaultMessage: 'Timeline'
  })
};
var metadataTab = {
  key: 'metadata',
  label: i18n.translate('xpack.apm.propertiesTable.tabs.metadataLabel', {
    defaultMessage: 'Metadata'
  })
};
export function TransactionTabs(_ref) {
  var location = _ref.location,
      transaction = _ref.transaction,
      urlParams = _ref.urlParams,
      waterfall = _ref.waterfall,
      exceedsMax = _ref.exceedsMax;
  var tabs = [timelineTab, metadataTab];
  var currentTab = urlParams.detailTab === metadataTab.key ? metadataTab : timelineTab;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiTabs, null, tabs.map(function (_ref2) {
    var key = _ref2.key,
        label = _ref2.label;
    return /*#__PURE__*/React.createElement(EuiTab, {
      onClick: function onClick() {
        history.replace(_objectSpread(_objectSpread({}, location), {}, {
          search: fromQuery(_objectSpread(_objectSpread({}, toQuery(location.search)), {}, {
            detailTab: key
          }))
        }));
      },
      isSelected: currentTab.key === key,
      key: key
    }, label);
  })), /*#__PURE__*/React.createElement(EuiSpacer, null), currentTab.key === timelineTab.key ? /*#__PURE__*/React.createElement(WaterfallContainer, {
    location: location,
    urlParams: urlParams,
    waterfall: waterfall,
    exceedsMax: exceedsMax
  }) : /*#__PURE__*/React.createElement(TransactionMetadata, {
    transaction: transaction
  }));
}