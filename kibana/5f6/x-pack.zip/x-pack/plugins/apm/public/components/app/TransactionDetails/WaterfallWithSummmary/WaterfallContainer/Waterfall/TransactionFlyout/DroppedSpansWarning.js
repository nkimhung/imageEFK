/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiCallOut, EuiHorizontalRule } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React from 'react';
import { ElasticDocsLink } from '../../../../../../shared/Links/ElasticDocsLink';
export function DroppedSpansWarning(_ref) {
  var _transactionDoc$trans;

  var transactionDoc = _ref.transactionDoc;
  var dropped = (_transactionDoc$trans = transactionDoc.transaction.span_count) === null || _transactionDoc$trans === void 0 ? void 0 : _transactionDoc$trans.dropped;

  if (!dropped) {
    return null;
  }

  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiCallOut, {
    size: "s"
  }, i18n.translate('xpack.apm.transactionDetails.transFlyout.callout.agentDroppedSpansMessage', {
    defaultMessage: 'The APM agent that reported this transaction dropped {dropped} spans or more based on its configuration.',
    values: {
      dropped: dropped
    }
  }), ' ', /*#__PURE__*/React.createElement(ElasticDocsLink, {
    section: "/apm/get-started",
    path: "/transaction-spans.html#dropped-spans",
    target: "_blank"
  }, i18n.translate('xpack.apm.transactionDetails.transFlyout.callout.learnMoreAboutDroppedSpansLinkText', {
    defaultMessage: 'Learn more about dropped spans.'
  }))), /*#__PURE__*/React.createElement(EuiHorizontalRule, null));
}