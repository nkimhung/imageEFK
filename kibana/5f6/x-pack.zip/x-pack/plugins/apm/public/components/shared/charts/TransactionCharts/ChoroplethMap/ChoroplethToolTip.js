/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { i18n } from '@kbn/i18n';
import { asDuration, asInteger } from '../../../../../utils/formatters';
import { fontSizes } from '../../../../../style/variables';
export var ChoroplethToolTip = function ChoroplethToolTip(_ref) {
  var name = _ref.name,
      value = _ref.value,
      docCount = _ref.docCount;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: fontSizes.large
    }
  }, name), /*#__PURE__*/React.createElement("div", null, i18n.translate('xpack.apm.metrics.durationByCountryMap.RegionMapChart.ToolTip.avgPageLoadDuration', {
    defaultMessage: 'Avg. page load duration:'
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 'bold',
      fontSize: fontSizes.large
    }
  }, asDuration(value)), /*#__PURE__*/React.createElement("div", null, "(", i18n.translate('xpack.apm.metrics.durationByCountryMap.RegionMapChart.ToolTip.countPageLoads', {
    values: {
      docCount: asInteger(docCount)
    },
    defaultMessage: '{docCount} page loads'
  }), ")"));
};