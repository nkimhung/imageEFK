/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiButtonEmpty, EuiFlexGroup, EuiFlexItem, EuiTabs, EuiTitle } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React from 'react';
import { useApmPluginContext } from '../../../hooks/useApmPluginContext';
import { ApmHeader } from '../../shared/ApmHeader';
import { EuiTabLink } from '../../shared/EuiTabLink';
import { ServiceMapLink } from '../../shared/Links/apm/ServiceMapLink';
import { ServiceOverviewLink } from '../../shared/Links/apm/ServiceOverviewLink';
import { SettingsLink } from '../../shared/Links/apm/SettingsLink';
import { AnomalyDetectionSetupLink } from '../../shared/Links/apm/AnomalyDetectionSetupLink';
import { TraceOverviewLink } from '../../shared/Links/apm/TraceOverviewLink';
import { SetupInstructionsLink } from '../../shared/Links/SetupInstructionsLink';
import { ServiceMap } from '../ServiceMap';
import { ServiceOverview } from '../ServiceOverview';
import { TraceOverview } from '../TraceOverview';

function getHomeTabs(_ref) {
  var _ref$serviceMapEnable = _ref.serviceMapEnabled,
      serviceMapEnabled = _ref$serviceMapEnable === void 0 ? true : _ref$serviceMapEnable;
  var homeTabs = [{
    link: /*#__PURE__*/React.createElement(ServiceOverviewLink, null, i18n.translate('xpack.apm.home.servicesTabLabel', {
      defaultMessage: 'Services'
    })),
    render: function render() {
      return /*#__PURE__*/React.createElement(ServiceOverview, null);
    },
    name: 'services'
  }, {
    link: /*#__PURE__*/React.createElement(TraceOverviewLink, null, i18n.translate('xpack.apm.home.tracesTabLabel', {
      defaultMessage: 'Traces'
    })),
    render: function render() {
      return /*#__PURE__*/React.createElement(TraceOverview, null);
    },
    name: 'traces'
  }];

  if (serviceMapEnabled) {
    homeTabs.push({
      link: /*#__PURE__*/React.createElement(ServiceMapLink, null, i18n.translate('xpack.apm.home.serviceMapTabLabel', {
        defaultMessage: 'Service Map'
      })),
      render: function render() {
        return /*#__PURE__*/React.createElement(ServiceMap, null);
      },
      name: 'service-map'
    });
  }

  return homeTabs;
}

var SETTINGS_LINK_LABEL = i18n.translate('xpack.apm.settingsLinkLabel', {
  defaultMessage: 'Settings'
});
export function Home(_ref2) {
  var _core$application$cap;

  var tab = _ref2.tab;

  var _useApmPluginContext = useApmPluginContext(),
      config = _useApmPluginContext.config,
      core = _useApmPluginContext.core;

  var canAccessML = !!((_core$application$cap = core.application.capabilities.ml) === null || _core$application$cap === void 0 ? void 0 : _core$application$cap.canAccessML);
  var homeTabs = getHomeTabs(config);
  var selectedTab = homeTabs.find(function (homeTab) {
    return homeTab.name === tab;
  });
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(ApmHeader, null, /*#__PURE__*/React.createElement(EuiFlexGroup, {
    alignItems: "center"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "l"
  }, /*#__PURE__*/React.createElement("h1", null, "APM"))), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(SettingsLink, null, /*#__PURE__*/React.createElement(EuiButtonEmpty, {
    size: "s",
    color: "primary",
    iconType: "gear"
  }, SETTINGS_LINK_LABEL))), canAccessML && /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(AnomalyDetectionSetupLink, null)), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(SetupInstructionsLink, null)))), /*#__PURE__*/React.createElement(EuiTabs, null, homeTabs.map(function (homeTab) {
    return /*#__PURE__*/React.createElement(EuiTabLink, {
      isSelected: homeTab === selectedTab,
      key: homeTab.name
    }, homeTab.link);
  })), selectedTab.render());
}