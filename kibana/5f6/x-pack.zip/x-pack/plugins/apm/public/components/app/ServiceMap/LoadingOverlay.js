/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { EuiProgress, EuiText, EuiSpacer } from '@elastic/eui';
import styled from 'styled-components';
import { i18n } from '@kbn/i18n';
var Container = styled.div.withConfig({
  displayName: "Container",
  componentId: "sc-7v04w-0"
})(["position:relative;"]);
var Overlay = styled.div.withConfig({
  displayName: "Overlay",
  componentId: "sc-7v04w-1"
})(["position:absolute;top:0;z-index:1;display:flex;flex-direction:column;align-items:center;width:100%;padding:", ";"], function (_ref) {
  var theme = _ref.theme;
  return theme.eui.gutterTypes.gutterMedium;
});
var ProgressBarContainer = styled.div.withConfig({
  displayName: "ProgressBarContainer",
  componentId: "sc-7v04w-2"
})(["width:50%;max-width:600px;"]);
export var LoadingOverlay = function LoadingOverlay(_ref2) {
  var isLoading = _ref2.isLoading,
      percentageLoaded = _ref2.percentageLoaded;
  return /*#__PURE__*/React.createElement(Container, null, isLoading && /*#__PURE__*/React.createElement(Overlay, null, /*#__PURE__*/React.createElement(ProgressBarContainer, null, /*#__PURE__*/React.createElement(EuiProgress, {
    value: percentageLoaded,
    max: 100,
    color: "primary",
    size: "m"
  })), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "s"
  }), /*#__PURE__*/React.createElement(EuiText, {
    size: "s",
    textAlign: "center"
  }, i18n.translate('xpack.apm.loadingServiceMap', {
    defaultMessage: 'Loading service map... This might take a short while.'
  }))));
};