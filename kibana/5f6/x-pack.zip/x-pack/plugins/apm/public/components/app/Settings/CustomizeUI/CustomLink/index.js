function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiPanel, EuiSpacer, EuiFlexGroup, EuiFlexItem } from '@elastic/eui';
import { isEmpty } from 'lodash';
import React, { useEffect, useState } from 'react';
import { i18n } from '@kbn/i18n';
import { useLicense } from '../../../../../hooks/useLicense';
import { useFetcher, FETCH_STATUS } from '../../../../../hooks/useFetcher';
import { CustomLinkFlyout } from './CustomLinkFlyout';
import { CustomLinkTable } from './CustomLinkTable';
import { EmptyPrompt } from './EmptyPrompt';
import { Title } from './Title';
import { CreateCustomLinkButton } from './CreateCustomLinkButton';
import { LicensePrompt } from '../../../../shared/LicensePrompt';
export var CustomLinkOverview = function CustomLinkOverview() {
  var license = useLicense();
  var hasValidLicense = (license === null || license === void 0 ? void 0 : license.isActive) && (license === null || license === void 0 ? void 0 : license.hasAtLeast('gold'));

  var _useState = useState(false),
      _useState2 = _slicedToArray(_useState, 2),
      isFlyoutOpen = _useState2[0],
      setIsFlyoutOpen = _useState2[1];

  var _useState3 = useState(),
      _useState4 = _slicedToArray(_useState3, 2),
      customLinkSelected = _useState4[0],
      setCustomLinkSelected = _useState4[1];

  var _useFetcher = useFetcher(function (callApmApi) {
    return callApmApi({
      pathname: '/api/apm/settings/custom_links'
    });
  }, []),
      customLinks = _useFetcher.data,
      status = _useFetcher.status,
      refetch = _useFetcher.refetch;

  useEffect(function () {
    if (customLinkSelected) {
      setIsFlyoutOpen(true);
    }
  }, [customLinkSelected]);

  var onCloseFlyout = function onCloseFlyout() {
    setCustomLinkSelected(undefined);
    setIsFlyoutOpen(false);
  };

  var onCreateCustomLinkClick = function onCreateCustomLinkClick() {
    setIsFlyoutOpen(true);
  };

  var showEmptyPrompt = status === FETCH_STATUS.SUCCESS && isEmpty(customLinks);
  return /*#__PURE__*/React.createElement(React.Fragment, null, isFlyoutOpen && /*#__PURE__*/React.createElement(CustomLinkFlyout, {
    onClose: onCloseFlyout,
    defaults: customLinkSelected,
    customLinkId: customLinkSelected === null || customLinkSelected === void 0 ? void 0 : customLinkSelected.id,
    onSave: function onSave() {
      onCloseFlyout();
      refetch();
    },
    onDelete: function onDelete() {
      onCloseFlyout();
      refetch();
    }
  }), /*#__PURE__*/React.createElement(EuiPanel, null, /*#__PURE__*/React.createElement(EuiFlexGroup, {
    alignItems: "center"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(Title, null)), hasValidLicense && !showEmptyPrompt && /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(EuiFlexGroup, {
    alignItems: "center",
    justifyContent: "flexEnd"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(CreateCustomLinkButton, {
    onClick: onCreateCustomLinkClick
  }))))), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "m"
  }), hasValidLicense ? showEmptyPrompt ? /*#__PURE__*/React.createElement(EmptyPrompt, {
    onCreateCustomLinkClick: onCreateCustomLinkClick
  }) : /*#__PURE__*/React.createElement(CustomLinkTable, {
    items: customLinks,
    onCustomLinkSelected: setCustomLinkSelected
  }) : /*#__PURE__*/React.createElement(LicensePrompt, {
    text: i18n.translate('xpack.apm.settings.customizeUI.customLink.license.text', {
      defaultMessage: "To create custom links, you must be subscribed to an Elastic Gold license or above. With it, you'll have the ability to create custom links to improve your workflow when analyzing your services."
    })
  })));
};