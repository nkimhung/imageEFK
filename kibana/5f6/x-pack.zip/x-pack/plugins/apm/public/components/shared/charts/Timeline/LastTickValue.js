/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
export function LastTickValue(_ref) {
  var x = _ref.x,
      marginTop = _ref.marginTop,
      value = _ref.value;
  return /*#__PURE__*/React.createElement("g", {
    transform: "translate(".concat(x, ", ").concat(marginTop, ")")
  }, /*#__PURE__*/React.createElement("text", {
    textAnchor: "middle",
    dy: "0",
    transform: "translate(0, -8)"
  }, value));
}
LastTickValue.requiresSVG = true;