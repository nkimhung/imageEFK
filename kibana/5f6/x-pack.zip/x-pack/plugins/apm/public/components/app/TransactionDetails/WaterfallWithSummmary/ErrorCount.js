/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiText, EuiTextColor } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React from 'react';
export var ErrorCount = function ErrorCount(_ref) {
  var count = _ref.count;
  return /*#__PURE__*/React.createElement(EuiText, {
    size: "xs"
  }, /*#__PURE__*/React.createElement("h4", null, /*#__PURE__*/React.createElement(EuiTextColor, {
    color: "danger",
    onClick: function onClick(e) {
      e.stopPropagation();
    }
  }, i18n.translate('xpack.apm.transactionDetails.errorCount', {
    defaultMessage: '{errorCount, number} {errorCount, plural, one {Error} other {Errors}}',
    values: {
      errorCount: count
    }
  }))));
};