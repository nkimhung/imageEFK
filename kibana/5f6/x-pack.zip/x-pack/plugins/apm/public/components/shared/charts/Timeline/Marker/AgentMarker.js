/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { EuiToolTip } from '@elastic/eui';
import styled from 'styled-components';
import { useTheme } from '../../../../../hooks/useTheme';
import { px, units } from '../../../../../style/variables';
import { asDuration } from '../../../../../utils/formatters';
import { Legend } from '../../Legend';
var NameContainer = styled.div.withConfig({
  displayName: "NameContainer",
  componentId: "sc-1km8i9m-0"
})(["border-bottom:1px solid ", ";padding-bottom:", ";"], function (_ref) {
  var theme = _ref.theme;
  return theme.eui.euiColorMediumShade;
}, px(units.half));
var TimeContainer = styled.div.withConfig({
  displayName: "TimeContainer",
  componentId: "sc-1km8i9m-1"
})(["color:", ";padding-top:", ";"], function (_ref2) {
  var theme = _ref2.theme;
  return theme.eui.euiColorMediumShade;
}, px(units.half));
export var AgentMarker = function AgentMarker(_ref3) {
  var mark = _ref3.mark;
  var theme = useTheme();
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiToolTip, {
    id: mark.id,
    position: "top",
    content: /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(NameContainer, null, mark.id), /*#__PURE__*/React.createElement(TimeContainer, null, asDuration(mark.offset)))
  }, /*#__PURE__*/React.createElement(Legend, {
    clickable: true,
    color: theme.eui.euiColorMediumShade
  })));
};