function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React, { createContext, useEffect, useRef, useState } from 'react';
import cytoscape from 'cytoscape';
import { debounce } from 'lodash';
import { useTheme } from '../../../hooks/useTheme';
import { getAnimationOptions, getCytoscapeOptions, getNodeHeight } from './cytoscapeOptions';
import { useUiTracker } from '../../../../../observability/public';
export var CytoscapeContext = createContext(undefined);

function useCytoscape(options) {
  var _useState = useState(undefined),
      _useState2 = _slicedToArray(_useState, 2),
      cy = _useState2[0],
      setCy = _useState2[1];

  var ref = useRef(null);
  useEffect(function () {
    if (!cy) {
      setCy(cytoscape(_objectSpread(_objectSpread({}, options), {}, {
        container: ref.current
      })));
    }
  }, [options, cy]); // Destroy the cytoscape instance on unmount

  useEffect(function () {
    return function () {
      if (cy) {
        cy.destroy();
      }
    };
  }, [cy]);
  return [ref, cy];
}

function rotatePoint(_ref, degreesRotated) {
  var x = _ref.x,
      y = _ref.y;
  var radiansPerDegree = Math.PI / 180;
  var θ = radiansPerDegree * degreesRotated;
  var cosθ = Math.cos(θ);
  var sinθ = Math.sin(θ);
  return {
    x: x * cosθ - y * sinθ,
    y: x * sinθ + y * cosθ
  };
}

function getLayoutOptions(selectedRoots, height, width, nodeHeight) {
  return {
    name: 'breadthfirst',
    // @ts-ignore DefinitelyTyped is incorrect here. Roots can be an Array
    roots: selectedRoots.length ? selectedRoots : undefined,
    fit: true,
    padding: nodeHeight,
    spacingFactor: 1.2,
    // @ts-ignore
    // Rotate nodes counter-clockwise to transform layout from top→bottom to left→right.
    // The extra 5° achieves the effect of separating overlapping taxi-styled edges.
    transform: function transform(node, pos) {
      return rotatePoint(pos, -95);
    },
    // swap width/height of boundingBox to compensate for the rotation
    boundingBox: {
      x1: 0,
      y1: 0,
      w: height,
      h: width
    }
  };
}

function selectRoots(cy) {
  var bfs = cy.elements().bfs({
    roots: cy.elements().leaves()
  });
  var furthestNodeFromLeaves = bfs.path.last();
  return cy.elements().roots().union(furthestNodeFromLeaves).map(function (el) {
    return el.id();
  });
}

export function Cytoscape(_ref2) {
  var children = _ref2.children,
      elements = _ref2.elements,
      height = _ref2.height,
      width = _ref2.width,
      serviceName = _ref2.serviceName,
      style = _ref2.style;
  var theme = useTheme();

  var _useCytoscape = useCytoscape(_objectSpread(_objectSpread({}, getCytoscapeOptions(theme)), {}, {
    elements: elements
  })),
      _useCytoscape2 = _slicedToArray(_useCytoscape, 2),
      ref = _useCytoscape2[0],
      cy = _useCytoscape2[1];

  var nodeHeight = getNodeHeight(theme); // Add the height to the div style. The height is a separate prop because it
  // is required and can trigger rendering when changed.

  var divStyle = _objectSpread(_objectSpread({}, style), {}, {
    height: height
  });

  var trackApmEvent = useUiTracker({
    app: 'apm'
  }); // Set up cytoscape event handlers

  useEffect(function () {
    var resetConnectedEdgeStyle = function resetConnectedEdgeStyle(node) {
      if (cy) {
        cy.edges().removeClass('highlight');

        if (node) {
          node.connectedEdges().addClass('highlight');
        }
      }
    };

    var dataHandler = function dataHandler(event) {
      if (cy && cy.elements().length > 0) {
        if (serviceName) {
          resetConnectedEdgeStyle(cy.getElementById(serviceName)); // Add the "primary" class to the node if its id matches the serviceName.

          if (cy.nodes().length > 0) {
            cy.nodes().removeClass('primary');
            cy.getElementById(serviceName).addClass('primary');
          }
        } else {
          resetConnectedEdgeStyle();
        }

        var selectedRoots = selectRoots(event.cy);
        var layout = cy.layout(getLayoutOptions(selectedRoots, height, width, nodeHeight));
        layout.run();
      }
    };

    var layoutstopDelayTimeout;

    var layoutstopHandler = function layoutstopHandler(event) {
      // This 0ms timer is necessary to prevent a race condition
      // between the layout finishing rendering and viewport centering
      layoutstopDelayTimeout = setTimeout(function () {
        if (serviceName) {
          event.cy.animate(_objectSpread(_objectSpread({}, getAnimationOptions(theme)), {}, {
            fit: {
              eles: event.cy.elements(),
              padding: nodeHeight
            },
            center: {
              eles: event.cy.getElementById(serviceName)
            }
          }));
        } else {
          event.cy.fit(undefined, nodeHeight);
        }
      }, 0);
    }; // debounce hover tracking so it doesn't spam telemetry with redundant events


    var trackNodeEdgeHover = debounce(function () {
      return trackApmEvent({
        metric: 'service_map_node_or_edge_hover'
      });
    }, 1000);

    var mouseoverHandler = function mouseoverHandler(event) {
      trackNodeEdgeHover();
      event.target.addClass('hover');
      event.target.connectedEdges().addClass('nodeHover');
    };

    var mouseoutHandler = function mouseoutHandler(event) {
      event.target.removeClass('hover');
      event.target.connectedEdges().removeClass('nodeHover');
    };

    var selectHandler = function selectHandler(event) {
      trackApmEvent({
        metric: 'service_map_node_select'
      });
      resetConnectedEdgeStyle(event.target);
    };

    var unselectHandler = function unselectHandler(event) {
      resetConnectedEdgeStyle(serviceName ? event.cy.getElementById(serviceName) : undefined);
    };

    var debugHandler = function debugHandler(event) {
      var debugEnabled = sessionStorage.getItem('apm_debug') === 'true';

      if (debugEnabled) {
        // eslint-disable-next-line no-console
        console.debug('cytoscape:', event);
      }
    };

    if (cy) {
      cy.on('data layoutstop select unselect', debugHandler);
      cy.on('data', dataHandler);
      cy.on('layoutstop', layoutstopHandler);
      cy.on('mouseover', 'edge, node', mouseoverHandler);
      cy.on('mouseout', 'edge, node', mouseoutHandler);
      cy.on('select', 'node', selectHandler);
      cy.on('unselect', 'node', unselectHandler);
      cy.remove(cy.elements());
      cy.add(elements);
      cy.trigger('data');
    }

    return function () {
      if (cy) {
        cy.removeListener('data layoutstop select unselect', undefined, debugHandler);
        cy.removeListener('data', undefined, dataHandler);
        cy.removeListener('layoutstop', undefined, layoutstopHandler);
        cy.removeListener('mouseover', 'edge, node', mouseoverHandler);
        cy.removeListener('mouseout', 'edge, node', mouseoutHandler);
        cy.removeListener('select', 'node', selectHandler);
        cy.removeListener('unselect', 'node', unselectHandler);
      }

      clearTimeout(layoutstopDelayTimeout);
    };
  }, [cy, elements, height, serviceName, trackApmEvent, width, nodeHeight, theme]);
  return /*#__PURE__*/React.createElement(CytoscapeContext.Provider, {
    value: cy
  }, /*#__PURE__*/React.createElement("div", {
    ref: ref,
    style: divStyle
  }, children));
}