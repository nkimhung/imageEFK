/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { EuiLoadingSpinner, EuiFlexGroup, EuiHorizontalRule, EuiText } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import { isNumber } from 'lodash';
import { ServiceStatsList } from './ServiceStatsList';
import { useFetcher, FETCH_STATUS } from '../../../../hooks/useFetcher';
import { useUrlParams } from '../../../../hooks/useUrlParams';
import { AnomalyDetection } from './AnomalyDetection';
export function ServiceStatsFetcher(_ref) {
  var serviceName = _ref.serviceName,
      serviceAnomalyStats = _ref.serviceAnomalyStats;

  var _useUrlParams = useUrlParams(),
      _useUrlParams$urlPara = _useUrlParams.urlParams,
      start = _useUrlParams$urlPara.start,
      end = _useUrlParams$urlPara.end,
      uiFilters = _useUrlParams.uiFilters;

  var _useFetcher = useFetcher(function (callApmApi) {
    if (serviceName && start && end) {
      return callApmApi({
        pathname: '/api/apm/service-map/service/{serviceName}',
        params: {
          path: {
            serviceName: serviceName
          },
          query: {
            start: start,
            end: end,
            uiFilters: JSON.stringify(uiFilters)
          }
        }
      });
    }
  }, [serviceName, start, end, uiFilters], {
    preservePreviousData: false
  }),
      _useFetcher$data = _useFetcher.data,
      data = _useFetcher$data === void 0 ? {
    transactionStats: {}
  } : _useFetcher$data,
      status = _useFetcher.status;

  var isLoading = status === FETCH_STATUS.PENDING || status === FETCH_STATUS.LOADING;

  if (isLoading) {
    return /*#__PURE__*/React.createElement(LoadingSpinner, null);
  }

  var avgCpuUsage = data.avgCpuUsage,
      avgErrorRate = data.avgErrorRate,
      avgMemoryUsage = data.avgMemoryUsage,
      _data$transactionStat = data.transactionStats,
      avgRequestsPerMinute = _data$transactionStat.avgRequestsPerMinute,
      avgTransactionDuration = _data$transactionStat.avgTransactionDuration;
  var hasServiceData = [avgCpuUsage, avgErrorRate, avgMemoryUsage, avgRequestsPerMinute, avgTransactionDuration].some(function (stat) {
    return isNumber(stat);
  });

  if (!hasServiceData) {
    return /*#__PURE__*/React.createElement(EuiText, {
      color: "subdued"
    }, i18n.translate('xpack.apm.serviceMap.popoverMetrics.noDataText', {
      defaultMessage: "No data for selected environment. Try switching to another environment."
    }));
  }

  return /*#__PURE__*/React.createElement(React.Fragment, null, serviceAnomalyStats && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(AnomalyDetection, {
    serviceName: serviceName,
    serviceAnomalyStats: serviceAnomalyStats
  }), /*#__PURE__*/React.createElement(EuiHorizontalRule, {
    margin: "xs"
  })), /*#__PURE__*/React.createElement(ServiceStatsList, data));
}

function LoadingSpinner() {
  return /*#__PURE__*/React.createElement(EuiFlexGroup, {
    alignItems: "center",
    justifyContent: "spaceAround",
    style: {
      height: 170
    }
  }, /*#__PURE__*/React.createElement(EuiLoadingSpinner, {
    size: "xl"
  }));
}