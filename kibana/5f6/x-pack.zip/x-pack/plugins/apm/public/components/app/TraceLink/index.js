/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiEmptyPrompt } from '@elastic/eui';
import React from 'react';
import { Redirect } from 'react-router-dom';
import styled from 'styled-components';
import url from 'url';
import { TRACE_ID } from '../../../../common/elasticsearch_fieldnames';
import { FETCH_STATUS, useFetcher } from '../../../hooks/useFetcher';
import { useUrlParams } from '../../../hooks/useUrlParams';
var CentralizedContainer = styled.div.withConfig({
  displayName: "CentralizedContainer",
  componentId: "rkv897-0"
})(["height:100%;display:flex;"]);

var redirectToTransactionDetailPage = function redirectToTransactionDetailPage(_ref) {
  var transaction = _ref.transaction,
      rangeFrom = _ref.rangeFrom,
      rangeTo = _ref.rangeTo;
  return url.format({
    pathname: "/services/".concat(transaction.service.name, "/transactions/view"),
    query: {
      traceId: transaction.trace.id,
      transactionId: transaction.transaction.id,
      transactionName: transaction.transaction.name,
      transactionType: transaction.transaction.type,
      rangeFrom: rangeFrom,
      rangeTo: rangeTo
    }
  });
};

var redirectToTracePage = function redirectToTracePage(_ref2) {
  var traceId = _ref2.traceId,
      rangeFrom = _ref2.rangeFrom,
      rangeTo = _ref2.rangeTo;
  return url.format({
    pathname: "/traces",
    query: {
      kuery: encodeURIComponent("".concat(TRACE_ID, " : \"").concat(traceId, "\"")),
      rangeFrom: rangeFrom,
      rangeTo: rangeTo
    }
  });
};

export var TraceLink = function TraceLink() {
  var _useUrlParams = useUrlParams(),
      urlParams = _useUrlParams.urlParams;

  var traceId = urlParams.traceIdLink,
      rangeFrom = urlParams.rangeFrom,
      rangeTo = urlParams.rangeTo;

  var _useFetcher = useFetcher(function (callApmApi) {
    if (traceId) {
      return callApmApi({
        pathname: '/api/apm/transaction/{traceId}',
        params: {
          path: {
            traceId: traceId
          }
        }
      });
    }
  }, [traceId]),
      _useFetcher$data = _useFetcher.data,
      data = _useFetcher$data === void 0 ? {
    transaction: null
  } : _useFetcher$data,
      status = _useFetcher.status;

  if (traceId && status === FETCH_STATUS.SUCCESS) {
    var to = data.transaction ? redirectToTransactionDetailPage({
      transaction: data.transaction,
      rangeFrom: rangeFrom,
      rangeTo: rangeTo
    }) : redirectToTracePage({
      traceId: traceId,
      rangeFrom: rangeFrom,
      rangeTo: rangeTo
    });
    return /*#__PURE__*/React.createElement(Redirect, {
      to: to
    });
  }

  return /*#__PURE__*/React.createElement(CentralizedContainer, null, /*#__PURE__*/React.createElement(EuiEmptyPrompt, {
    iconType: "apmTrace",
    title: /*#__PURE__*/React.createElement("h2", null, "Fetching trace...")
  }));
};