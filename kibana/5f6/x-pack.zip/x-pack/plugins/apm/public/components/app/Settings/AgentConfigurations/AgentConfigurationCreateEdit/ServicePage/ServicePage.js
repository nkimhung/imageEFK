function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiTitle, EuiSpacer, EuiPanel, EuiFlexGroup, EuiFlexItem, EuiButton } from '@elastic/eui';
import React from 'react';
import { i18n } from '@kbn/i18n';
import { isString } from 'lodash';
import { EuiButtonEmpty } from '@elastic/eui';
import { omitAllOption, getOptionLabel } from '../../../../../../../common/agent_configuration/all_option';
import { useFetcher, FETCH_STATUS } from '../../../../../../hooks/useFetcher';
import { FormRowSelect } from './FormRowSelect';
import { APMLink } from '../../../../../shared/Links/apm/APMLink';
export function ServicePage(_ref) {
  var newConfig = _ref.newConfig,
      setNewConfig = _ref.setNewConfig,
      onClickNext = _ref.onClickNext;

  var _useFetcher = useFetcher(function (callApmApi) {
    return callApmApi({
      pathname: '/api/apm/settings/agent-configuration/services',
      isCachable: true
    });
  }, [], {
    preservePreviousData: false
  }),
      _useFetcher$data = _useFetcher.data,
      serviceNames = _useFetcher$data === void 0 ? [] : _useFetcher$data,
      serviceNamesStatus = _useFetcher.status;

  var _useFetcher2 = useFetcher(function (callApmApi) {
    if (newConfig.service.name) {
      return callApmApi({
        pathname: '/api/apm/settings/agent-configuration/environments',
        params: {
          query: {
            serviceName: omitAllOption(newConfig.service.name)
          }
        }
      });
    }
  }, [newConfig.service.name], {
    preservePreviousData: false
  }),
      _useFetcher2$data = _useFetcher2.data,
      environments = _useFetcher2$data === void 0 ? [] : _useFetcher2$data,
      environmentStatus = _useFetcher2.status;

  var _useFetcher3 = useFetcher( /*#__PURE__*/function () {
    var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(callApmApi) {
      var serviceName, _yield$callApmApi, agentName;

      return regeneratorRuntime.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              serviceName = newConfig.service.name;

              if (!(!isString(serviceName) || serviceName.length === 0)) {
                _context.next = 3;
                break;
              }

              return _context.abrupt("return");

            case 3:
              _context.next = 5;
              return callApmApi({
                pathname: '/api/apm/settings/agent-configuration/agent_name',
                params: {
                  query: {
                    serviceName: serviceName
                  }
                }
              });

            case 5:
              _yield$callApmApi = _context.sent;
              agentName = _yield$callApmApi.agentName;
              setNewConfig(function (prev) {
                return _objectSpread(_objectSpread({}, prev), {}, {
                  agent_name: agentName
                });
              });

            case 8:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function (_x) {
      return _ref2.apply(this, arguments);
    };
  }(), [newConfig.service.name, setNewConfig]),
      agentNameStatus = _useFetcher3.status;

  var ALREADY_CONFIGURED_TRANSLATED = i18n.translate('xpack.apm.agentConfig.servicePage.alreadyConfiguredOption', {
    defaultMessage: 'already configured'
  });
  var serviceNameOptions = serviceNames.map(function (name) {
    return {
      text: getOptionLabel(name),
      value: name
    };
  });
  var environmentOptions = environments.map(function (_ref3) {
    var name = _ref3.name,
        alreadyConfigured = _ref3.alreadyConfigured;
    return {
      disabled: alreadyConfigured,
      text: "".concat(getOptionLabel(name), " ").concat(alreadyConfigured ? "(".concat(ALREADY_CONFIGURED_TRANSLATED, ")") : ''),
      value: name
    };
  });
  return /*#__PURE__*/React.createElement(EuiPanel, {
    paddingSize: "m"
  }, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xs"
  }, /*#__PURE__*/React.createElement("h3", null, i18n.translate('xpack.apm.agentConfig.servicePage.title', {
    defaultMessage: 'Choose service'
  }))), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "m"
  }), /*#__PURE__*/React.createElement(FormRowSelect, {
    title: i18n.translate('xpack.apm.agentConfig.servicePage.service.title', {
      defaultMessage: 'Service'
    }),
    description: i18n.translate('xpack.apm.agentConfig.servicePage.service.description', {
      defaultMessage: 'Choose the service you want to configure.'
    }),
    fieldLabel: i18n.translate('xpack.apm.agentConfig.servicePage.service.fieldLabel', {
      defaultMessage: 'Service name'
    }),
    isLoading: serviceNamesStatus === FETCH_STATUS.LOADING,
    options: serviceNameOptions,
    value: newConfig.service.name,
    disabled: serviceNamesStatus === FETCH_STATUS.LOADING,
    onChange: function onChange(e) {
      e.preventDefault();
      var name = e.target.value;
      setNewConfig(function (prev) {
        return _objectSpread(_objectSpread({}, prev), {}, {
          service: {
            name: name,
            environment: ''
          }
        });
      });
    }
  }), /*#__PURE__*/React.createElement(FormRowSelect, {
    title: i18n.translate('xpack.apm.agentConfig.servicePage.environment.title', {
      defaultMessage: 'Environment'
    }),
    description: i18n.translate('xpack.apm.agentConfig.servicePage.environment.description', {
      defaultMessage: 'Only a single environment per configuration is supported.'
    }),
    fieldLabel: i18n.translate('xpack.apm.agentConfig.servicePage.environment.fieldLabel', {
      defaultMessage: 'Service environment'
    }),
    isLoading: environmentStatus === FETCH_STATUS.LOADING,
    options: environmentOptions,
    value: newConfig.service.environment,
    disabled: !newConfig.service.name || environmentStatus === FETCH_STATUS.LOADING,
    onChange: function onChange(e) {
      e.preventDefault();
      var environment = e.target.value;
      setNewConfig(function (prev) {
        return _objectSpread(_objectSpread({}, prev), {}, {
          service: {
            name: prev.service.name,
            environment: environment
          }
        });
      });
    }
  }), /*#__PURE__*/React.createElement(EuiSpacer, null), /*#__PURE__*/React.createElement(EuiFlexGroup, {
    justifyContent: "flexEnd"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(APMLink, {
    path: "/settings/agent-configuration"
  }, /*#__PURE__*/React.createElement(EuiButtonEmpty, {
    color: "primary"
  }, i18n.translate('xpack.apm.agentConfig.servicePage.cancelButton', {
    defaultMessage: 'Cancel'
  })))), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiButton, {
    type: "submit",
    fill: true,
    onClick: onClickNext,
    isLoading: agentNameStatus === FETCH_STATUS.LOADING,
    isDisabled: !newConfig.service.name || !newConfig.service.environment || agentNameStatus === FETCH_STATUS.LOADING
  }, i18n.translate('xpack.apm.agentConfig.saveConfigurationButtonLabel', {
    defaultMessage: 'Next step'
  })))));
}