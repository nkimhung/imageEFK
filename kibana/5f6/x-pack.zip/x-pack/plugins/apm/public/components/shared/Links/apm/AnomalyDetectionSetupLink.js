/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { EuiButtonEmpty, EuiToolTip, EuiIcon } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import { useApmPluginContext } from '../../../../hooks/useApmPluginContext';
import { APMLink } from './APMLink';
import { getEnvironmentLabel } from '../../../../../common/environment_filter_values';
import { useUrlParams } from '../../../../hooks/useUrlParams';
import { useFetcher, FETCH_STATUS } from '../../../../hooks/useFetcher';
import { useLicense } from '../../../../hooks/useLicense';
var DEFAULT_DATA = {
  jobs: [],
  hasLegacyJobs: false
};
export function AnomalyDetectionSetupLink() {
  var _plugin$core$applicat;

  var _useUrlParams = useUrlParams(),
      uiFilters = _useUrlParams.uiFilters;

  var environment = uiFilters.environment;
  var plugin = useApmPluginContext();
  var canGetJobs = !!((_plugin$core$applicat = plugin.core.application.capabilities.ml) === null || _plugin$core$applicat === void 0 ? void 0 : _plugin$core$applicat.canGetJobs);
  var license = useLicense();
  var hasValidLicense = (license === null || license === void 0 ? void 0 : license.isActive) && (license === null || license === void 0 ? void 0 : license.hasAtLeast('platinum'));
  return /*#__PURE__*/React.createElement(APMLink, {
    path: "/settings/anomaly-detection",
    style: {
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement(EuiButtonEmpty, {
    size: "s",
    color: "primary",
    iconType: "inspect"
  }, ANOMALY_DETECTION_LINK_LABEL), canGetJobs && hasValidLicense ? /*#__PURE__*/React.createElement(MissingJobsAlert, {
    environment: environment
  }) : null);
}
export function MissingJobsAlert(_ref) {
  var environment = _ref.environment;

  var _useFetcher = useFetcher(function (callApmApi) {
    return callApmApi({
      pathname: "/api/apm/settings/anomaly-detection"
    });
  }, [], {
    preservePreviousData: false,
    showToastOnError: false
  }),
      _useFetcher$data = _useFetcher.data,
      data = _useFetcher$data === void 0 ? DEFAULT_DATA : _useFetcher$data,
      status = _useFetcher.status;

  if (status !== FETCH_STATUS.SUCCESS) {
    return null;
  }

  var isEnvironmentSelected = !!environment; // there are jobs for at least one environment

  if (!isEnvironmentSelected && data.jobs.length > 0) {
    return null;
  } // there are jobs for the selected environment


  if (isEnvironmentSelected && data.jobs.some(function (job) {
    return environment === job.environment;
  })) {
    return null;
  }

  return /*#__PURE__*/React.createElement(EuiToolTip, {
    position: "bottom",
    content: getTooltipText(environment)
  }, /*#__PURE__*/React.createElement(EuiIcon, {
    type: "alert",
    color: "danger"
  }));
}

function getTooltipText(environment) {
  if (!environment) {
    return i18n.translate('xpack.apm.anomalyDetectionSetup.notEnabledText', {
      defaultMessage: "Anomaly detection is not yet enabled. Click to continue setup."
    });
  }

  return i18n.translate('xpack.apm.anomalyDetectionSetup.notEnabledForEnvironmentText', {
    defaultMessage: "Anomaly detection is not yet enabled for the environment \"{currentEnvironment}\". Click to continue setup.",
    values: {
      currentEnvironment: getEnvironmentLabel(environment)
    }
  });
}

var ANOMALY_DETECTION_LINK_LABEL = i18n.translate('xpack.apm.anomalyDetectionSetup.linkLabel', {
  defaultMessage: "Anomaly detection"
});