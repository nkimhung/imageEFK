/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { AlertAdd } from '../../../../../../../triggers_actions_ui/public';
export function AlertingFlyout(props) {
  var addFlyoutVisible = props.addFlyoutVisible,
      setAddFlyoutVisibility = props.setAddFlyoutVisibility,
      alertType = props.alertType;
  return alertType && /*#__PURE__*/React.createElement(AlertAdd, {
    addFlyoutVisible: addFlyoutVisible,
    setAddFlyoutVisibility: setAddFlyoutVisibility,
    consumer: "apm",
    alertTypeId: alertType,
    canChangeTrigger: false
  });
}