function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */

/* eslint-disable @elastic/eui/href-or-on-click */
import { EuiButton, EuiFlexItem } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React from 'react';
import { useUrlParams } from '../../../../hooks/useUrlParams';
import { getAPMHref } from '../../../shared/Links/apm/APMLink';
export function Buttons(_ref) {
  var _ref$onFocusClick = _ref.onFocusClick,
      onFocusClick = _ref$onFocusClick === void 0 ? function () {} : _ref$onFocusClick,
      selectedNodeServiceName = _ref.selectedNodeServiceName;

  // The params may contain the service name. We want to use the selected node's
  // service name in the button URLs, so make a copy and set the
  // `serviceName` property.
  var urlParams = _objectSpread({}, useUrlParams().urlParams);

  urlParams.serviceName = selectedNodeServiceName;
  var detailsUrl = getAPMHref("/services/".concat(selectedNodeServiceName, "/transactions"), '', urlParams);
  var focusUrl = getAPMHref("/services/".concat(selectedNodeServiceName, "/service-map"), '', urlParams);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(EuiButton, {
    href: detailsUrl,
    fill: true
  }, i18n.translate('xpack.apm.serviceMap.serviceDetailsButtonText', {
    defaultMessage: 'Service Details'
  }))), /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(EuiButton, {
    color: "secondary",
    href: focusUrl,
    onClick: onFocusClick
  }, i18n.translate('xpack.apm.serviceMap.focusMapButtonText', {
    defaultMessage: 'Focus map'
  }))));
}