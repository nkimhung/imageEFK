/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { i18n } from '@kbn/i18n';
import { EuiBadge, EuiToolTip } from '@elastic/eui';
export var EnvironmentBadge = function EnvironmentBadge(_ref) {
  var _ref$environments = _ref.environments,
      environments = _ref$environments === void 0 ? [] : _ref$environments;

  if (environments.length < 3) {
    return /*#__PURE__*/React.createElement(React.Fragment, null, environments.map(function (env) {
      return /*#__PURE__*/React.createElement(EuiBadge, {
        color: "hollow",
        key: env
      }, env);
    }));
  }

  return /*#__PURE__*/React.createElement(EuiToolTip, {
    position: "right",
    content: environments.map(function (env) {
      return /*#__PURE__*/React.createElement(React.Fragment, {
        key: env
      }, env, /*#__PURE__*/React.createElement("br", null));
    })
  }, /*#__PURE__*/React.createElement(EuiBadge, null, i18n.translate('xpack.apm.servicesTable.environmentCount', {
    values: {
      environmentCount: environments.length
    },
    defaultMessage: '{environmentCount, plural, one {1 environment} other {# environments}}'
  })));
};