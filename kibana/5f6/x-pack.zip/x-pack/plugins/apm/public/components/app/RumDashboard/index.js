function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React, { useMemo } from 'react';
import { EuiFlexGroup, EuiFlexItem, EuiHorizontalRule, EuiSpacer } from '@elastic/eui';
import { useTrackPageview } from '../../../../../observability/public';
import { LocalUIFilters } from '../../shared/LocalUIFilters';
import { PROJECTION } from '../../../../common/projections/typings';
import { RumDashboard } from './RumDashboard';
import { ServiceNameFilter } from '../../shared/LocalUIFilters/ServiceNameFilter';
import { useUrlParams } from '../../../hooks/useUrlParams';
import { useFetcher } from '../../../hooks/useFetcher';
import { RUM_AGENTS } from '../../../../common/agent_name';
import { EnvironmentFilter } from '../../shared/EnvironmentFilter';
export function RumOverview() {
  useTrackPageview({
    app: 'apm',
    path: 'rum_overview'
  });
  useTrackPageview({
    app: 'apm',
    path: 'rum_overview',
    delay: 15000
  });
  var localUIFiltersConfig = useMemo(function () {
    var config = {
      filterNames: ['transactionUrl', 'location', 'device', 'os', 'browser'],
      projection: PROJECTION.RUM_OVERVIEW
    };
    return config;
  }, []);

  var _useUrlParams = useUrlParams(),
      _useUrlParams$urlPara = _useUrlParams.urlParams,
      start = _useUrlParams$urlPara.start,
      end = _useUrlParams$urlPara.end;

  var _useFetcher = useFetcher(function (callApmApi) {
    if (start && end) {
      return callApmApi({
        pathname: '/api/apm/rum-client/services',
        params: {
          query: {
            start: start,
            end: end,
            uiFilters: JSON.stringify({
              agentName: RUM_AGENTS
            })
          }
        }
      });
    }
  }, [start, end]),
      data = _useFetcher.data,
      status = _useFetcher.status;

  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiSpacer, null), /*#__PURE__*/React.createElement(EuiFlexGroup, null, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: 1
  }, /*#__PURE__*/React.createElement(EnvironmentFilter, null), /*#__PURE__*/React.createElement(EuiSpacer, null), /*#__PURE__*/React.createElement(LocalUIFilters, _extends({}, localUIFiltersConfig, {
    showCount: true
  }), /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(ServiceNameFilter, {
    loading: status !== 'success',
    serviceNames: data !== null && data !== void 0 ? data : []
  }), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "xl"
  }), /*#__PURE__*/React.createElement(EuiHorizontalRule, {
    margin: "none"
  }), ' '))), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: 7
  }, /*#__PURE__*/React.createElement(RumDashboard, null))));
}