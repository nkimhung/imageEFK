/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { EuiFlexGroup, EuiFlexItem, EuiTitle } from '@elastic/eui';
import { VisitorBreakdownChart } from '../Charts/VisitorBreakdownChart';
import { VisitorBreakdownLabel } from '../translations';
import { useFetcher } from '../../../../hooks/useFetcher';
import { useUrlParams } from '../../../../hooks/useUrlParams';
export var VisitorBreakdown = function VisitorBreakdown() {
  var _useUrlParams = useUrlParams(),
      urlParams = _useUrlParams.urlParams,
      uiFilters = _useUrlParams.uiFilters;

  var start = urlParams.start,
      end = urlParams.end,
      serviceName = urlParams.serviceName;

  var _useFetcher = useFetcher(function (callApmApi) {
    if (start && end && serviceName) {
      return callApmApi({
        pathname: '/api/apm/rum-client/visitor-breakdown',
        params: {
          query: {
            start: start,
            end: end,
            uiFilters: JSON.stringify(uiFilters)
          }
        }
      });
    }

    return Promise.resolve(null);
  }, [end, start, serviceName, uiFilters]),
      data = _useFetcher.data;

  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xs"
  }, /*#__PURE__*/React.createElement("h3", null, VisitorBreakdownLabel)), /*#__PURE__*/React.createElement(EuiFlexGroup, null, /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(VisitorBreakdownChart, {
    options: data === null || data === void 0 ? void 0 : data.browsers
  }), /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xs",
    className: "eui-textCenter"
  }, /*#__PURE__*/React.createElement("h4", null, "Browser"))), /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(VisitorBreakdownChart, {
    options: data === null || data === void 0 ? void 0 : data.os
  }), /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xs",
    className: "eui-textCenter"
  }, /*#__PURE__*/React.createElement("h4", null, "Operating System"))), /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(VisitorBreakdownChart, {
    options: data === null || data === void 0 ? void 0 : data.devices
  }), /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xs",
    className: "eui-textCenter"
  }, /*#__PURE__*/React.createElement("h4", null, "Device")))));
};