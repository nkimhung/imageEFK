function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React, { useState } from 'react';
import { EuiPopover, EuiText } from '@elastic/eui';
import styled from 'styled-components';
import { useTheme } from '../../../../../hooks/useTheme';
import { TRACE_ID, TRANSACTION_ID } from '../../../../../../common/elasticsearch_fieldnames';
import { useUrlParams } from '../../../../../hooks/useUrlParams';
import { px, unit, units } from '../../../../../style/variables';
import { asDuration } from '../../../../../utils/formatters';
import { ErrorDetailLink } from '../../../Links/apm/ErrorDetailLink';
import { Legend, Shape } from '../../Legend';
var Popover = styled.div.withConfig({
  displayName: "Popover",
  componentId: "sc-1yadst3-0"
})(["max-width:", ";"], px(280));
var TimeLegend = styled(Legend).withConfig({
  displayName: "TimeLegend",
  componentId: "sc-1yadst3-1"
})(["margin-bottom:", ";"], px(unit));
var ErrorLink = styled(ErrorDetailLink).withConfig({
  displayName: "ErrorLink",
  componentId: "sc-1yadst3-2"
})(["display:block;margin:", " 0 ", " 0;overflow-wrap:break-word;"], px(units.half), px(units.half));
var Button = styled(Legend).withConfig({
  displayName: "Button",
  componentId: "sc-1yadst3-3"
})(["height:20px;display:flex;align-items:flex-end;"]); // We chose 240 characters because it fits most error messages and it's still easily readable on a screen.

function truncateMessage(errorMessage) {
  var maxLength = 240;

  if (typeof errorMessage === 'string' && errorMessage.length > maxLength) {
    return errorMessage.substring(0, maxLength) + '…';
  } else {
    return errorMessage;
  }
}

export var ErrorMarker = function ErrorMarker(_ref) {
  var _error$trace, _error$trace2, _error$transaction, _error$transaction2, _error$error$log, _error$error$exceptio, _error$error$exceptio2;

  var mark = _ref.mark;
  var theme = useTheme();

  var _useUrlParams = useUrlParams(),
      urlParams = _useUrlParams.urlParams;

  var _useState = useState(false),
      _useState2 = _slicedToArray(_useState, 2),
      isPopoverOpen = _useState2[0],
      showPopover = _useState2[1];

  var togglePopover = function togglePopover() {
    return showPopover(!isPopoverOpen);
  };

  var button = /*#__PURE__*/React.createElement(Button, {
    "data-test-subj": "popover",
    clickable: true,
    color: theme.eui.euiColorDanger,
    shape: Shape.square,
    onClick: togglePopover
  });
  var error = mark.error;
  var rangeTo = urlParams.rangeTo,
      rangeFrom = urlParams.rangeFrom;
  var query = {
    kuery: [].concat(_toConsumableArray(((_error$trace = error.trace) === null || _error$trace === void 0 ? void 0 : _error$trace.id) ? ["".concat(TRACE_ID, " : \"").concat((_error$trace2 = error.trace) === null || _error$trace2 === void 0 ? void 0 : _error$trace2.id, "\"")] : []), _toConsumableArray(((_error$transaction = error.transaction) === null || _error$transaction === void 0 ? void 0 : _error$transaction.id) ? ["".concat(TRANSACTION_ID, " : \"").concat((_error$transaction2 = error.transaction) === null || _error$transaction2 === void 0 ? void 0 : _error$transaction2.id, "\"")] : [])).join(' and '),
    rangeFrom: rangeFrom,
    rangeTo: rangeTo
  };
  var errorMessage = ((_error$error$log = error.error.log) === null || _error$error$log === void 0 ? void 0 : _error$error$log.message) || ((_error$error$exceptio = error.error.exception) === null || _error$error$exceptio === void 0 ? void 0 : (_error$error$exceptio2 = _error$error$exceptio[0]) === null || _error$error$exceptio2 === void 0 ? void 0 : _error$error$exceptio2.message);
  var truncatedErrorMessage = truncateMessage(errorMessage);
  return /*#__PURE__*/React.createElement(EuiPopover, {
    id: "popover",
    button: button,
    isOpen: isPopoverOpen,
    closePopover: togglePopover,
    anchorPosition: "upCenter"
  }, /*#__PURE__*/React.createElement(Popover, null, /*#__PURE__*/React.createElement(TimeLegend, {
    text: asDuration(mark.offset),
    indicator: function indicator() {
      return /*#__PURE__*/React.createElement("div", {
        style: {
          marginRight: px(units.quarter)
        }
      }, "@");
    }
  }), /*#__PURE__*/React.createElement(Legend, {
    key: mark.serviceColor,
    color: mark.serviceColor,
    text: error.service.name
  }), /*#__PURE__*/React.createElement(EuiText, {
    size: "s"
  }, /*#__PURE__*/React.createElement(ErrorLink, {
    "data-test-subj": "errorLink",
    serviceName: error.service.name,
    errorGroupId: error.error.grouping_key,
    query: query,
    title: errorMessage
  }, truncatedErrorMessage))));
};