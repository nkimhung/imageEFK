function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { Chart, DARK_THEME, LIGHT_THEME, Partition, PartitionLayout, Settings } from '@elastic/charts';
import euiLightVars from '@elastic/eui/dist/eui_theme_light.json';
import { EUI_CHARTS_THEME_DARK, EUI_CHARTS_THEME_LIGHT } from '@elastic/eui/dist/eui_charts_theme';
import { useUiSetting$ } from '../../../../../../../../src/plugins/kibana_react/public';
import { ChartWrapper } from '../ChartWrapper';
export var VisitorBreakdownChart = function VisitorBreakdownChart(_ref) {
  var options = _ref.options;

  var _useUiSetting$ = useUiSetting$('theme:darkMode'),
      _useUiSetting$2 = _slicedToArray(_useUiSetting$, 1),
      darkMode = _useUiSetting$2[0];

  return /*#__PURE__*/React.createElement(ChartWrapper, {
    loading: false,
    height: "220px"
  }, /*#__PURE__*/React.createElement(Chart, null, /*#__PURE__*/React.createElement(Settings, {
    baseTheme: darkMode ? DARK_THEME : LIGHT_THEME,
    theme: darkMode ? EUI_CHARTS_THEME_DARK.theme : EUI_CHARTS_THEME_LIGHT.theme
  }), /*#__PURE__*/React.createElement(Partition, {
    id: "spec_1",
    data: options || [],
    valueAccessor: function valueAccessor(d) {
      return d.count;
    },
    valueGetter: "percent",
    percentFormatter: function percentFormatter(d) {
      return "".concat(Math.round((d + Number.EPSILON) * 100) / 100, "%");
    },
    layers: [{
      groupByRollup: function groupByRollup(d) {
        return d.name;
      },
      nodeLabel: function nodeLabel(d) {
        return d;
      },
      // fillLabel: { textInvertible: true },
      shape: {
        fillColor: function fillColor(d) {
          var clrs = [euiLightVars.euiColorVis1_behindText, euiLightVars.euiColorVis0_behindText, euiLightVars.euiColorVis2_behindText, euiLightVars.euiColorVis3_behindText, euiLightVars.euiColorVis4_behindText, euiLightVars.euiColorVis5_behindText, euiLightVars.euiColorVis6_behindText, euiLightVars.euiColorVis7_behindText, euiLightVars.euiColorVis8_behindText, euiLightVars.euiColorVis9_behindText];
          return clrs[d.sortIndex];
        }
      }
    }],
    config: {
      partitionLayout: PartitionLayout.sunburst,
      linkLabel: {
        maxCount: 32,
        fontSize: 14
      },
      fontFamily: 'Arial',
      margin: {
        top: 0,
        bottom: 0,
        left: 0,
        right: 0
      },
      minFontSize: 1,
      idealFontSizeJump: 1.1,
      outerSizeRatio: 0.9,
      // - 0.5 * Math.random(),
      emptySizeRatio: 0,
      circlePadding: 4
    }
  })));
};