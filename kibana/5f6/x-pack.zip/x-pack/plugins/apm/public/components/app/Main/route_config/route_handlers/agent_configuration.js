/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { useFetcher } from '../../../../../hooks/useFetcher';
import { history } from '../../../../../utils/history';
import { Settings } from '../../../Settings';
import { AgentConfigurationCreateEdit } from '../../../Settings/AgentConfigurations/AgentConfigurationCreateEdit';
import { toQuery } from '../../../../shared/Links/url_helpers';
export function EditAgentConfigurationRouteHandler() {
  var search = history.location.search; // typescript complains because `pageStop` does not exist in `APMQueryParams`
  // Going forward we should move away from globally declared query params and this is a first step
  // @ts-ignore

  var _toQuery = toQuery(search),
      name = _toQuery.name,
      environment = _toQuery.environment,
      pageStep = _toQuery.pageStep;

  var res = useFetcher(function (callApmApi) {
    return callApmApi({
      pathname: '/api/apm/settings/agent-configuration/view',
      params: {
        query: {
          name: name,
          environment: environment
        }
      }
    });
  }, [name, environment]);
  return /*#__PURE__*/React.createElement(Settings, null, /*#__PURE__*/React.createElement(AgentConfigurationCreateEdit, {
    pageStep: pageStep || 'choose-settings-step',
    existingConfigResult: res
  }));
}
export function CreateAgentConfigurationRouteHandler() {
  var search = history.location.search; // Ignoring here because we specifically DO NOT want to add the query params to the global route handler
  // @ts-ignore

  var _toQuery2 = toQuery(search),
      pageStep = _toQuery2.pageStep;

  return /*#__PURE__*/React.createElement(Settings, null, /*#__PURE__*/React.createElement(AgentConfigurationCreateEdit, {
    pageStep: pageStep || 'choose-service-step'
  }));
}