/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { i18n } from '@kbn/i18n';
import { isNumber } from 'lodash';
import React from 'react';
import styled from 'styled-components';
import { asDuration, asPercent, tpmUnit } from '../../../../utils/formatters';
export var ItemRow = styled('tr').withConfig({
  displayName: "ItemRow",
  componentId: "eeecwl-0"
})(["line-height:2;"]);
export var ItemTitle = styled('td').withConfig({
  displayName: "ItemTitle",
  componentId: "eeecwl-1"
})(["color:", ";padding-right:1rem;"], function (_ref) {
  var theme = _ref.theme;
  return theme.eui.textColors.subdued;
});
export var ItemDescription = styled('td').withConfig({
  displayName: "ItemDescription",
  componentId: "eeecwl-2"
})(["text-align:right;"]);
export function ServiceStatsList(_ref2) {
  var transactionStats = _ref2.transactionStats,
      avgErrorRate = _ref2.avgErrorRate,
      avgCpuUsage = _ref2.avgCpuUsage,
      avgMemoryUsage = _ref2.avgMemoryUsage;
  var listItems = [{
    title: i18n.translate('xpack.apm.serviceMap.avgTransDurationPopoverStat', {
      defaultMessage: 'Trans. duration (avg.)'
    }),
    description: isNumber(transactionStats.avgTransactionDuration) ? asDuration(transactionStats.avgTransactionDuration) : null
  }, {
    title: i18n.translate('xpack.apm.serviceMap.avgReqPerMinutePopoverMetric', {
      defaultMessage: 'Req. per minute (avg.)'
    }),
    description: isNumber(transactionStats.avgRequestsPerMinute) ? "".concat(transactionStats.avgRequestsPerMinute.toFixed(2), " ").concat(tpmUnit('request')) : null
  }, {
    title: i18n.translate('xpack.apm.serviceMap.errorRatePopoverStat', {
      defaultMessage: 'Trans. error rate (avg.)'
    }),
    description: isNumber(avgErrorRate) ? asPercent(avgErrorRate, 1) : null
  }, {
    title: i18n.translate('xpack.apm.serviceMap.avgCpuUsagePopoverStat', {
      defaultMessage: 'CPU usage (avg.)'
    }),
    description: isNumber(avgCpuUsage) ? asPercent(avgCpuUsage, 1) : null
  }, {
    title: i18n.translate('xpack.apm.serviceMap.avgMemoryUsagePopoverStat', {
      defaultMessage: 'Memory usage (avg.)'
    }),
    description: isNumber(avgMemoryUsage) ? asPercent(avgMemoryUsage, 1) : null
  }];
  return /*#__PURE__*/React.createElement("table", null, /*#__PURE__*/React.createElement("tbody", null, listItems.map(function (_ref3) {
    var title = _ref3.title,
        description = _ref3.description;
    return description && /*#__PURE__*/React.createElement(ItemRow, {
      key: title
    }, /*#__PURE__*/React.createElement(ItemTitle, null, title), /*#__PURE__*/React.createElement(ItemDescription, null, description));
  })));
}