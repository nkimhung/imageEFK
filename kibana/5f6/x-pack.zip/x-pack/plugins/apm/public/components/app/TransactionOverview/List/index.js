/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiToolTip, EuiIconTip } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React, { useMemo } from 'react';
import styled from 'styled-components';
import { NOT_AVAILABLE_LABEL } from '../../../../../common/i18n'; // eslint-disable-next-line @kbn/eslint/no-restricted-paths

import { fontFamilyCode, truncate } from '../../../../style/variables';
import { asDecimal, asMillisecondDuration } from '../../../../utils/formatters';
import { ImpactBar } from '../../../shared/ImpactBar';
import { ManagedTable } from '../../../shared/ManagedTable';
import { LoadingStatePrompt } from '../../../shared/LoadingStatePrompt';
import { EmptyMessage } from '../../../shared/EmptyMessage';
import { TransactionDetailLink } from '../../../shared/Links/apm/TransactionDetailLink';
var TransactionNameLink = styled(TransactionDetailLink).withConfig({
  displayName: "TransactionNameLink",
  componentId: "sc-1f4vhh5-0"
})(["", ";font-family:", ";"], truncate('100%'), fontFamilyCode);
export function TransactionList(_ref) {
  var items = _ref.items,
      isLoading = _ref.isLoading;
  var columns = useMemo(function () {
    return [{
      field: 'name',
      name: i18n.translate('xpack.apm.transactionsTable.nameColumnLabel', {
        defaultMessage: 'Name'
      }),
      width: '50%',
      sortable: true,
      render: function render(transactionName, _ref2) {
        var sample = _ref2.sample;
        return /*#__PURE__*/React.createElement(EuiToolTip, {
          id: "transaction-name-link-tooltip",
          content: transactionName || NOT_AVAILABLE_LABEL
        }, /*#__PURE__*/React.createElement(TransactionNameLink, {
          serviceName: sample.service.name,
          transactionId: sample.transaction.id,
          traceId: sample.trace.id,
          transactionName: sample.transaction.name,
          transactionType: sample.transaction.type
        }, transactionName || NOT_AVAILABLE_LABEL));
      }
    }, {
      field: 'averageResponseTime',
      name: i18n.translate('xpack.apm.transactionsTable.avgDurationColumnLabel', {
        defaultMessage: 'Avg. duration'
      }),
      sortable: true,
      dataType: 'number',
      render: function render(time) {
        return asMillisecondDuration(time);
      }
    }, {
      field: 'p95',
      name: i18n.translate('xpack.apm.transactionsTable.95thPercentileColumnLabel', {
        defaultMessage: '95th percentile'
      }),
      sortable: true,
      dataType: 'number',
      render: function render(time) {
        return asMillisecondDuration(time);
      }
    }, {
      field: 'transactionsPerMinute',
      name: i18n.translate('xpack.apm.transactionsTable.transactionsPerMinuteColumnLabel', {
        defaultMessage: 'Trans. per minute'
      }),
      sortable: true,
      dataType: 'number',
      render: function render(value) {
        return "".concat(asDecimal(value), " ").concat(i18n.translate('xpack.apm.transactionsTable.transactionsPerMinuteUnitLabel', {
          defaultMessage: 'tpm'
        }));
      }
    }, {
      field: 'impact',
      name: /*#__PURE__*/React.createElement(React.Fragment, null, i18n.translate('xpack.apm.transactionsTable.impactColumnLabel', {
        defaultMessage: 'Impact'
      }), ' ', /*#__PURE__*/React.createElement(EuiIconTip, {
        size: "s",
        type: "questionInCircle",
        color: "subdued",
        iconProps: {
          className: 'eui-alignTop'
        },
        content: i18n.translate('xpack.apm.transactionsTable.impactColumnDescription', {
          defaultMessage: "The most used and slowest endpoints in your service. It's calculated by taking the relative average duration times the number of transactions per minute."
        })
      })),
      sortable: true,
      dataType: 'number',
      render: function render(value) {
        return /*#__PURE__*/React.createElement(ImpactBar, {
          value: value
        });
      }
    }];
  }, []);
  var noItemsMessage = /*#__PURE__*/React.createElement(EmptyMessage, {
    heading: i18n.translate('xpack.apm.transactionsTable.notFoundLabel', {
      defaultMessage: 'No transactions were found.'
    })
  });
  return /*#__PURE__*/React.createElement(ManagedTable, {
    noItemsMessage: isLoading ? /*#__PURE__*/React.createElement(LoadingStatePrompt, null) : noItemsMessage,
    columns: columns,
    items: items,
    initialSortField: "impact",
    initialSortDirection: "desc",
    initialPageSize: 25
  });
}