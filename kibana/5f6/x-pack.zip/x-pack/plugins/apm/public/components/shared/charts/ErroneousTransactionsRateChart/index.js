function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiTitle } from '@elastic/eui';
import theme from '@elastic/eui/dist/eui_theme_light.json';
import { i18n } from '@kbn/i18n';
import React, { useCallback } from 'react';
import { EuiPanel } from '@elastic/eui';
import { useChartsSync } from '../../../../hooks/useChartsSync';
import { useFetcher } from '../../../../hooks/useFetcher';
import { useUrlParams } from '../../../../hooks/useUrlParams';
import { callApmApi } from '../../../../services/rest/createCallApmApi';
import { asPercent } from '../../../../utils/formatters'; // @ts-ignore

import CustomPlot from '../CustomPlot';

var tickFormatY = function tickFormatY(y) {
  return asPercent(y || 0, 1);
};

export var ErroneousTransactionsRateChart = function ErroneousTransactionsRateChart() {
  var _useUrlParams = useUrlParams(),
      urlParams = _useUrlParams.urlParams,
      uiFilters = _useUrlParams.uiFilters;

  var syncedChartsProps = useChartsSync();
  var serviceName = urlParams.serviceName,
      start = urlParams.start,
      end = urlParams.end,
      transactionType = urlParams.transactionType,
      transactionName = urlParams.transactionName;

  var _useFetcher = useFetcher(function () {
    if (serviceName && start && end) {
      return callApmApi({
        pathname: '/api/apm/services/{serviceName}/transaction_groups/error_rate',
        params: {
          path: {
            serviceName: serviceName
          },
          query: {
            start: start,
            end: end,
            transactionType: transactionType,
            transactionName: transactionName,
            uiFilters: JSON.stringify(uiFilters)
          }
        }
      });
    }
  }, [serviceName, start, end, uiFilters, transactionType, transactionName]),
      data = _useFetcher.data;

  var combinedOnHover = useCallback(function (hoverX) {
    return syncedChartsProps.onHover(hoverX);
  }, [syncedChartsProps]);
  var errorRates = (data === null || data === void 0 ? void 0 : data.erroneousTransactionsRate) || [];
  return /*#__PURE__*/React.createElement(EuiPanel, null, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "xs"
  }, /*#__PURE__*/React.createElement("span", null, i18n.translate('xpack.apm.errorRateChart.title', {
    defaultMessage: 'Transaction error rate'
  }))), /*#__PURE__*/React.createElement(CustomPlot, _extends({}, syncedChartsProps, {
    noHits: data === null || data === void 0 ? void 0 : data.noHits,
    series: [{
      color: theme.euiColorVis7,
      data: [],
      legendValue: tickFormatY(data === null || data === void 0 ? void 0 : data.average),
      legendClickDisabled: true,
      title: i18n.translate('xpack.apm.errorRateChart.avgLabel', {
        defaultMessage: 'Avg.'
      }),
      type: 'linemark',
      hideTooltipValue: true
    }, {
      data: errorRates,
      type: 'line',
      color: theme.euiColorVis7,
      hideLegend: true,
      title: i18n.translate('xpack.apm.errorRateChart.rateLabel', {
        defaultMessage: 'Rate'
      })
    }],
    onHover: combinedOnHover,
    tickFormatY: tickFormatY,
    formatTooltipValue: function formatTooltipValue(_ref) {
      var y = _ref.y;
      return Number.isFinite(y) ? tickFormatY(y) : 'N/A';
    }
  })));
};