/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiTabs } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React from 'react';
import { isJavaAgentName, isRumAgentName } from '../../../../common/agent_name';
import { useAgentName } from '../../../hooks/useAgentName';
import { useApmPluginContext } from '../../../hooks/useApmPluginContext';
import { useUrlParams } from '../../../hooks/useUrlParams';
import { EuiTabLink } from '../../shared/EuiTabLink';
import { ErrorOverviewLink } from '../../shared/Links/apm/ErrorOverviewLink';
import { MetricOverviewLink } from '../../shared/Links/apm/MetricOverviewLink';
import { ServiceMapLink } from '../../shared/Links/apm/ServiceMapLink';
import { ServiceNodeOverviewLink } from '../../shared/Links/apm/ServiceNodeOverviewLink';
import { TransactionOverviewLink } from '../../shared/Links/apm/TransactionOverviewLink';
import { ErrorGroupOverview } from '../ErrorGroupOverview';
import { ServiceMap } from '../ServiceMap';
import { ServiceMetrics } from '../ServiceMetrics';
import { ServiceNodeOverview } from '../ServiceNodeOverview';
import { TransactionOverview } from '../TransactionOverview';
export function ServiceDetailTabs(_ref) {
  var tab = _ref.tab;

  var _useUrlParams = useUrlParams(),
      urlParams = _useUrlParams.urlParams;

  var serviceName = urlParams.serviceName;

  var _useAgentName = useAgentName(),
      agentName = _useAgentName.agentName;

  var serviceMapEnabled = useApmPluginContext().config.serviceMapEnabled;

  if (!serviceName) {
    // this never happens, urlParams type is not accurate enough
    throw new Error('Service name was not defined');
  }

  var transactionsTab = {
    link: /*#__PURE__*/React.createElement(TransactionOverviewLink, {
      serviceName: serviceName
    }, i18n.translate('xpack.apm.serviceDetails.transactionsTabLabel', {
      defaultMessage: 'Transactions'
    })),
    render: function render() {
      return /*#__PURE__*/React.createElement(TransactionOverview, null);
    },
    name: 'transactions'
  };
  var errorsTab = {
    link: /*#__PURE__*/React.createElement(ErrorOverviewLink, {
      serviceName: serviceName
    }, i18n.translate('xpack.apm.serviceDetails.errorsTabLabel', {
      defaultMessage: 'Errors'
    })),
    render: function render() {
      return /*#__PURE__*/React.createElement(ErrorGroupOverview, null);
    },
    name: 'errors'
  };
  var tabs = [transactionsTab, errorsTab];

  if (isJavaAgentName(agentName)) {
    var nodesListTab = {
      link: /*#__PURE__*/React.createElement(ServiceNodeOverviewLink, {
        serviceName: serviceName
      }, i18n.translate('xpack.apm.serviceDetails.nodesTabLabel', {
        defaultMessage: 'JVMs'
      })),
      render: function render() {
        return /*#__PURE__*/React.createElement(ServiceNodeOverview, null);
      },
      name: 'nodes'
    };
    tabs.push(nodesListTab);
  } else if (agentName && !isRumAgentName(agentName)) {
    var metricsTab = {
      link: /*#__PURE__*/React.createElement(MetricOverviewLink, {
        serviceName: serviceName
      }, i18n.translate('xpack.apm.serviceDetails.metricsTabLabel', {
        defaultMessage: 'Metrics'
      })),
      render: function render() {
        return /*#__PURE__*/React.createElement(ServiceMetrics, {
          agentName: agentName
        });
      },
      name: 'metrics'
    };
    tabs.push(metricsTab);
  }

  var serviceMapTab = {
    link: /*#__PURE__*/React.createElement(ServiceMapLink, {
      serviceName: serviceName
    }, i18n.translate('xpack.apm.home.serviceMapTabLabel', {
      defaultMessage: 'Service Map'
    })),
    render: function render() {
      return /*#__PURE__*/React.createElement(ServiceMap, {
        serviceName: serviceName
      });
    },
    name: 'service-map'
  };

  if (serviceMapEnabled) {
    tabs.push(serviceMapTab);
  }

  var selectedTab = tabs.find(function (serviceTab) {
    return serviceTab.name === tab;
  });
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiTabs, null, tabs.map(function (serviceTab) {
    return /*#__PURE__*/React.createElement(EuiTabLink, {
      isSelected: serviceTab.name === tab,
      key: serviceTab.name
    }, serviceTab.link);
  })), selectedTab ? selectedTab.render() : null);
}