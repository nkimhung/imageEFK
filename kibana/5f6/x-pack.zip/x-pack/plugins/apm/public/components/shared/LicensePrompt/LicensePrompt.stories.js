/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { storiesOf } from '@storybook/react';
import React from 'react';
import { ApmPluginContext } from '../../../context/ApmPluginContext';
import { LicensePrompt } from '.';
storiesOf('app/LicensePrompt', module).add('example', function () {
  var contextMock = {
    core: {
      http: {
        basePath: {
          prepend: function prepend() {}
        }
      }
    }
  };
  return /*#__PURE__*/React.createElement(ApmPluginContext.Provider, {
    value: contextMock
  }, /*#__PURE__*/React.createElement(LicensePrompt, {
    text: "To create Feature name, you must be subscribed to an Elastic X license or above."
  }));
}, {
  info: {
    source: false
  }
});