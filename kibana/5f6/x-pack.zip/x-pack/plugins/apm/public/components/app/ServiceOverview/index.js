/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiPanel, EuiFlexGroup, EuiFlexItem, EuiSpacer } from '@elastic/eui';
import { EuiLink } from '@elastic/eui';
import { i18n } from '@kbn/i18n';
import React, { useEffect, useMemo } from 'react';
import url from 'url';
import { toMountPoint } from '../../../../../../../src/plugins/kibana_react/public';
import { useFetcher } from '../../../hooks/useFetcher';
import { NoServicesMessage } from './NoServicesMessage';
import { ServiceList } from './ServiceList';
import { useUrlParams } from '../../../hooks/useUrlParams';
import { useTrackPageview } from '../../../../../observability/public';
import { PROJECTION } from '../../../../common/projections/typings';
import { LocalUIFilters } from '../../shared/LocalUIFilters';
import { useApmPluginContext } from '../../../hooks/useApmPluginContext';
var initalData = {
  items: [],
  hasHistoricalData: true,
  hasLegacyData: false
};
var hasDisplayedToast = false;
export function ServiceOverview() {
  var _useApmPluginContext = useApmPluginContext(),
      core = _useApmPluginContext.core;

  var _useUrlParams = useUrlParams(),
      _useUrlParams$urlPara = _useUrlParams.urlParams,
      start = _useUrlParams$urlPara.start,
      end = _useUrlParams$urlPara.end,
      uiFilters = _useUrlParams.uiFilters;

  var _useFetcher = useFetcher(function (callApmApi) {
    if (start && end) {
      return callApmApi({
        pathname: '/api/apm/services',
        params: {
          query: {
            start: start,
            end: end,
            uiFilters: JSON.stringify(uiFilters)
          }
        }
      });
    }
  }, [start, end, uiFilters]),
      _useFetcher$data = _useFetcher.data,
      data = _useFetcher$data === void 0 ? initalData : _useFetcher$data,
      status = _useFetcher.status;

  useEffect(function () {
    if (data.hasLegacyData && !hasDisplayedToast) {
      hasDisplayedToast = true;
      core.notifications.toasts.addWarning({
        title: i18n.translate('xpack.apm.serviceOverview.toastTitle', {
          defaultMessage: 'Legacy data was detected within the selected time range'
        }),
        text: toMountPoint( /*#__PURE__*/React.createElement("p", null, i18n.translate('xpack.apm.serviceOverview.toastText', {
          defaultMessage: "You're running Elastic Stack 7.0+ and we've detected incompatible data from a previous 6.x version. If you want to view this data in APM, you should migrate it. See more in "
        }), /*#__PURE__*/React.createElement(EuiLink, {
          href: url.format({
            pathname: core.http.basePath.prepend('/app/kibana'),
            hash: '/management/stack/upgrade_assistant'
          })
        }, i18n.translate('xpack.apm.serviceOverview.upgradeAssistantLink', {
          defaultMessage: 'the upgrade assistant'
        }))))
      });
    }
  }, [data.hasLegacyData, core.http.basePath, core.notifications.toasts]);
  useTrackPageview({
    app: 'apm',
    path: 'services_overview'
  });
  useTrackPageview({
    app: 'apm',
    path: 'services_overview',
    delay: 15000
  });
  var localFiltersConfig = useMemo(function () {
    return {
      filterNames: ['host', 'agentName'],
      projection: PROJECTION.SERVICES
    };
  }, []);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EuiSpacer, null), /*#__PURE__*/React.createElement(EuiFlexGroup, null, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: 1
  }, /*#__PURE__*/React.createElement(LocalUIFilters, localFiltersConfig)), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: 7
  }, /*#__PURE__*/React.createElement(EuiPanel, null, /*#__PURE__*/React.createElement(ServiceList, {
    items: data.items,
    noItemsMessage: /*#__PURE__*/React.createElement(NoServicesMessage, {
      historicalDataFound: data.hasHistoricalData,
      status: status
    })
  })))));
}