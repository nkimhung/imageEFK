/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { ERROR_GROUP_ID, SERVICE_NAME } from '../../../../../common/elasticsearch_fieldnames';
import { DiscoverLink } from './DiscoverLink';

function getDiscoverQuery(error, kuery) {
  var serviceName = error.service.name;
  var groupId = error.error.grouping_key;
  var query = "".concat(SERVICE_NAME, ":\"").concat(serviceName, "\" AND ").concat(ERROR_GROUP_ID, ":\"").concat(groupId, "\"");

  if (kuery) {
    query += " AND ".concat(kuery);
  }

  return {
    _a: {
      interval: 'auto',
      query: {
        language: 'kuery',
        query: query
      },
      sort: {
        '@timestamp': 'desc'
      }
    }
  };
}

var DiscoverErrorLink = function DiscoverErrorLink(_ref) {
  var error = _ref.error,
      kuery = _ref.kuery,
      children = _ref.children;
  return /*#__PURE__*/React.createElement(DiscoverLink, {
    query: getDiscoverQuery(error, kuery),
    children: children
  });
};

export { DiscoverErrorLink };