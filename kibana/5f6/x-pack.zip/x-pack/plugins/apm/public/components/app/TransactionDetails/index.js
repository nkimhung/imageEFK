/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiPanel, EuiSpacer, EuiTitle, EuiHorizontalRule, EuiFlexGroup, EuiFlexItem } from '@elastic/eui';
import React, { useMemo } from 'react';
import { EuiFlexGrid } from '@elastic/eui';
import { useTransactionCharts } from '../../../hooks/useTransactionCharts';
import { useTransactionDistribution } from '../../../hooks/useTransactionDistribution';
import { useWaterfall } from '../../../hooks/useWaterfall';
import { TransactionCharts } from '../../shared/charts/TransactionCharts';
import { ApmHeader } from '../../shared/ApmHeader';
import { TransactionDistribution } from './Distribution';
import { WaterfallWithSummmary } from './WaterfallWithSummmary';
import { useLocation } from '../../../hooks/useLocation';
import { useUrlParams } from '../../../hooks/useUrlParams';
import { FETCH_STATUS } from '../../../hooks/useFetcher';
import { TransactionBreakdown } from '../../shared/TransactionBreakdown';
import { ChartsSyncContextProvider } from '../../../context/ChartsSyncContext';
import { useTrackPageview } from '../../../../../observability/public';
import { PROJECTION } from '../../../../common/projections/typings';
import { LocalUIFilters } from '../../shared/LocalUIFilters';
import { HeightRetainer } from '../../shared/HeightRetainer';
import { ErroneousTransactionsRateChart } from '../../shared/charts/ErroneousTransactionsRateChart';
export function TransactionDetails() {
  var _distributionData$buc;

  var location = useLocation();

  var _useUrlParams = useUrlParams(),
      urlParams = _useUrlParams.urlParams;

  var _useTransactionDistri = useTransactionDistribution(urlParams),
      distributionData = _useTransactionDistri.data,
      distributionStatus = _useTransactionDistri.status;

  var _useTransactionCharts = useTransactionCharts(),
      transactionChartsData = _useTransactionCharts.data;

  var _useWaterfall = useWaterfall(urlParams),
      waterfall = _useWaterfall.waterfall,
      exceedsMax = _useWaterfall.exceedsMax,
      waterfallStatus = _useWaterfall.status;

  var transactionName = urlParams.transactionName,
      transactionType = urlParams.transactionType,
      serviceName = urlParams.serviceName;
  useTrackPageview({
    app: 'apm',
    path: 'transaction_details'
  });
  useTrackPageview({
    app: 'apm',
    path: 'transaction_details',
    delay: 15000
  });
  var localUIFiltersConfig = useMemo(function () {
    var config = {
      filterNames: ['transactionResult', 'serviceVersion'],
      projection: PROJECTION.TRANSACTIONS,
      params: {
        transactionName: transactionName,
        transactionType: transactionType,
        serviceName: serviceName
      }
    };
    return config;
  }, [transactionName, transactionType, serviceName]);
  var bucketIndex = distributionData.buckets.findIndex(function (bucket) {
    return bucket.samples.some(function (sample) {
      return sample.transactionId === urlParams.transactionId && sample.traceId === urlParams.traceId;
    });
  });
  var traceSamples = (_distributionData$buc = distributionData.buckets[bucketIndex]) === null || _distributionData$buc === void 0 ? void 0 : _distributionData$buc.samples;
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(ApmHeader, null, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "l"
  }, /*#__PURE__*/React.createElement("h1", null, transactionName))), /*#__PURE__*/React.createElement(EuiFlexGroup, null, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: 1
  }, /*#__PURE__*/React.createElement(LocalUIFilters, localUIFiltersConfig)), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: 7
  }, /*#__PURE__*/React.createElement(ChartsSyncContextProvider, null, /*#__PURE__*/React.createElement(EuiFlexGrid, {
    columns: 2,
    gutterSize: "s"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(TransactionBreakdown, null)), /*#__PURE__*/React.createElement(EuiFlexItem, null, /*#__PURE__*/React.createElement(ErroneousTransactionsRateChart, null))), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "s"
  }), /*#__PURE__*/React.createElement(TransactionCharts, {
    charts: transactionChartsData,
    urlParams: urlParams,
    location: location
  })), /*#__PURE__*/React.createElement(EuiHorizontalRule, {
    size: "full",
    margin: "l"
  }), /*#__PURE__*/React.createElement(EuiPanel, null, /*#__PURE__*/React.createElement(TransactionDistribution, {
    distribution: distributionData,
    isLoading: distributionStatus === FETCH_STATUS.LOADING,
    urlParams: urlParams,
    bucketIndex: bucketIndex
  })), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "s"
  }), /*#__PURE__*/React.createElement(HeightRetainer, null, /*#__PURE__*/React.createElement(WaterfallWithSummmary, {
    location: location,
    urlParams: urlParams,
    waterfall: waterfall,
    isLoading: waterfallStatus === FETCH_STATUS.LOADING,
    exceedsMax: exceedsMax,
    traceSamples: traceSamples
  })))));
}