function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React, { useCallback } from 'react';
import { useChartsSync } from '../../../../../hooks/useChartsSync'; // @ts-ignore

import CustomPlot from '../../CustomPlot';

var TransactionLineChart = function TransactionLineChart(props) {
  var series = props.series,
      tickFormatY = props.tickFormatY,
      formatTooltipValue = props.formatTooltipValue,
      _props$yMax = props.yMax,
      yMax = _props$yMax === void 0 ? 'max' : _props$yMax,
      height = props.height,
      truncateLegends = props.truncateLegends,
      _props$stacked = props.stacked,
      stacked = _props$stacked === void 0 ? false : _props$stacked,
      onHover = props.onHover;
  var syncedChartsProps = useChartsSync(); // combine callback for syncedChartsProps.onHover and props.onHover

  var combinedOnHover = useCallback(function (hoverX) {
    if (onHover) {
      onHover();
    }

    return syncedChartsProps.onHover(hoverX);
  }, [syncedChartsProps, onHover]);
  return /*#__PURE__*/React.createElement(CustomPlot, _extends({
    series: series
  }, syncedChartsProps, {
    onHover: combinedOnHover,
    tickFormatY: tickFormatY,
    formatTooltipValue: formatTooltipValue,
    yMax: yMax,
    height: height,
    truncateLegends: truncateLegends
  }, stacked ? {
    stackBy: 'y'
  } : {}));
};

export { TransactionLineChart };