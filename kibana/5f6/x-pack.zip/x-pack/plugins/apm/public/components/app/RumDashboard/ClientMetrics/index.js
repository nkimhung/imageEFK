/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import * as React from 'react';
import numeral from '@elastic/numeral';
import styled from 'styled-components';
import { EuiFlexGroup, EuiFlexItem, EuiStat, EuiToolTip } from '@elastic/eui';
import { useFetcher } from '../../../../hooks/useFetcher';
import { useUrlParams } from '../../../../hooks/useUrlParams';
import { I18LABELS } from '../translations';
var ClFlexGroup = styled(EuiFlexGroup).withConfig({
  displayName: "ClFlexGroup",
  componentId: "sc-1m748z4-0"
})(["flex-direction:row;@media only screen and (max-width:768px){flex-direction:row;justify-content:space-between;}"]);
export function ClientMetrics() {
  var _data$backEnd$value$t, _data$backEnd, _data$backEnd$value, _data$frontEnd$value$, _data$frontEnd, _data$frontEnd$value, _data$pageViews, _numeral$format, _data$pageViews2;

  var _useUrlParams = useUrlParams(),
      urlParams = _useUrlParams.urlParams,
      uiFilters = _useUrlParams.uiFilters;

  var start = urlParams.start,
      end = urlParams.end,
      serviceName = urlParams.serviceName;

  var _useFetcher = useFetcher(function (callApmApi) {
    if (start && end && serviceName) {
      return callApmApi({
        pathname: '/api/apm/rum/client-metrics',
        params: {
          query: {
            start: start,
            end: end,
            uiFilters: JSON.stringify(uiFilters)
          }
        }
      });
    }

    return Promise.resolve(null);
  }, [start, end, serviceName, uiFilters]),
      data = _useFetcher.data,
      status = _useFetcher.status;

  var STAT_STYLE = {
    width: '240px'
  };
  return /*#__PURE__*/React.createElement(ClFlexGroup, {
    responsive: false
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false,
    style: STAT_STYLE
  }, /*#__PURE__*/React.createElement(EuiStat, {
    titleSize: "s",
    title: ((_data$backEnd$value$t = data === null || data === void 0 ? void 0 : (_data$backEnd = data.backEnd) === null || _data$backEnd === void 0 ? void 0 : (_data$backEnd$value = _data$backEnd.value) === null || _data$backEnd$value === void 0 ? void 0 : _data$backEnd$value.toFixed(2)) !== null && _data$backEnd$value$t !== void 0 ? _data$backEnd$value$t : '-') + ' sec',
    description: I18LABELS.backEnd,
    isLoading: status !== 'success'
  })), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false,
    style: STAT_STYLE
  }, /*#__PURE__*/React.createElement(EuiStat, {
    titleSize: "s",
    title: ((_data$frontEnd$value$ = data === null || data === void 0 ? void 0 : (_data$frontEnd = data.frontEnd) === null || _data$frontEnd === void 0 ? void 0 : (_data$frontEnd$value = _data$frontEnd.value) === null || _data$frontEnd$value === void 0 ? void 0 : _data$frontEnd$value.toFixed(2)) !== null && _data$frontEnd$value$ !== void 0 ? _data$frontEnd$value$ : '-') + ' sec',
    description: I18LABELS.frontEnd,
    isLoading: status !== 'success'
  })), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false,
    style: STAT_STYLE
  }, /*#__PURE__*/React.createElement(EuiStat, {
    titleSize: "s",
    title: /*#__PURE__*/React.createElement(EuiToolTip, {
      content: data === null || data === void 0 ? void 0 : (_data$pageViews = data.pageViews) === null || _data$pageViews === void 0 ? void 0 : _data$pageViews.value
    }, /*#__PURE__*/React.createElement(React.Fragment, null, (_numeral$format = numeral(data === null || data === void 0 ? void 0 : (_data$pageViews2 = data.pageViews) === null || _data$pageViews2 === void 0 ? void 0 : _data$pageViews2.value).format('0 a')) !== null && _numeral$format !== void 0 ? _numeral$format : '-')),
    description: I18LABELS.pageViews,
    isLoading: status !== 'success'
  })));
}