function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { APMLink } from './APMLink';
import { useUrlParams } from '../../../../hooks/useUrlParams';
import { pickKeys } from '../../../../../common/utils/pick_keys';

var ServiceOverviewLink = function ServiceOverviewLink(props) {
  var _useUrlParams = useUrlParams(),
      urlParams = _useUrlParams.urlParams;

  var persistedFilters = pickKeys(urlParams, 'host', 'agentName');
  return /*#__PURE__*/React.createElement(APMLink, _extends({
    path: "/services",
    query: persistedFilters
  }, props));
};

export { ServiceOverviewLink };