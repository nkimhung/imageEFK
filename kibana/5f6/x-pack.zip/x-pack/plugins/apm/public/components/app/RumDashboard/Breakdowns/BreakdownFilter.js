/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import React from 'react';
import { BreakdownGroup } from './BreakdownGroup';
import { CLIENT_GEO_COUNTRY_ISO_CODE, USER_AGENT_DEVICE, USER_AGENT_NAME, USER_AGENT_OS } from '../../../../../common/elasticsearch_fieldnames';
export var BreakdownFilter = function BreakdownFilter(_ref) {
  var id = _ref.id,
      selectedBreakdowns = _ref.selectedBreakdowns,
      onBreakdownChange = _ref.onBreakdownChange;
  var categories = [{
    name: 'Browser',
    type: 'category',
    count: 0,
    selected: selectedBreakdowns.some(function (_ref2) {
      var name = _ref2.name;
      return name === 'Browser';
    }),
    fieldName: USER_AGENT_NAME
  }, {
    name: 'OS',
    type: 'category',
    count: 0,
    selected: selectedBreakdowns.some(function (_ref3) {
      var name = _ref3.name;
      return name === 'OS';
    }),
    fieldName: USER_AGENT_OS
  }, {
    name: 'Device',
    type: 'category',
    count: 0,
    selected: selectedBreakdowns.some(function (_ref4) {
      var name = _ref4.name;
      return name === 'Device';
    }),
    fieldName: USER_AGENT_DEVICE
  }, {
    name: 'Location',
    type: 'category',
    count: 0,
    selected: selectedBreakdowns.some(function (_ref5) {
      var name = _ref5.name;
      return name === 'Location';
    }),
    fieldName: CLIENT_GEO_COUNTRY_ISO_CODE
  }];
  return /*#__PURE__*/React.createElement(BreakdownGroup, {
    id: id,
    items: categories,
    onChange: function onChange(selValues) {
      onBreakdownChange(selValues);
    }
  });
};