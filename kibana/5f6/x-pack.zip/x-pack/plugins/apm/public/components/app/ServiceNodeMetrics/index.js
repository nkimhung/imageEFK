/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { EuiFlexGroup, EuiFlexItem, EuiTitle, EuiHorizontalRule, EuiFlexGrid, EuiPanel, EuiSpacer, EuiStat, EuiToolTip, EuiCallOut } from '@elastic/eui';
import React from 'react';
import { i18n } from '@kbn/i18n';
import styled from 'styled-components';
import { FormattedMessage } from '@kbn/i18n/react';
import { SERVICE_NODE_NAME_MISSING } from '../../../../common/service_nodes';
import { ApmHeader } from '../../shared/ApmHeader';
import { useUrlParams } from '../../../hooks/useUrlParams';
import { useAgentName } from '../../../hooks/useAgentName';
import { useServiceMetricCharts } from '../../../hooks/useServiceMetricCharts';
import { ChartsSyncContextProvider } from '../../../context/ChartsSyncContext';
import { MetricsChart } from '../../shared/charts/MetricsChart';
import { useFetcher, FETCH_STATUS } from '../../../hooks/useFetcher';
import { truncate, px, unit } from '../../../style/variables';
import { ElasticDocsLink } from '../../shared/Links/ElasticDocsLink';
var INITIAL_DATA = {
  host: '',
  containerId: ''
};
var Truncate = styled.span.withConfig({
  displayName: "Truncate",
  componentId: "sc-16psvbo-0"
})(["display:block;", ""], truncate(px(unit * 12)));
export function ServiceNodeMetrics() {
  var _useUrlParams = useUrlParams(),
      urlParams = _useUrlParams.urlParams,
      uiFilters = _useUrlParams.uiFilters;

  var serviceName = urlParams.serviceName,
      serviceNodeName = urlParams.serviceNodeName;

  var _useAgentName = useAgentName(),
      agentName = _useAgentName.agentName;

  var _useServiceMetricChar = useServiceMetricCharts(urlParams, agentName),
      data = _useServiceMetricChar.data;

  var start = urlParams.start,
      end = urlParams.end;

  var _useFetcher = useFetcher(function (callApmApi) {
    if (serviceName && serviceNodeName && start && end) {
      return callApmApi({
        pathname: '/api/apm/services/{serviceName}/node/{serviceNodeName}/metadata',
        params: {
          path: {
            serviceName: serviceName,
            serviceNodeName: serviceNodeName
          },
          query: {
            start: start,
            end: end,
            uiFilters: JSON.stringify(uiFilters)
          }
        }
      });
    }
  }, [serviceName, serviceNodeName, start, end, uiFilters]),
      _useFetcher$data = _useFetcher.data;

  _useFetcher$data = _useFetcher$data === void 0 ? INITIAL_DATA : _useFetcher$data;
  var host = _useFetcher$data.host,
      containerId = _useFetcher$data.containerId,
      status = _useFetcher.status;
  var isLoading = status === FETCH_STATUS.LOADING;
  var isAggregatedData = serviceNodeName === SERVICE_NODE_NAME_MISSING;
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(ApmHeader, null, /*#__PURE__*/React.createElement(EuiFlexGroup, {
    alignItems: "center"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiTitle, {
    size: "l"
  }, /*#__PURE__*/React.createElement("h1", null, serviceName))))), /*#__PURE__*/React.createElement(EuiHorizontalRule, {
    margin: "m"
  }), isAggregatedData ? /*#__PURE__*/React.createElement(EuiCallOut, {
    title: i18n.translate('xpack.apm.serviceNodeMetrics.unidentifiedServiceNodesWarningTitle', {
      defaultMessage: 'Could not identify JVMs'
    }),
    iconType: "help",
    color: "warning"
  }, /*#__PURE__*/React.createElement(FormattedMessage, {
    id: "xpack.apm.serviceNodeMetrics.unidentifiedServiceNodesWarningText",
    defaultMessage: "We could not identify which JVMs these metrics belong to. This is likely caused by running a version of APM Server that is older than 7.5. Upgrading to APM Server 7.5 or higher should resolve this issue. For more information on upgrading, see the {link}. As an alternative, you can use the Kibana Query bar to filter by hostname, container ID or other fields.",
    values: {
      link: /*#__PURE__*/React.createElement(ElasticDocsLink, {
        target: "_blank",
        section: "/apm/server",
        path: "/upgrading.html"
      }, i18n.translate('xpack.apm.serviceNodeMetrics.unidentifiedServiceNodesWarningDocumentationLink', {
        defaultMessage: 'documentation of APM Server'
      }))
    }
  })) : /*#__PURE__*/React.createElement(EuiFlexGroup, {
    gutterSize: "xl"
  }, /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiStat, {
    titleSize: "s",
    description: i18n.translate('xpack.apm.serviceNodeMetrics.serviceName', {
      defaultMessage: 'Service name'
    }),
    title: /*#__PURE__*/React.createElement(EuiToolTip, {
      content: serviceName
    }, /*#__PURE__*/React.createElement(Truncate, null, serviceName))
  })), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiStat, {
    titleSize: "s",
    isLoading: isLoading,
    description: i18n.translate('xpack.apm.serviceNodeMetrics.host', {
      defaultMessage: 'Host'
    }),
    title: /*#__PURE__*/React.createElement(EuiToolTip, {
      content: host
    }, /*#__PURE__*/React.createElement(Truncate, null, host))
  })), /*#__PURE__*/React.createElement(EuiFlexItem, {
    grow: false
  }, /*#__PURE__*/React.createElement(EuiStat, {
    titleSize: "s",
    isLoading: isLoading,
    description: i18n.translate('xpack.apm.serviceNodeMetrics.containerId', {
      defaultMessage: 'Container ID'
    }),
    title: /*#__PURE__*/React.createElement(EuiToolTip, {
      content: containerId
    }, /*#__PURE__*/React.createElement(Truncate, null, containerId))
  }))), /*#__PURE__*/React.createElement(EuiHorizontalRule, {
    margin: "m"
  }), agentName && serviceNodeName && /*#__PURE__*/React.createElement(ChartsSyncContextProvider, null, /*#__PURE__*/React.createElement(EuiFlexGrid, {
    columns: 2,
    gutterSize: "s"
  }, data.charts.map(function (chart) {
    return /*#__PURE__*/React.createElement(EuiFlexItem, {
      key: chart.key
    }, /*#__PURE__*/React.createElement(EuiPanel, null, /*#__PURE__*/React.createElement(MetricsChart, {
      start: start,
      end: end,
      chart: chart
    })));
  })), /*#__PURE__*/React.createElement(EuiSpacer, {
    size: "xxl"
  })));
}