function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
import { ApmRoute } from '@elastic/apm-rum-react';
import React from 'react';
import ReactDOM from 'react-dom';
import { Route, Router, Switch } from 'react-router-dom';
import styled, { ThemeProvider } from 'styled-components';
import euiDarkVars from '@elastic/eui/dist/eui_theme_dark.json';
import euiLightVars from '@elastic/eui/dist/eui_theme_light.json';
import { ApmPluginContext } from '../context/ApmPluginContext';
import { LicenseProvider } from '../context/LicenseContext';
import { LoadingIndicatorProvider } from '../context/LoadingIndicatorContext';
import { LocationProvider } from '../context/LocationContext';
import { MatchedRouteProvider } from '../context/MatchedRouteContext';
import { UrlParamsProvider } from '../context/UrlParamsContext';
import { AlertsContextProvider } from '../../../triggers_actions_ui/public';
import { KibanaContextProvider, useUiSetting$ } from '../../../../../src/plugins/kibana_react/public';
import { px, units } from '../style/variables';
import { UpdateBreadcrumbs } from '../components/app/Main/UpdateBreadcrumbs';
import { ScrollToTopOnPathChange } from '../components/app/Main/ScrollToTopOnPathChange';
import { routes } from '../components/app/Main/route_config';
import { history, resetHistory } from '../utils/history';
import 'react-vis/dist/style.css';
var MainContainer = styled.div.withConfig({
  displayName: "MainContainer",
  componentId: "p3yjla-0"
})(["padding:", ";height:100%;"], px(units.plus));

var App = function App() {
  var _useUiSetting$ = useUiSetting$('theme:darkMode'),
      _useUiSetting$2 = _slicedToArray(_useUiSetting$, 1),
      darkMode = _useUiSetting$2[0];

  return /*#__PURE__*/React.createElement(ThemeProvider, {
    theme: function theme(outerTheme) {
      return _objectSpread(_objectSpread({}, outerTheme), {}, {
        eui: darkMode ? euiDarkVars : euiLightVars,
        darkMode: darkMode
      });
    }
  }, /*#__PURE__*/React.createElement(MainContainer, {
    "data-test-subj": "apmMainContainer",
    role: "main"
  }, /*#__PURE__*/React.createElement(UpdateBreadcrumbs, {
    routes: routes
  }), /*#__PURE__*/React.createElement(Route, {
    component: ScrollToTopOnPathChange
  }), /*#__PURE__*/React.createElement(Switch, null, routes.map(function (route, i) {
    return /*#__PURE__*/React.createElement(ApmRoute, _extends({
      key: i
    }, route));
  }))));
};

var ApmAppRoot = function ApmAppRoot(_ref) {
  var core = _ref.core,
      deps = _ref.deps,
      routerHistory = _ref.routerHistory,
      config = _ref.config;
  var i18nCore = core.i18n;
  var plugins = deps;
  var apmPluginContextValue = {
    config: config,
    core: core,
    plugins: plugins
  };
  return /*#__PURE__*/React.createElement(ApmPluginContext.Provider, {
    value: apmPluginContextValue
  }, /*#__PURE__*/React.createElement(AlertsContextProvider, {
    value: {
      http: core.http,
      docLinks: core.docLinks,
      capabilities: core.application.capabilities,
      toastNotifications: core.notifications.toasts,
      actionTypeRegistry: plugins.triggers_actions_ui.actionTypeRegistry,
      alertTypeRegistry: plugins.triggers_actions_ui.alertTypeRegistry
    }
  }, /*#__PURE__*/React.createElement(KibanaContextProvider, {
    services: _objectSpread(_objectSpread({}, core), plugins)
  }, /*#__PURE__*/React.createElement(i18nCore.Context, null, /*#__PURE__*/React.createElement(Router, {
    history: routerHistory
  }, /*#__PURE__*/React.createElement(LocationProvider, null, /*#__PURE__*/React.createElement(MatchedRouteProvider, {
    routes: routes
  }, /*#__PURE__*/React.createElement(UrlParamsProvider, null, /*#__PURE__*/React.createElement(LoadingIndicatorProvider, null, /*#__PURE__*/React.createElement(LicenseProvider, null, /*#__PURE__*/React.createElement(App, null)))))))))));
};
/**
 * This module is rendered asynchronously in the Kibana platform.
 */


export var renderApp = function renderApp(core, deps, _ref2, config) {
  var element = _ref2.element;
  resetHistory();
  ReactDOM.render( /*#__PURE__*/React.createElement(ApmAppRoot, {
    core: core,
    deps: deps,
    routerHistory: history,
    config: config
  }), element);
  return function () {
    ReactDOM.unmountComponentAtNode(element);
  };
};