"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DEFAULT_TIMEOUT = void 0;

var _steps = require("cypress-cucumber-preprocessor/steps");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */

/** The default time in ms to wait for a Cypress command to complete */
const DEFAULT_TIMEOUT = 60 * 1000;
exports.DEFAULT_TIMEOUT = DEFAULT_TIMEOUT;
(0, _steps.Given)(`a user click page load breakdown filter`, () => {
  // wait for all loading to finish
  cy.get('kbnLoadingIndicator').should('not.be.visible');
  cy.get('.euiStat__title-isLoading').should('not.be.visible');
  const breakDownBtn = cy.get('[data-cy=breakdown-popover_pageLoad]');
  breakDownBtn.click();
});
(0, _steps.When)(`the user selected the breakdown`, () => {
  cy.get('[data-cy=filter-breakdown-item_Browser]', {
    timeout: DEFAULT_TIMEOUT
  }).click(); // click outside popover to close it

  cy.get('[data-cy=pageLoadDist]').click();
});
(0, _steps.Then)(`breakdown series should appear in chart`, () => {
  cy.get('.euiLoadingChart').should('not.be.visible');
  cy.get('div.echLegendItem__label[title=Chrome] ', {
    timeout: DEFAULT_TIMEOUT
  }).invoke('text').should('eq', 'Chrome');
});