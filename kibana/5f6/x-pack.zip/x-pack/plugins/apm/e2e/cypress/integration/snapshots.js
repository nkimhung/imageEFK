module.exports = {
  "__version": "4.9.0",
  "RUM Dashboard": {
    "Rum page filters (example #1)": {
      "1": "8 ",
      "2": "0.08 sec",
      "3": "0.01 sec"
    },
    "Rum page filters (example #2)": {
      "1": "28 ",
      "2": "0.07 sec",
      "3": "0.01 sec"
    },
    "Page load distribution chart legends": {
      "1": "Overall"
    }
  }
}
