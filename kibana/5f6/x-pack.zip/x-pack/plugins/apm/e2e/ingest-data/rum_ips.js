/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */

const IPS = [
  '89.191.86.214', // check24.de
  '167.40.79.24', // canada.ca
  '151.101.130.217', // elastic.co
  '185.143.68.17',
  '151.101.130.217',
  '185.143.68.17',
  '185.143.68.17',
  '151.101.130.217',
  '185.143.68.17',
];

module.exports = IPS;
