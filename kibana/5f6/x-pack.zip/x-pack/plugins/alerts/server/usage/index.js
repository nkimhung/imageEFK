"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "registerAlertsUsageCollector", {
  enumerable: true,
  get: function () {
    return _alerts_usage_collector.registerAlertsUsageCollector;
  }
});

var _alerts_usage_collector = require("./alerts_usage_collector");