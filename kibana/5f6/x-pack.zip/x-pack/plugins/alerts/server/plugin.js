"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.AlertingPlugin = exports.EVENT_LOG_ACTIONS = void 0;

var _operators = require("rxjs/operators");

var _alert_type_registry = require("./alert_type_registry");

var _task_runner = require("./task_runner");

var _alerts_client_factory = require("./alerts_client_factory");

var _license_state = require("./lib/license_state");

var _routes = require("./routes");

var _usage = require("./usage");

var _task = require("./usage/task");

var _saved_objects = require("./saved_objects");

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const EVENT_LOG_PROVIDER = 'alerting';
const EVENT_LOG_ACTIONS = {
  execute: 'execute',
  executeAction: 'execute-action',
  newInstance: 'new-instance',
  resolvedInstance: 'resolved-instance'
};
exports.EVENT_LOG_ACTIONS = EVENT_LOG_ACTIONS;

class AlertingPlugin {
  constructor(initializerContext) {
    _defineProperty(this, "logger", void 0);

    _defineProperty(this, "alertTypeRegistry", void 0);

    _defineProperty(this, "taskRunnerFactory", void 0);

    _defineProperty(this, "serverBasePath", void 0);

    _defineProperty(this, "licenseState", null);

    _defineProperty(this, "isESOUsingEphemeralEncryptionKey", void 0);

    _defineProperty(this, "spaces", void 0);

    _defineProperty(this, "security", void 0);

    _defineProperty(this, "alertsClientFactory", void 0);

    _defineProperty(this, "telemetryLogger", void 0);

    _defineProperty(this, "kibanaIndex", void 0);

    _defineProperty(this, "eventLogger", void 0);

    _defineProperty(this, "createRouteHandlerContext", core => {
      const {
        alertTypeRegistry,
        alertsClientFactory
      } = this;
      return async (context, request) => {
        const [{
          savedObjects
        }] = await core.getStartServices();
        return {
          getAlertsClient: () => {
            return alertsClientFactory.create(request, this.getScopedClientWithAlertSavedObjectType(savedObjects, request));
          },
          listTypes: alertTypeRegistry.list.bind(alertTypeRegistry)
        };
      };
    });

    _defineProperty(this, "spaceIdToNamespace", spaceId => {
      return this.spaces && spaceId ? this.spaces.spaceIdToNamespace(spaceId) : undefined;
    });

    _defineProperty(this, "getBasePath", spaceId => {
      return this.spaces && spaceId ? this.spaces.getBasePath(spaceId) : this.serverBasePath;
    });

    this.logger = initializerContext.logger.get('plugins', 'alerting');
    this.taskRunnerFactory = new _task_runner.TaskRunnerFactory();
    this.alertsClientFactory = new _alerts_client_factory.AlertsClientFactory();
    this.telemetryLogger = initializerContext.logger.get('telemetry');
    this.kibanaIndex = initializerContext.config.legacy.globalConfig$.pipe((0, _operators.first)(), (0, _operators.map)(config => config.kibana.index)).toPromise();
  }

  async setup(core, plugins) {
    var _plugins$spaces;

    this.licenseState = new _license_state.LicenseState(plugins.licensing.license$);
    this.spaces = (_plugins$spaces = plugins.spaces) === null || _plugins$spaces === void 0 ? void 0 : _plugins$spaces.spacesService;
    this.security = plugins.security;
    this.isESOUsingEphemeralEncryptionKey = plugins.encryptedSavedObjects.usingEphemeralEncryptionKey;

    if (this.isESOUsingEphemeralEncryptionKey) {
      this.logger.warn('APIs are disabled due to the Encrypted Saved Objects plugin using an ephemeral encryption key. Please set xpack.encryptedSavedObjects.encryptionKey in kibana.yml.');
    }

    (0, _saved_objects.setupSavedObjects)(core.savedObjects, plugins.encryptedSavedObjects);
    plugins.eventLog.registerProviderActions(EVENT_LOG_PROVIDER, Object.values(EVENT_LOG_ACTIONS));
    this.eventLogger = plugins.eventLog.getLogger({
      event: {
        provider: EVENT_LOG_PROVIDER
      }
    });
    const alertTypeRegistry = new _alert_type_registry.AlertTypeRegistry({
      taskManager: plugins.taskManager,
      taskRunnerFactory: this.taskRunnerFactory
    });
    this.alertTypeRegistry = alertTypeRegistry;
    this.serverBasePath = core.http.basePath.serverBasePath;
    const usageCollection = plugins.usageCollection;

    if (usageCollection) {
      (0, _task.initializeAlertingTelemetry)(this.telemetryLogger, core, plugins.taskManager, await this.kibanaIndex);
      core.getStartServices().then(async ([, startPlugins]) => {
        (0, _usage.registerAlertsUsageCollector)(usageCollection, startPlugins.taskManager);
      });
    }

    core.http.registerRouteHandlerContext('alerting', this.createRouteHandlerContext(core)); // Routes

    const router = core.http.createRouter(); // Register routes

    (0, _routes.createAlertRoute)(router, this.licenseState);
    (0, _routes.deleteAlertRoute)(router, this.licenseState);
    (0, _routes.findAlertRoute)(router, this.licenseState);
    (0, _routes.getAlertRoute)(router, this.licenseState);
    (0, _routes.getAlertStateRoute)(router, this.licenseState);
    (0, _routes.listAlertTypesRoute)(router, this.licenseState);
    (0, _routes.updateAlertRoute)(router, this.licenseState);
    (0, _routes.enableAlertRoute)(router, this.licenseState);
    (0, _routes.disableAlertRoute)(router, this.licenseState);
    (0, _routes.updateApiKeyRoute)(router, this.licenseState);
    (0, _routes.muteAllAlertRoute)(router, this.licenseState);
    (0, _routes.unmuteAllAlertRoute)(router, this.licenseState);
    (0, _routes.muteAlertInstanceRoute)(router, this.licenseState);
    (0, _routes.unmuteAlertInstanceRoute)(router, this.licenseState);
    (0, _routes.healthRoute)(router, this.licenseState, plugins.encryptedSavedObjects);
    return {
      registerType: alertTypeRegistry.register.bind(alertTypeRegistry)
    };
  }

  start(core, plugins) {
    const {
      spaces,
      isESOUsingEphemeralEncryptionKey,
      logger,
      taskRunnerFactory,
      alertTypeRegistry,
      alertsClientFactory,
      security
    } = this;
    const encryptedSavedObjectsClient = plugins.encryptedSavedObjects.getClient({
      includedHiddenTypes: ['alert']
    });
    alertsClientFactory.initialize({
      alertTypeRegistry: alertTypeRegistry,
      logger,
      taskManager: plugins.taskManager,
      securityPluginSetup: security,
      encryptedSavedObjectsClient,
      spaceIdToNamespace: this.spaceIdToNamespace,

      getSpaceId(request) {
        return spaces === null || spaces === void 0 ? void 0 : spaces.getSpaceId(request);
      },

      actions: plugins.actions
    });
    taskRunnerFactory.initialize({
      logger,
      getServices: this.getServicesFactory(core.savedObjects, core.elasticsearch),
      spaceIdToNamespace: this.spaceIdToNamespace,
      actionsPlugin: plugins.actions,
      encryptedSavedObjectsClient,
      getBasePath: this.getBasePath,
      eventLogger: this.eventLogger
    });
    (0, _task.scheduleAlertingTelemetry)(this.telemetryLogger, plugins.taskManager);
    return {
      listTypes: alertTypeRegistry.list.bind(this.alertTypeRegistry),
      // Ability to get an alerts client from legacy code
      getAlertsClientWithRequest: request => {
        if (isESOUsingEphemeralEncryptionKey === true) {
          throw new Error(`Unable to create alerts client due to the Encrypted Saved Objects plugin using an ephemeral encryption key. Please set xpack.encryptedSavedObjects.encryptionKey in kibana.yml`);
        }

        return alertsClientFactory.create(request, this.getScopedClientWithAlertSavedObjectType(core.savedObjects, request));
      }
    };
  }

  getServicesFactory(savedObjects, elasticsearch) {
    return request => ({
      callCluster: elasticsearch.legacy.client.asScoped(request).callAsCurrentUser,
      savedObjectsClient: this.getScopedClientWithAlertSavedObjectType(savedObjects, request),

      getLegacyScopedClusterClient(clusterClient) {
        return clusterClient.asScoped(request);
      }

    });
  }

  getScopedClientWithAlertSavedObjectType(savedObjects, request) {
    return savedObjects.getScopedClient(request, {
      includedHiddenTypes: ['alert', 'action']
    });
  }

  stop() {
    if (this.licenseState) {
      this.licenseState.clean();
    }
  }

}

exports.AlertingPlugin = AlertingPlugin;