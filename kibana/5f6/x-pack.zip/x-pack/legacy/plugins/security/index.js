"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.security = void 0;

var _path = require("path");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
const security = kibana => new kibana.Plugin({
  id: 'security',
  publicDir: (0, _path.resolve)(__dirname, 'public'),
  require: ['kibana'],
  configPrefix: 'xpack.security',
  uiExports: {
    hacks: ['plugins/security/hacks/legacy']
  },
  config: Joi => Joi.object({
    enabled: Joi.boolean().default(true)
  }).unknown().default(),

  init() {}

});

exports.security = security;