/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
// @ts-ignore
import { uiModules } from 'ui/modules';
import { npSetup, npStart } from 'ui/new_platform';
import routes from 'ui/routes';
import { isSystemApiRequest } from '../../../../../../src/plugins/kibana_legacy/public';
var securityPluginSetup = npSetup.plugins.security;

if (securityPluginSetup) {
  routes.when('/account', {
    template: '<div />',
    controller: function controller() {
      return npStart.core.application.navigateToApp('security_account');
    }
  });

  var getNextParameter = function getNextParameter() {
    var _window = window,
        location = _window.location;
    var next = encodeURIComponent("".concat(location.pathname).concat(location.search).concat(location.hash));
    return "&next=".concat(next);
  };

  var getProviderParameter = function getProviderParameter(tenant) {
    var key = "".concat(tenant, "/session_provider");
    var providerName = sessionStorage.getItem(key);
    return providerName ? "&provider=".concat(encodeURIComponent(providerName)) : '';
  };

  var module = uiModules.get('security', []);
  module.config(function ($httpProvider) {
    $httpProvider.interceptors.push(function ($q, $window, Promise) {
      var isAnonymous = npSetup.core.http.anonymousPaths.isAnonymous(window.location.pathname);

      function interceptorFactory(responseHandler) {
        return function interceptor(response) {
          if (!isAnonymous && !isSystemApiRequest(response.config)) {
            securityPluginSetup.sessionTimeout.extend(response.config.url);
          }

          if (response.status !== 401 || isAnonymous) {
            return responseHandler(response);
          }

          var _securityPluginSetup$ = securityPluginSetup.__legacyCompat,
              logoutUrl = _securityPluginSetup$.logoutUrl,
              tenant = _securityPluginSetup$.tenant;
          var next = getNextParameter();
          var provider = getProviderParameter(tenant);
          $window.location.href = "".concat(logoutUrl, "?msg=SESSION_EXPIRED").concat(next).concat(provider);
          return Promise.halt();
        };
      }

      return {
        response: interceptorFactory(function (response) {
          return response;
        }),
        responseError: interceptorFactory($q.reject)
      };
    });
  });
}