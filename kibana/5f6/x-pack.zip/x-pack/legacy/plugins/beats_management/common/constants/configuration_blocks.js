"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.UNIQUENESS_ENFORCING_TYPES = void 0;

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */
const UNIQUENESS_ENFORCING_TYPES = ['output'];
exports.UNIQUENESS_ENFORCING_TYPES = UNIQUENESS_ENFORCING_TYPES;