"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.monitoring = void 0;

var _config = require("./config");

/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License;
 * you may not use this file except in compliance with the Elastic License.
 */

/**
 * Invokes plugin modules to instantiate the Monitoring plugin for Kibana
 * @param kibana {Object} Kibana plugin instance
 * @return {Object} Monitoring UI Kibana plugin object
 */
const deps = ['kibana', 'elasticsearch', 'xpack_main'];

const monitoring = kibana => {
  return new kibana.Plugin({
    require: deps,
    id: 'monitoring',
    configPrefix: 'monitoring',

    init(server) {
      const npMonitoring = server.newPlatform.setup.plugins.monitoring;

      if (npMonitoring) {
        const kbnServerStatus = this.kbnServer.status;
        npMonitoring.registerLegacyAPI({
          getServerStatus: () => {
            var _status$overall;

            const status = kbnServerStatus.toJSON();
            return status === null || status === void 0 ? void 0 : (_status$overall = status.overall) === null || _status$overall === void 0 ? void 0 : _status$overall.state;
          }
        });
      }
    },

    config: _config.config
  });
};

exports.monitoring = monitoring;